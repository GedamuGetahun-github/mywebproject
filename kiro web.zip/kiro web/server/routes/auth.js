const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { User } = require('../db');
const { rateLimitLogin, validateEmail, validatePassword } = require('../middleware/security');

// ── POST /api/auth/signup ──────────────────────────────────────
router.post('/signup', rateLimitLogin, async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
      return res.status(400).json({ error: 'All fields are required.' });

    if (!validateEmail(email))
      return res.status(400).json({ error: 'Invalid email format.' });

    const pwdError = validatePassword(password);
    if (pwdError)
      return res.status(400).json({ error: pwdError });

    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: 'Email already registered.' });

    const hash = await bcrypt.hash(password, 12); // increased from 10 to 12 rounds
    const user = await User.create({ name, email, password: hash });

    const token = jwt.sign({ id: user._id, name: user.name, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email } });
  } catch (err) {
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// ── POST /api/auth/signin ──────────────────────────────────────
router.post('/signin', rateLimitLogin, async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email and password are required.' });

    if (!validateEmail(email))
      return res.status(400).json({ error: 'Invalid email format.' });

    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ error: 'Invalid email or password.' });

    const token = jwt.sign({ id: user._id, name: user.name, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email } });
  } catch (err) {
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// ── POST /api/auth/admin ───────────────────────────────────────
router.post('/admin', rateLimitLogin, (req, res) => {
  const { username, password } = req.body;
  if (username !== process.env.ADMIN_USERNAME || password !== process.env.ADMIN_PASSWORD)
    return res.status(401).json({ error: 'Invalid admin credentials.' });

  const token = jwt.sign({ role: 'admin', username }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.json({ token });
});

module.exports = router;
