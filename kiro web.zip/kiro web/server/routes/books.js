const router = require('express').Router();
const { Book } = require('../db');
const { requireAdmin } = require('../middleware/auth');

// ── GET /api/books (admin) ─────────────────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const books = await Book.find().sort({ createdAt: 1 });
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/books (admin) ────────────────────────────────────
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { title, author, category, progress } = req.body;
    if (!title) return res.status(400).json({ error: 'Title is required.' });
    const book = await Book.create({ title, author: author||'', category: category||'Other', progress: progress||0 });
    res.json({ success: true, id: book._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PATCH /api/books/:id (admin) ──────────────────────────────
router.patch('/:id', requireAdmin, async (req, res) => {
  try {
    await Book.findByIdAndUpdate(req.params.id, req.body);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/books/:id/log (admin) ───────────────────────────
router.post('/:id/log', requireAdmin, async (req, res) => {
  try {
    const { date, pct, note } = req.body;
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ error: 'Book not found.' });

    // Remove existing entry for same date then add new
    book.cal_log = book.cal_log.filter(e => e.date !== date);
    book.cal_log.push({ date, pct, note: note||'' });
    book.cal_log.sort((a,b) => b.date.localeCompare(a.date));
    book.progress = pct;
    await book.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/books/:id (admin) ─────────────────────────────
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
