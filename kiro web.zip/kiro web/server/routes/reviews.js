const router = require('express').Router();
const { Review } = require('../db');
const { requireUser, requireAdmin } = require('../middleware/auth');

// ── GET /api/reviews (public) ──────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const reviews = await Review.find().sort({ rating: -1, createdAt: -1 });
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reviews (user) ───────────────────────────────────
router.post('/', requireUser, async (req, res) => {
  try {
    const { service, rating, text } = req.body;
    if (!rating || !text) return res.status(400).json({ error: 'Rating and text are required.' });
    if (rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be 1–5.' });

    const review = await Review.create({
      user: req.user.id, name: req.user.name,
      service: service || '', rating, text,
    });
    res.json({ success: true, id: review._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/reviews/:id (admin) ───────────────────────────
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await Review.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
