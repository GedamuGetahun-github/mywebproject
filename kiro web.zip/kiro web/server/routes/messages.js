const router = require('express').Router();
const { Message } = require('../db');
const { requireAdmin } = require('../middleware/auth');

// ── POST /api/messages (public) ───────────────────────────────
router.post('/', async (req, res) => {
  try {
    const { name, email, device, message } = req.body;
    if (!name || !message) return res.status(400).json({ error: 'Name and message are required.' });
    await Message.create({ name, email: email||'', device: device||'', message });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/messages (admin) ──────────────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const msgs = await Message.find().sort({ createdAt: -1 });
    res.json(msgs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PATCH /api/messages/:id/read (admin) ──────────────────────
router.patch('/:id/read', requireAdmin, async (req, res) => {
  try {
    await Message.findByIdAndUpdate(req.params.id, { read: true });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/messages/:id (admin) ──────────────────────────
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await Message.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
