const router = require('express').Router();
const { Repair, Review, Message, User } = require('../db');
const { requireAdmin } = require('../middleware/auth');

// ── GET /api/stats (admin) ─────────────────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const [
      totalRepairs, completed, inProgress, pending,
      totalCustomers, totalReviews, avgRatingResult, unreadMsgs
    ] = await Promise.all([
      Repair.countDocuments(),
      Repair.countDocuments({ status: 'Completed' }),
      Repair.countDocuments({ status: 'In Progress' }),
      Repair.countDocuments({ status: 'Pending' }),
      User.countDocuments(),
      Review.countDocuments(),
      Review.aggregate([{ $group: { _id: null, avg: { $avg: '$rating' } } }]),
      Message.countDocuments({ read: false }),
    ]);

    const avgRating = avgRatingResult[0]?.avg || 0;

    res.json({
      totalRepairs, completed, inProgress, pending,
      totalCustomers, totalReviews,
      avgRating: parseFloat(avgRating).toFixed(1),
      unreadMsgs,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
