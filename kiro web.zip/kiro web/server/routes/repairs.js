const router = require('express').Router();
const { Repair } = require('../db');
const { requireUser, requireAdmin } = require('../middleware/auth');
const { sendRepairConfirmation, notifyAdminNewRepair, sendStatusUpdate } = require('../services/email');

const COST_MAP = {
  TV:'ETB 500–2,500', Laptop:'ETB 300–1,500', Mobile:'ETB 200–800',
  Appliance:'ETB 300–1,200', Printer:'ETB 150–700', 'Power System':'ETB 400–1,500'
};

// ── POST /api/repairs ──────────────────────────────────────────
router.post('/', requireUser, async (req, res) => {
  try {
    const { device, problems, urgency, phone, name } = req.body;
    if (!device || !problems || !phone || !name)
      return res.status(400).json({ error: 'Missing required fields.' });

    const deviceType = device.split(' ')[0];
    const cost = COST_MAP[deviceType] || 'ETB 150–2,500';
    const request_id = 'R-' + Date.now();

    const repair = await Repair.create({
      request_id, user: req.user.id, name, phone,
      email: req.user.email, device, problems,
      urgency: urgency || 'Normal', cost,
    });

    // Send emails (non-blocking)
    if (req.user.email) {
      sendRepairConfirmation(req.user.email, name, device, cost, request_id);
    }
    notifyAdminNewRepair(name, phone, device, problems);

    // Real-time notification to admin dashboard
    const io = req.app.get('io');
    if (io) io.to('admin').emit('new_repair', { request_id, name, device, status: 'Pending' });

    res.json({ success: true, request_id, cost, id: repair._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/repairs/mine ──────────────────────────────────────
router.get('/mine', requireUser, async (req, res) => {
  try {
    const repairs = await Repair.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(repairs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/repairs (admin) ───────────────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const repairs = await Repair.find().sort({ createdAt: -1 }).populate('user', 'name email');
    res.json(repairs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PATCH /api/repairs/:id (admin) ────────────────────────────
router.patch('/:id', requireAdmin, async (req, res) => {
  try {
    const repair = await Repair.findByIdAndUpdate(req.params.id, req.body, { new: true });
    // Send status update email to customer
    if (repair && repair.email && req.body.status) {
      sendStatusUpdate(repair.email, repair.name, repair.device, req.body.status, repair.request_id);
    }
    // Real-time update
    const io = req.app.get('io');
    if (io) io.emit('repair_updated', { id: req.params.id, status: req.body.status });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/repairs/:id (admin) ───────────────────────────
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await Repair.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
