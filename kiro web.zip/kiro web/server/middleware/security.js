// ── Advanced Security Middleware ───────────────────────────────

// 1. Input sanitization — prevent XSS and injection
function sanitizeInput(req, res, next) {
  const dangerous = /<script|javascript:|onerror=|onclick=/gi;
  
  function clean(obj) {
    if (typeof obj === 'string') {
      if (dangerous.test(obj)) {
        return res.status(400).json({ error: 'Invalid input detected.' });
      }
      return obj.trim();
    }
    if (typeof obj === 'object' && obj !== null) {
      for (let key in obj) {
        const result = clean(obj[key]);
        if (result === undefined) return; // blocked
        obj[key] = result;
      }
    }
    return obj;
  }

  clean(req.body);
  clean(req.query);
  clean(req.params);
  next();
}

// 2. Prevent brute force on login
const loginAttempts = new Map();

function rateLimitLogin(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const key = `${ip}-${req.body.email || req.body.username || 'unknown'}`;
  const now = Date.now();
  
  if (!loginAttempts.has(key)) {
    loginAttempts.set(key, { count: 1, firstAttempt: now });
    return next();
  }

  const data = loginAttempts.get(key);
  const elapsed = now - data.firstAttempt;

  // Reset after 15 minutes
  if (elapsed > 15 * 60 * 1000) {
    loginAttempts.set(key, { count: 1, firstAttempt: now });
    return next();
  }

  // Block after 5 failed attempts
  if (data.count >= 5) {
    const waitTime = Math.ceil((15 * 60 * 1000 - elapsed) / 1000 / 60);
    return res.status(429).json({
      error: `Too many login attempts. Try again in ${waitTime} minutes.`
    });
  }

  data.count++;
  next();
}

// 3. Validate email format
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// 4. Strong password check
function validatePassword(password) {
  if (password.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Z]/.test(password)) return 'Password must contain at least one uppercase letter.';
  if (!/[a-z]/.test(password)) return 'Password must contain at least one lowercase letter.';
  if (!/[0-9]/.test(password)) return 'Password must contain at least one number.';
  return null; // valid
}

// 5. SQL/NoSQL injection prevention (already handled by Mongoose, but extra layer)
function preventInjection(req, res, next) {
  const dangerous = /(\$where|\$ne|\$gt|\$lt|;|--|\/\*|\*\/|union|select|insert|update|delete|drop)/gi;
  
  function check(obj) {
    if (typeof obj === 'string' && dangerous.test(obj)) {
      return res.status(400).json({ error: 'Suspicious input detected.' });
    }
    if (typeof obj === 'object' && obj !== null) {
      for (let key in obj) {
        if (dangerous.test(key)) {
          return res.status(400).json({ error: 'Suspicious input detected.' });
        }
        const result = check(obj[key]);
        if (result) return result;
      }
    }
  }

  check(req.body);
  check(req.query);
  next();
}

// 6. CSRF protection token
function generateCSRFToken() {
  return require('crypto').randomBytes(32).toString('hex');
}

function verifyCSRFToken(req, res, next) {
  // Skip for GET requests
  if (req.method === 'GET') return next();
  
  const token = req.headers['x-csrf-token'];
  const sessionToken = req.session?.csrfToken;
  
  if (!token || token !== sessionToken) {
    return res.status(403).json({ error: 'Invalid CSRF token.' });
  }
  next();
}

module.exports = {
  sanitizeInput,
  rateLimitLogin,
  validateEmail,
  validatePassword,
  preventInjection,
  generateCSRFToken,
  verifyCSRFToken,
};
