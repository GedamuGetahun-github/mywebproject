# Gedamu Electronics — Node.js Backend

## Setup

```bash
cd server
npm install
cp .env.example .env
# Edit .env with your values
npm run dev
```

Server runs at: http://localhost:3001

## API Endpoints

### Auth
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | /api/auth/signup | Public | Register new user |
| POST | /api/auth/signin | Public | Login user |
| POST | /api/auth/admin  | Public | Admin login |

### Repairs
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST   | /api/repairs       | User  | Submit repair request |
| GET    | /api/repairs/mine  | User  | Get own repairs |
| GET    | /api/repairs       | Admin | Get all repairs |
| PATCH  | /api/repairs/:id   | Admin | Update status/cost |
| DELETE | /api/repairs/:id   | Admin | Delete repair |

### Reviews
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET    | /api/reviews     | Public | Get all reviews |
| POST   | /api/reviews     | User   | Submit review |
| DELETE | /api/reviews/:id | Admin  | Delete review |

### Messages
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST   | /api/messages          | Public | Send contact message |
| GET    | /api/messages          | Admin  | Get all messages |
| PATCH  | /api/messages/:id/read | Admin  | Mark as read |
| DELETE | /api/messages/:id      | Admin  | Delete message |

### Books (Admin Study)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET    | /api/books         | Admin | Get all books |
| POST   | /api/books         | Admin | Add book |
| PATCH  | /api/books/:id     | Admin | Update progress |
| POST   | /api/books/:id/log | Admin | Log calendar entry |
| DELETE | /api/books/:id     | Admin | Delete book |

### Stats
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | /api/stats | Admin | Dashboard overview stats |

## How it connects to web/

1. Add `<script src="/api.js"></script>` to `web/index.html`
2. Use `API.signup(...)`, `API.submitRepair(...)` etc. instead of localStorage
3. Tokens are stored in localStorage/sessionStorage automatically

## Database
SQLite file: `server/gedamu.db` (auto-created on first run)

## Deploy to production
- Use [Railway](https://railway.app) or [Render](https://render.com) — both free
- Set environment variables in their dashboard
- They auto-detect Node.js and run `npm start`
