require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const { connectDB } = require('./db');
const { sanitizeInput, preventInjection } = require('./middleware/security');
const compression = require('compression');
const { createServer } = require('http');
const { Server } = require('socket.io');

const app    = express();
const httpServer = createServer(app);
const io     = new Server(httpServer, { cors: { origin: process.env.FRONTEND_URL || '*' } });

// Make io available to routes
app.set('io', io);

// ── Socket.io ──────────────────────────────────────────────────
io.on('connection', (socket) => {
  // Admin joins admin room for real-time notifications
  socket.on('join_admin', () => socket.join('admin'));
  socket.on('disconnect', () => {});
});

// ── Performance: Gzip compression ─────────────────────────────
app.use(compression());

// ── Security middleware ────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      imgSrc: ["'self'", "data:", "https:", "http:"],
      connectSrc: ["'self'", "http://localhost:3001"],
      fontSrc: ["'self'", "https://cdnjs.cloudflare.com"],
      frameSrc: ["'self'", "https://www.google.com"],
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
  noSniff: true,
  xssFilter: true,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
}));

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json({ limit: '10mb' })); // Prevent huge payloads
app.use(sanitizeInput);      // XSS protection
app.use(preventInjection);   // SQL/NoSQL injection protection

// Rate limiting — 100 requests per 15 minutes per IP
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: 'Too many requests. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
}));

// Stricter rate limit for auth endpoints
app.use('/api/auth/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many login attempts. Try again in 15 minutes.' },
}));

// ── Serve static web files with caching ───────────────────────
app.use(express.static(path.join(__dirname, '../web'), {
  maxAge: '1d',           // Cache static files for 1 day
  etag: true,             // Enable ETags for cache validation
  lastModified: true,
  setHeaders: (res, filePath) => {
    // Cache HTML for 1 hour, assets for 1 day
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'public, max-age=3600');
    } else if (filePath.match(/\.(css|js|png|jpg|svg|ico)$/)) {
      res.setHeader('Cache-Control', 'public, max-age=86400');
    }
  }
}));

// ── API Routes ─────────────────────────────────────────────────
app.use('/api/auth',     require('./routes/auth'));
app.use('/api/repairs',  require('./routes/repairs'));
app.use('/api/reviews',  require('./routes/reviews'));
app.use('/api/messages', require('./routes/messages'));
app.use('/api/books',    require('./routes/books'));
app.use('/api/stats',    require('./routes/stats'));

// ── Health check ───────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', db: 'mongodb', time: new Date().toISOString() }));

// ── Fallback ───────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../web/index.html'));
});

// ── Start ──────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;

connectDB().then(() => {
  httpServer.listen(PORT, () => {
    console.log(`\n✅ Gedamu Electronics Server running on http://localhost:${PORT}`);
    console.log(`   Database: MongoDB`);
    console.log(`   Frontend: http://localhost:${PORT}`);
    console.log(`   API:      http://localhost:${PORT}/api`);
    console.log(`   Socket:   Real-time enabled\n`);
  });
});
