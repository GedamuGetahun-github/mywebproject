const mongoose = require('mongoose');

// ── Connect to MongoDB ─────────────────────────────────────────
async function connectDB() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ MongoDB connected:', mongoose.connection.host);
  } catch (err) {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1);
  }
}

// ── Schemas & Models ───────────────────────────────────────────

const UserSchema = new mongoose.Schema({
  name:       { type: String, required: true, trim: true },
  email:      { type: String, required: true, unique: true, lowercase: true },
  password:   { type: String, required: true },
}, { timestamps: true });

const RepairSchema = new mongoose.Schema({
  request_id: { type: String, required: true, unique: true },
  user:       { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  name:       { type: String, required: true },
  phone:      { type: String, required: true },
  email:      String,
  device:     { type: String, required: true },
  problems:   { type: String, required: true },
  urgency:    { type: String, default: 'Normal', enum: ['Normal','Urgent','Same Day'] },
  status:     { type: String, default: 'Pending', enum: ['Pending','In Progress','Completed'] },
  cost:       String,
  technician: String,
  notes:      String,
}, { timestamps: true });

const ReviewSchema = new mongoose.Schema({
  user:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  name:    { type: String, required: true },
  service: String,
  rating:  { type: Number, required: true, min: 1, max: 5 },
  text:    { type: String, required: true },
}, { timestamps: true });

const MessageSchema = new mongoose.Schema({
  name:    { type: String, required: true },
  email:   String,
  device:  String,
  message: { type: String, required: true },
  read:    { type: Boolean, default: false },
}, { timestamps: true });

const BookLogSchema = new mongoose.Schema({
  date: String,
  pct:  Number,
  note: String,
});

const BookSchema = new mongoose.Schema({
  title:       { type: String, required: true },
  author:      String,
  category:    { type: String, default: 'Other' },
  progress:    { type: Number, default: 0, min: 0, max: 100 },
  total_pages: Number,
  pages_read:  Number,
  hours_log:   [{ date: String, hours: Number }],
  cal_log:     [BookLogSchema],
}, { timestamps: true });

const User    = mongoose.model('User',    UserSchema);
const Repair  = mongoose.model('Repair',  RepairSchema);
const Review  = mongoose.model('Review',  ReviewSchema);
const Message = mongoose.model('Message', MessageSchema);
const Book    = mongoose.model('Book',    BookSchema);

module.exports = { connectDB, User, Repair, Review, Message, Book };
