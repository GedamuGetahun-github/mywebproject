const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS, // Gmail App Password
  },
});

// ── Send repair request confirmation to customer ───────────────
async function sendRepairConfirmation(to, name, device, cost, requestId) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) return;
  try {
    await transporter.sendMail({
      from: `"Gedamu Electronics" <${process.env.EMAIL_USER}>`,
      to,
      subject: `✅ Repair Request Received — ${requestId}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f8fafc;padding:2rem;border-radius:12px">
          <div style="background:#1a1a2e;padding:1.5rem;border-radius:8px;text-align:center;margin-bottom:1.5rem">
            <h1 style="color:#f97316;margin:0;font-size:1.4rem">⚡ Gedamu Electronics</h1>
            <p style="color:#94a3b8;margin:0.3rem 0 0;font-size:0.85rem">Doba Town, Hararghe</p>
          </div>
          <h2 style="color:#1a1a2e">Hello ${name}! 👋</h2>
          <p style="color:#334155">Your repair request has been received. Here are the details:</p>
          <div style="background:#fff;border-radius:8px;padding:1.2rem;margin:1rem 0;border-left:4px solid #f97316">
            <p style="margin:0.3rem 0"><strong>Request ID:</strong> ${requestId}</p>
            <p style="margin:0.3rem 0"><strong>Device:</strong> ${device}</p>
            <p style="margin:0.3rem 0"><strong>Estimated Cost:</strong> <span style="color:#f97316;font-weight:700">${cost}</span></p>
            <p style="margin:0.3rem 0"><strong>Status:</strong> <span style="color:#f59e0b">Pending</span></p>
          </div>
          <p style="color:#64748b">We will contact you shortly to confirm your appointment.</p>
          <p style="color:#64748b">📞 <strong>+251 954 030 195</strong></p>
          <div style="text-align:center;margin-top:1.5rem;padding-top:1rem;border-top:1px solid #e2e8f0">
            <p style="color:#94a3b8;font-size:0.78rem">© 2026 Gedamu Electronics Maintenance, Doba Town, Hararghe</p>
          </div>
        </div>`,
    });
  } catch (err) {
    console.error('Email error:', err.message);
  }
}

// ── Notify admin of new repair request ────────────────────────
async function notifyAdminNewRepair(name, phone, device, problems) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) return;
  try {
    await transporter.sendMail({
      from: `"Gedamu Electronics" <${process.env.EMAIL_USER}>`,
      to: process.env.EMAIL_USER,
      subject: `🔧 New Repair Request from ${name}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:500px">
          <h2 style="color:#f97316">New Repair Request</h2>
          <p><strong>Customer:</strong> ${name}</p>
          <p><strong>Phone:</strong> ${phone}</p>
          <p><strong>Device:</strong> ${device}</p>
          <p><strong>Problems:</strong> ${problems}</p>
          <a href="http://localhost:3001/admin/dashboard.html" style="background:#f97316;color:#fff;padding:0.6rem 1.2rem;border-radius:8px;text-decoration:none;display:inline-block;margin-top:1rem">View Dashboard</a>
        </div>`,
    });
  } catch (err) {
    console.error('Admin email error:', err.message);
  }
}

// ── Send repair status update to customer ─────────────────────
async function sendStatusUpdate(to, name, device, status, requestId) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) return;
  const statusColors = { Pending:'#f59e0b', 'In Progress':'#3b82f6', Completed:'#10b981' };
  const color = statusColors[status] || '#64748b';
  try {
    await transporter.sendMail({
      from: `"Gedamu Electronics" <${process.env.EMAIL_USER}>`,
      to,
      subject: `📱 Repair Update: ${status} — ${requestId}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#1a1a2e;padding:1.5rem;border-radius:8px;text-align:center;margin-bottom:1.5rem">
            <h1 style="color:#f97316;margin:0">⚡ Gedamu Electronics</h1>
          </div>
          <h2>Hello ${name}!</h2>
          <p>Your repair status has been updated:</p>
          <div style="background:#f8fafc;border-radius:8px;padding:1.2rem;border-left:4px solid ${color}">
            <p><strong>Device:</strong> ${device}</p>
            <p><strong>Status:</strong> <span style="color:${color};font-weight:700">${status}</span></p>
            <p><strong>Request ID:</strong> ${requestId}</p>
          </div>
          ${status === 'Completed' ? '<p style="color:#10b981;font-weight:600">✅ Your device is ready for pickup!</p>' : ''}
          <p>📞 Call us: <strong>+251 954 030 195</strong></p>
        </div>`,
    });
  } catch (err) {
    console.error('Status email error:', err.message);
  }
}

module.exports = { sendRepairConfirmation, notifyAdminNewRepair, sendStatusUpdate };
