import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Ticker from './components/Ticker';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Contact from './components/Contact';
import Feedback from './components/Feedback';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import CookieBanner from './components/CookieBanner';
import BuyMeCoffee from './components/BuyMeCoffee';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import PrivacyPolicy from './pages/PrivacyPolicy';
import ServicePage from './pages/ServicePage';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { LangProvider } from './context/LangContext';

function MainSite() {
  return (
    <>
      <CookieBanner />
      <Ticker />
      <Navbar />
      <AuthModal />
      <main>
        <Hero />
        <Services />
        <About />
        <Contact />
        <Feedback />
      </main>
      <Footer />
      <BuyMeCoffee />
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LangProvider>
        <AuthProvider>
          <Routes>
            <Route path="/"                       element={<MainSite />} />
            <Route path="/privacy"                element={<PrivacyPolicy />} />
            <Route path="/services/:slug"         element={<ServicePage />} />
            <Route path="/admin"                  element={<AdminLogin />} />
            <Route path="/admin/dashboard"        element={<AdminDashboard />} />
          </Routes>
        </AuthProvider>
      </LangProvider>
    </ThemeProvider>
  );
}
