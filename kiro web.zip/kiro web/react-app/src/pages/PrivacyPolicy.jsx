import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const SECTIONS = [
  { id:'info-collect', icon:'fa-database', title:'1. Information We Collect',
    content:`When you use our website or submit a repair request, we may collect: full name and contact details, device information, location (city/town), communication records, and usage data.` },
  { id:'how-use', icon:'fa-cogs', title:'2. How We Use Your Information',
    content:`We use your information to process repair requests, contact you about your device status, improve our services, send reminders (with consent), and maintain internal records.` },
  { id:'sharing', icon:'fa-share-alt', title:'3. Sharing of Your Data',
    content:`We do NOT sell, trade, or rent your personal information. We may share data only with technicians completing your repair, when required by law, or to protect our business or customers.` },
  { id:'security', icon:'fa-lock', title:'4. Data Security',
    content:`We take reasonable measures to protect your information including secure admin access, limited staff access, and regular review of data practices.` },
  { id:'cookies', icon:'fa-cookie-bite', title:'5. Cookies',
    content:`Our website uses browser localStorage to remember your language preference and display theme. No tracking or advertising cookies are used.` },
  { id:'rights', icon:'fa-user-shield', title:'6. Your Rights',
    content:`You have the right to access, correct, or delete your personal data, and to withdraw consent at any time. Contact us to exercise these rights.` },
  { id:'children', icon:'fa-child', title:"7. Children's Privacy",
    content:`Our services are not directed to children under 13. We do not knowingly collect data from children.` },
  { id:'changes', icon:'fa-sync-alt', title:'8. Changes to This Policy',
    content:`We may update this policy periodically. Continued use of our website after changes constitutes acceptance of the updated policy.` },
];

export default function PrivacyPolicy() {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  return (
    <div style={{ background:'#f1f5f9', minHeight:'100vh' }}>
      {/* Top bar */}
      <div style={{ background:'#1a1a2e', padding:'1rem 5%', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <Link to="/" style={{ color:'#94a3b8', textDecoration:'none', fontSize:'0.88rem' }}>
          <i className="fas fa-arrow-left"></i> Back to Home
        </Link>
        <div style={{ color:'#f97316', fontWeight:700 }}><i className="fas fa-bolt"></i> Gedamu Electronics</div>
      </div>

      {/* Hero */}
      <div style={{ background:'linear-gradient(135deg,#1a1a2e,#0f3460)', padding:'4rem 5%', textAlign:'center', color:'#fff' }}>
        <div style={{ width:70, height:70, background:'rgba(249,115,22,0.15)', border:'2px solid #f97316', borderRadius:20, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 1rem', fontSize:'2rem', color:'#f97316' }}>
          <i className="fas fa-shield-alt"></i>
        </div>
        <h1 style={{ fontSize:'clamp(1.8rem,4vw,2.8rem)', marginBottom:'0.7rem' }}>Privacy Policy</h1>
        <p style={{ color:'#94a3b8', maxWidth:500, margin:'0 auto' }}>We are committed to protecting your personal information and your right to privacy.</p>
        <span style={{ display:'inline-block', marginTop:'1rem', background:'rgba(249,115,22,0.15)', color:'#f97316', padding:'0.3rem 1rem', borderRadius:20, fontSize:'0.8rem', fontWeight:600 }}>
          <i className="fas fa-calendar-alt"></i> Last updated: April 14, 2026
        </span>
      </div>

      {/* Content */}
      <div style={{ maxWidth:800, margin:'0 auto', padding:'3rem 5%' }}>
        {SECTIONS.map(s => (
          <div key={s.id} id={s.id} style={{ background:'#fff', borderRadius:14, padding:'2rem', marginBottom:'1.5rem', boxShadow:'0 2px 12px rgba(0,0,0,0.06)' }}>
            <div style={{ display:'flex', alignItems:'center', gap:'0.8rem', marginBottom:'1rem' }}>
              <div style={{ width:40, height:40, borderRadius:10, background:'#fff7ed', display:'flex', alignItems:'center', justifyContent:'center', color:'#f97316', fontSize:'1.1rem' }}>
                <i className={`fas ${s.icon}`}></i>
              </div>
              <h2 style={{ fontSize:'1.1rem', fontWeight:700, color:'#1a1a2e' }}>{s.title}</h2>
            </div>
            <p style={{ fontSize:'0.9rem', lineHeight:1.8, color:'#64748b' }}>{s.content}</p>
          </div>
        ))}

        {/* Contact CTA */}
        <div style={{ background:'linear-gradient(135deg,#1a1a2e,#0f3460)', borderRadius:16, padding:'2.5rem', textAlign:'center', color:'#fff' }}>
          <h3 style={{ fontSize:'1.5rem', marginBottom:'0.7rem' }}>Questions About This Policy?</h3>
          <p style={{ color:'#94a3b8', marginBottom:'1.5rem' }}>If you have any questions, reach out to us directly.</p>
          <a href="mailto:Gedamugetahun22@gmail.com" className="btn"><i className="fas fa-envelope"></i> &nbsp;Gedamugetahun22@gmail.com</a>
        </div>
      </div>

      <div style={{ background:'#1a1a2e', color:'#94a3b8', textAlign:'center', padding:'1.2rem 5%', fontSize:'0.82rem' }}>
        © 2026 Gedamu Electronics Maintenance, Doba Town, Hararghe &nbsp;|&nbsp; <Link to="/" style={{ color:'#f97316' }}>Back to Home</Link>
      </div>
    </div>
  );
}
