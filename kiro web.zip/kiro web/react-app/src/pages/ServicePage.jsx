import React from 'react';
import { useParams, Link } from 'react-router-dom';

const SERVICES = {
  'tv-repair': {
    icon:'fa-tv', title:'TV Repair Service', badge:'90-Day Warranty',
    image:'https://images.unsplash.com/photo-1461151304267-38535e780c79?w=1200&auto=format&fit=crop',
    fixes:['No Power / Dead TV','Blank or Black Screen','No Sound','Color Issue','Remote Not Working','Broken Backlight','Wi-Fi Issue','Main Board Replacement','HDMI Port Repair','Overheating'],
    pricing:[{label:'Diagnosis',price:'Free'},{label:'Minor Repair',price:'From 300 ETB'},{label:'Board Repair',price:'From 800 ETB'},{label:'Screen Replace',price:'From 2500 ETB'}],
  },
  'laptop-pc': {
    icon:'fa-laptop', title:'Laptop & PC Repair', badge:'90-Day Warranty',
    image:'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=1200&auto=format&fit=crop',
    fixes:["Won't Turn On",'Broken Screen','Keyboard Replacement','Battery Replacement','HDD / SSD Upgrade','RAM Upgrade','Virus Removal','OS Installation','Overheating','Charging Port Repair'],
    pricing:[{label:'Diagnosis',price:'Free'},{label:'OS Install',price:'From 200 ETB'},{label:'Hardware Fix',price:'From 500 ETB'},{label:'Upgrade',price:'From 700 ETB'}],
  },
  'mobile-phones': {
    icon:'fa-mobile-alt', title:'Mobile Phone Repair', badge:'90-Day Warranty',
    image:'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=1200&auto=format&fit=crop',
    fixes:['Cracked Screen','Battery Replacement','Charging Port','Water Damage','Speaker / Mic','Camera Repair','Network Issue','Pattern/PIN Reset','Google FRP Bypass','Software Flash'],
    pricing:[{label:'Diagnosis',price:'Free'},{label:'Screen Repair',price:'From 400 ETB'},{label:'Battery',price:'From 250 ETB'},{label:'Water Damage',price:'From 350 ETB'}],
  },
  'home-appliances': {
    icon:'fa-blender', title:'Home Appliances Repair', badge:'90-Day Warranty',
    image:'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200&auto=format&fit=crop',
    fixes:['Refrigerator / Fridge','Washing Machine','Microwave Oven','Electric Stove','Electric Fan / AC','Blender / Mixer','Electric Iron','Water Pump','Electric Kettle','Power Surge Damage'],
    pricing:[{label:'Diagnosis',price:'Free'},{label:'Small Appliance',price:'From 150 ETB'},{label:'Medium Appliance',price:'From 500 ETB'},{label:'Large Appliance',price:'From 900 ETB'}],
  },
  'printers': {
    icon:'fa-print', title:'Printers & Scanners Repair', badge:'90-Day Warranty',
    image:'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=1200&auto=format&fit=crop',
    fixes:['Ink / Toner Issues','Paper Jam','Wi-Fi / Network Setup','Not Printing','Poor Print Quality','Roller Replacement','USB / Driver Issues','Scanner Not Working','General Servicing'],
    pricing:[{label:'Diagnosis',price:'Free'},{label:'Head Cleaning',price:'From 150 ETB'},{label:'Roller / Feed',price:'From 300 ETB'},{label:'Board Repair',price:'From 600 ETB'}],
  },
  'power-systems': {
    icon:'fa-car-battery', title:'Power Systems Repair', badge:'90-Day Warranty',
    image:'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=1200&auto=format&fit=crop',
    fixes:['UPS Repair','Solar Systems','Inverter Repair','Voltage Stabilizer','Power Supply Units','Battery Replacement','Surge Protectors','Generator Servicing','Wiring & Installation'],
    pricing:[{label:'Diagnosis',price:'Free'},{label:'UPS Repair',price:'From 400 ETB'},{label:'Inverter',price:'From 600 ETB'},{label:'Solar System',price:'From 800 ETB'}],
  },
};

const STEPS = ['Drop Off or Call','Free Diagnosis','Quote & Approval','Repair & Test','Pickup & Warranty'];

export default function ServicePage() {
  const { slug } = useParams();
  const s = SERVICES[slug];
  if (!s) return <div style={{ padding:'4rem', textAlign:'center' }}>Service not found. <Link to="/">Go Home</Link></div>;

  return (
    <div>
      {/* Top bar */}
      <div style={{ background:'#1a1a2e', padding:'1rem 5%', display:'flex', justifyContent:'space-between', alignItems:'center', position:'sticky', top:0, zIndex:100 }}>
        <Link to="/" style={{ color:'#94a3b8', textDecoration:'none', fontSize:'0.88rem' }}>
          <i className="fas fa-arrow-left"></i> Back to Home
        </Link>
        <div style={{ color:'#f97316', fontWeight:700 }}><i className="fas fa-bolt"></i> Gedamu Electronics</div>
      </div>

      {/* Hero */}
      <div style={{ background:'linear-gradient(135deg,#1a1a2e,#0f3460)', padding:'5rem 5% 4rem', textAlign:'center', color:'#fff' }}>
        <div style={{ fontSize:'4rem', color:'#f97316', marginBottom:'1rem' }}><i className={`fas ${s.icon}`}></i></div>
        <h1 style={{ fontSize:'clamp(1.8rem,4vw,3rem)', marginBottom:'0.8rem' }}>{s.title}</h1>
        <span style={{ background:'#f97316', color:'#fff', padding:'0.3rem 1rem', borderRadius:50, fontSize:'0.85rem', fontWeight:600 }}>{s.badge}</span>
      </div>

      {/* Image */}
      <div style={{ width:'100%', maxHeight:420, overflow:'hidden' }}>
        <img src={s.image} alt={s.title} style={{ width:'100%', height:420, objectFit:'cover', filter:'brightness(0.88)' }}/>
      </div>

      {/* Content */}
      <div style={{ maxWidth:1000, margin:'0 auto', padding:'4rem 5%' }}>

        {/* What we fix */}
        <p style={{ fontSize:'0.8rem', fontWeight:700, color:'#f97316', textTransform:'uppercase', letterSpacing:2, marginBottom:'0.5rem' }}>What We Fix</p>
        <h2 style={{ fontSize:'1.7rem', color:'#1a1a2e', marginBottom:'1.5rem' }}>Common Problems We Solve</h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:'1rem', marginBottom:'3rem' }}>
          {s.fixes.map(f => (
            <div key={f} style={{ background:'#f1f5f9', borderRadius:10, padding:'1rem', display:'flex', alignItems:'center', gap:'0.8rem', fontSize:'0.92rem', fontWeight:500 }}>
              <i className="fas fa-check-circle" style={{ color:'#f97316' }}></i> {f}
            </div>
          ))}
        </div>

        {/* Steps */}
        <p style={{ fontSize:'0.8rem', fontWeight:700, color:'#f97316', textTransform:'uppercase', letterSpacing:2, marginBottom:'0.5rem' }}>Our Process</p>
        <h2 style={{ fontSize:'1.7rem', color:'#1a1a2e', marginBottom:'1.5rem' }}>How We Work</h2>
        <div style={{ display:'flex', flexDirection:'column', gap:'1rem', marginBottom:'3rem' }}>
          {STEPS.map((step, i) => (
            <div key={step} style={{ display:'flex', alignItems:'center', gap:'1.2rem', background:'#f1f5f9', borderRadius:12, padding:'1.2rem 1.5rem' }}>
              <div style={{ width:36, height:36, borderRadius:'50%', background:'#f97316', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, flexShrink:0 }}>{i+1}</div>
              <span style={{ fontWeight:600, color:'#1a1a2e' }}>{step}</span>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <p style={{ fontSize:'0.8rem', fontWeight:700, color:'#f97316', textTransform:'uppercase', letterSpacing:2, marginBottom:'0.5rem' }}>Pricing</p>
        <h2 style={{ fontSize:'1.7rem', color:'#1a1a2e', marginBottom:'1.5rem' }}>Estimated Repair Costs</h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:'1.2rem', marginBottom:'3rem' }}>
          {s.pricing.map(p => (
            <div key={p.label} style={{ border:'2px solid #e2e8f0', borderRadius:12, padding:'1.5rem', textAlign:'center' }}>
              <h4 style={{ color:'#1a1a2e', marginBottom:'0.5rem' }}>{p.label}</h4>
              <div style={{ fontSize:'1.5rem', fontWeight:700, color:'#f97316' }}>{p.price}</div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div style={{ background:'linear-gradient(135deg,#1a1a2e,#0f3460)', borderRadius:16, padding:'2.5rem', textAlign:'center', color:'#fff' }}>
          <h3 style={{ fontSize:'1.5rem', marginBottom:'0.7rem' }}>Ready to Fix Your Device?</h3>
          <p style={{ color:'#94a3b8', marginBottom:'1.5rem' }}>Contact us today — same-day service available for most repairs.</p>
          <Link to="/#contact" className="btn">Book a Repair</Link>
        </div>
      </div>
    </div>
  );
}
