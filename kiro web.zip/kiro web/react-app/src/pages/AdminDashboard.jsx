import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DashOverview from '../components/admin/DashOverview';
import DashRepairs from '../components/admin/DashRepairs';
import DashCustomers from '../components/admin/DashCustomers';
import DashMessages from '../components/admin/DashMessages';
import DashFeedback from '../components/admin/DashFeedback';
import DashStudy from '../components/admin/DashStudy';
import DashReports from '../components/admin/DashReports';
import DashServices from '../components/admin/DashServices';

const NAV = [
  { id:'overview',   icon:'fa-th-large',    label:'Overview' },
  { id:'repairs',    icon:'fa-tools',       label:'Repair Jobs' },
  { id:'customers',  icon:'fa-users',       label:'Customers' },
  { id:'messages',   icon:'fa-envelope',    label:'Messages', badge:3 },
  { id:'services',   icon:'fa-cogs',        label:'Services' },
  { id:'reports',    icon:'fa-chart-bar',   label:'Reports' },
  { id:'feedback',   icon:'fa-star',        label:'Feedback' },
  { id:'study',      icon:'fa-book-open',   label:'My Study' },
];

export default function AdminDashboard() {
  const [section, setSection] = useState('overview');
  const [sideOpen, setSideOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!sessionStorage.getItem('gedamu_admin')) navigate('/admin');
  }, []);

  function logout() {
    sessionStorage.removeItem('gedamu_admin');
    navigate('/admin');
  }

  const sections = { overview:<DashOverview/>, repairs:<DashRepairs/>, customers:<DashCustomers/>, messages:<DashMessages/>, services:<DashServices/>, reports:<DashReports/>, feedback:<DashFeedback/>, study:<DashStudy/> };

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'#f1f5f9' }}>

      {/* Sidebar */}
      <aside className={`sidebar ${sideOpen?'open':''}`} id="sidebar">
        <div className="sidebar-logo"><i className="fas fa-bolt"></i><span>Gedamu Admin</span></div>
        <nav className="sidebar-nav">
          {NAV.map(n => (
            <a key={n.id} href="#" className={`nav-item ${section===n.id?'active':''}`}
              onClick={e=>{e.preventDefault();setSection(n.id);setSideOpen(false);}}>
              <i className={`fas ${n.icon}`}></i> {n.label}
              {n.badge && <span className="badge-count">{n.badge}</span>}
            </a>
          ))}
        </nav>
        <div className="sidebar-footer">
          <a href="/" className="nav-item"><i className="fas fa-globe"></i> View Website</a>
          <a href="#" className="nav-item logout" onClick={logout}><i className="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </aside>

      {/* Main */}
      <div className="main">
        <header className="topbar">
          <button className="menu-toggle" onClick={()=>setSideOpen(!sideOpen)}><i className="fas fa-bars"></i></button>
          <div className="topbar-title">{NAV.find(n=>n.id===section)?.label}</div>
          <div className="topbar-right">
            <div className="notif"><i className="fas fa-bell"></i><span className="dot"></span></div>
            <div className="admin-avatar">A</div>
          </div>
        </header>
        <div className="content">
          {sections[section]}
        </div>
      </div>
    </div>
  );
}
