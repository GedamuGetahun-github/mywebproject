import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin() {
  const [user, setUser]   = useState('');
  const [pass, setPass]   = useState('');
  const [show, setShow]   = useState(false);
  const [err, setErr]     = useState('');
  const navigate          = useNavigate();

  function login(e) {
    e.preventDefault();
    if (user === 'admin' && pass === 'gedamu2026') {
      sessionStorage.setItem('gedamu_admin', '1');
      navigate('/admin/dashboard');
    } else {
      setErr('Invalid username or password.');
    }
  }

  return (
    <div style={{ minHeight:'100vh', background:'linear-gradient(135deg,#1a1a2e,#0f3460)', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div className="modal" style={{ maxWidth:400, width:'100%', margin:'1rem', animation:'slideUp 0.4s ease' }}>
        <div className="modal-logo" style={{ marginBottom:'1.5rem', flexDirection:'column', gap:'0.5rem' }}>
          <div style={{ width:60, height:60, background:'linear-gradient(135deg,#f97316,#ea580c)', borderRadius:16, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 0.5rem', fontSize:'1.6rem', color:'#fff' }}>
            <i className="fas fa-shield-alt"></i>
          </div>
          <div style={{ fontSize:'1.2rem' }}><i className="fas fa-bolt"></i> Admin Portal</div>
          <p style={{ fontSize:'0.82rem', color:'#94a3b8', fontWeight:'normal' }}>Gedamu Electronics Maintenance</p>
        </div>
        <form onSubmit={login}>
          <div className="form-group" style={{ marginBottom:'1rem' }}>
            <i className="fas fa-user-shield"></i>
            <input type="text" placeholder="Admin username" value={user} onChange={e=>setUser(e.target.value)} required/>
          </div>
          <div className="form-group" style={{ marginBottom:'1rem' }}>
            <i className="fas fa-lock"></i>
            <input type={show?'text':'password'} placeholder="Password" value={pass} onChange={e=>setPass(e.target.value)} required/>
            <i className={`fas ${show?'fa-eye-slash':'fa-eye'}`} style={{ cursor:'pointer', color:'#94a3b8' }} onClick={()=>setShow(!show)}></i>
          </div>
          {err && <p style={{ color:'#ef4444', fontSize:'0.85rem', textAlign:'center', marginBottom:'0.8rem' }}>{err}</p>}
          <button type="submit" className="btn full-btn"><i className="fas fa-sign-in-alt"></i> Login to Dashboard</button>
        </form>
        <a href="/" style={{ display:'block', textAlign:'center', marginTop:'1.2rem', fontSize:'0.85rem', color:'#94a3b8', textDecoration:'none' }}>
          <i className="fas fa-arrow-left"></i> Back to Website
        </a>
      </div>
    </div>
  );
}
