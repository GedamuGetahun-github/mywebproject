import React, { createContext, useContext, useState } from 'react';

const translations = {
  en: {
    nav_home:'Home', nav_services:'Services', nav_about:'About', nav_contact:'Contact',
    hero_title:'Expert Electronics Maintenance',
    hero_sub:'Fast, reliable, and affordable repair services for all your electronic devices.',
    hero_btn:'Book a Repair',
    services_title:'Our Services',
    about_title:'About Us',
    contact_title:'Contact Us',
    send_btn:'Send Message',
    footer_copy:'© 2026 Gedamu Electronics Maintenance. All rights reserved.',
  },
  am: {
    nav_home:'መነሻ', nav_services:'አገልግሎቶች', nav_about:'ስለ እኛ', nav_contact:'ያግኙን',
    hero_title:'የኤሌክትሮኒክስ ጥገና ባለሙያዎች',
    hero_sub:'ለሁሉም የኤሌክትሮኒክስ መሳሪያዎችዎ ፈጣን፣ አስተማማኝ እና ተመጣጣኝ የጥገና አገልግሎት።',
    hero_btn:'ጥገና ያስይዙ',
    services_title:'አገልግሎቶቻችን',
    about_title:'ስለ እኛ',
    contact_title:'ያግኙን',
    send_btn:'መልዕክት ላክ',
    footer_copy:'© 2026 ገዳሙ ኤሌክትሮኒክስ ጥገና። መብቱ በሕግ የተጠበቀ ነው።',
  },
  or: {
    nav_home:'Mana', nav_services:'Tajaajila', nav_about:"Waa'ee Keenya", nav_contact:'Nu Quunnamaa',
    hero_title:'Ogeeyyii Suphaa Elektirooniksii',
    hero_sub:'Tajaajila suphaa ariifataa, amanamaa fi gatii madaalawaa meeshaalee elektirooniksii keessaniif.',
    hero_btn:'Suphaa Qabadhu',
    services_title:'Tajaajila Keenya',
    about_title:"Waa'ee Keenya",
    contact_title:'Nu Quunnamaa',
    send_btn:'Ergaa Ergi',
    footer_copy:'© 2026 Suphaa Elektirooniksii Gedamu. Mirgi seeraan eegameera.',
  },
};

const LangContext = createContext();

export function LangProvider({ children }) {
  const [lang, setLang] = useState(() => localStorage.getItem('gedamu-lang') || 'en');

  function t(key) { return translations[lang]?.[key] || translations.en[key] || key; }
  function changeLang(l) { setLang(l); localStorage.setItem('gedamu-lang', l); }

  return (
    <LangContext.Provider value={{ lang, t, changeLang }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() { return useContext(LangContext); }
