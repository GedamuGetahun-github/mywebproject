import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() =>
    JSON.parse(sessionStorage.getItem('gedamu_user') || 'null')
  );
  const [authModal, setAuthModal] = useState({ open: false, tab: 'signin' });

  function openModal(tab = 'signin') { setAuthModal({ open: true, tab }); }
  function closeModal()              { setAuthModal({ open: false, tab: 'signin' }); }

  function signup(name, email, password) {
    const users = JSON.parse(localStorage.getItem('gedamu_users') || '[]');
    if (users.find(u => u.email === email)) throw new Error('Email already registered.');
    users.push({ name, email, password });
    localStorage.setItem('gedamu_users', JSON.stringify(users));
    const u = { name, email };
    sessionStorage.setItem('gedamu_user', JSON.stringify(u));
    setUser(u);
  }

  function signin(email, password) {
    const users = JSON.parse(localStorage.getItem('gedamu_users') || '[]');
    const found = users.find(u => u.email === email && u.password === password);
    if (!found) throw new Error('Invalid email or password.');
    const u = { name: found.name, email: found.email };
    sessionStorage.setItem('gedamu_user', JSON.stringify(u));
    setUser(u);
  }

  function logout() {
    sessionStorage.removeItem('gedamu_user');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, authModal, openModal, closeModal, signup, signin, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() { return useContext(AuthContext); }
