import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

const themes = ['dark', 'light', 'bright'];
const icons  = ['fa-moon', 'fa-sun', 'fa-circle-half-stroke'];

export function ThemeProvider({ children }) {
  const [themeIndex, setThemeIndex] = useState(() =>
    parseInt(localStorage.getItem('gedamu-theme') || '0')
  );

  useEffect(() => {
    document.body.classList.remove('light', 'bright');
    if (themes[themeIndex] !== 'dark') document.body.classList.add(themes[themeIndex]);
    localStorage.setItem('gedamu-theme', themeIndex);
  }, [themeIndex]);

  function toggleTheme() { setThemeIndex(i => (i + 1) % themes.length); }

  return (
    <ThemeContext.Provider value={{ themeIndex, toggleTheme, icon: icons[themeIndex] }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() { return useContext(ThemeContext); }
