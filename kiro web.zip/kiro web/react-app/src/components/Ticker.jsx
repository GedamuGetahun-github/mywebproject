import React from 'react';

const messages = [
  'እንኳን ወደ ገዳሙ ኤሌክትሮኒክስ ጥገና ድህረ ገጽ በደህና መጡ',
  '⚡',
  'Gara marsariitii suphaa elektirooniksii Gedamu baga nagaan dhuftan',
  '⚡',
  'Welcome to Gedamu Electronics Maintenance — Fast, Reliable & Affordable Repairs',
  '⚡',
];

export default function Ticker() {
  const doubled = [...messages, ...messages];
  return (
    <div className="ticker-wrap">
      <div className="ticker">
        {doubled.map((m, i) => <span key={i}>{m}</span>)}
      </div>
    </div>
  );
}
