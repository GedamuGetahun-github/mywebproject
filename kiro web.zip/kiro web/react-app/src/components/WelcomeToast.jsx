import React, { useEffect, useState } from 'react';

export default function WelcomeToast({ user, type, onDone }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!user) return;
    setTimeout(() => setVisible(true), 100);
    const t = setTimeout(() => { setVisible(false); setTimeout(onDone, 500); }, 5000);
    return () => clearTimeout(t);
  }, [user]);

  if (!user) return null;

  return (
    <div className={`welcome-toast ${visible ? 'show' : ''}`}>
      <div className="wt-avatar">{user.name.charAt(0).toUpperCase()}</div>
      <div className="wt-body">
        <strong>{type === 'signup' ? '🎉 Welcome to Gedamu Electronics!' : '👋 Welcome back!'}</strong>
        <span>Hello, <em>{user.name}</em>! You are now signed in.</span>
      </div>
      <button className="wt-close" onClick={() => { setVisible(false); onDone(); }}>
        <i className="fas fa-times"></i>
      </button>
    </div>
  );
}
