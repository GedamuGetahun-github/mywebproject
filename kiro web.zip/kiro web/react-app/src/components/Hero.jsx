import React from 'react';

export default function Hero() {
  return (
    <section className="hero" id="home">
      <div className="hero-content">
        <h1>Expert Electronics Maintenance</h1>
        <p>Fast, reliable, and affordable repair services for all your electronic devices.</p>
        <a href="#contact" className="btn">Book a Repair</a>
      </div>
    </section>
  );
}
