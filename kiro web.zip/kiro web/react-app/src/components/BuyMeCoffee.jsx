import React, { useState } from 'react';

const ACCOUNTS = {
  'M-Pesa':             { label:'M-Pesa Number',     num:'+251 954 030 195', ussd:'tel:*171*1*251954030195#', app:null },
  'Telebirr':           { label:'Telebirr Number',    num:'+251 954 030 195', ussd:'tel:*127*1*251954030195#', app:'https://telebirr.et' },
  'CBE Account':        { label:'CBE Account Number', num:'1000XXXXXXXXXX',   ussd:'tel:*847#', app:'https://www.combanketh.et' },
  'Abyssinia CBE Birr': { label:'Abyssinia Account',  num:'0XXXXXXXXXXX',     ussd:'tel:*704#', app:'https://www.bankofabyssinia.com' },
  'Awash Bank':         { label:'Awash Bank Account', num:'0XXXXXXXXXXX',     ussd:'tel:*844#', app:'https://awashbank.com' },
};

const AMOUNTS = [50, 100, 200, 500];

export default function BuyMeCoffee() {
  const [open, setOpen]       = useState(false);
  const [amount, setAmount]   = useState(200);
  const [custom, setCustom]   = useState('');
  const [account, setAccount] = useState(null);
  const [toast, setToast]     = useState('');

  function pay(method) {
    const amt = custom ? parseInt(custom) : amount;
    if (!amt || amt < 10) { showToast('⚠️ Please enter a valid amount (min 10 ETB)'); return; }
    setAccount({ ...ACCOUNTS[method], method, amt });
    showToast(`Send ${amt} ETB via ${method} using the details below.`);
  }

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(''), 4000);
  }

  function copyNum() {
    navigator.clipboard.writeText(account.num).then(() => showToast('✅ Account number copied!'));
  }

  function close() { setOpen(false); setAccount(null); setCustom(''); }

  return (
    <>
      <div className="bmc-fab" onClick={() => setOpen(true)} title="Buy me a coffee">☕</div>

      {open && (
        <div className="bmc-overlay active" onClick={e => e.target === e.currentTarget && close()}>
          <div className="bmc-box">
            <button className="bmc-close" onClick={close}><i className="fas fa-times"></i></button>
            <div className="bmc-header">
              <div className="bmc-avatar">☕</div>
              <h3>Buy Gedamu a Coffee</h3>
              <p>If our service helped you, support us with a small contribution. Every cup counts! 🙏</p>
            </div>

            <div className="bmc-amounts">
              {AMOUNTS.map(a => (
                <button key={a} className={`bmc-amt ${amount === a && !custom ? 'active' : ''}`}
                  onClick={() => { setAmount(a); setCustom(''); setAccount(null); }}>
                  {a} ETB
                </button>
              ))}
            </div>

            <div className="bmc-custom">
              <input type="number" value={custom} onChange={e => { setCustom(e.target.value); setAccount(null); }}
                placeholder="Or enter custom amount (ETB)" min="10"/>
            </div>

            <div className="bmc-methods">
              <p className="bmc-methods-label">Pay via</p>
              <div className="bmc-method-grid">
                <button className="bmc-method" onClick={() => pay('M-Pesa')}>📱 M-Pesa</button>
                <button className="bmc-method" onClick={() => pay('Telebirr')}>🟡 Telebirr</button>
                <button className="bmc-method" onClick={() => pay('CBE Account')}>🏦 CBE Account</button>
                <button className="bmc-method" onClick={() => pay('Abyssinia CBE Birr')}>🏛️ Abyssinia</button>
                <button className="bmc-method full-method" onClick={() => pay('Awash Bank')}>🏧 Awash Bank</button>
              </div>

              {account && (
                <div className="bmc-account-info" style={{ display:'block' }}>
                  <div className="bmc-account-box">
                    <span className="bmc-account-label">{account.label}</span>
                    <span className="bmc-account-num">{account.num}</span>
                    <span className="bmc-account-name">Account Name: Gedamu Getahun</span>
                    <div className="bmc-account-row">
                      <button className="bmc-copy-btn" onClick={copyNum}><i className="fas fa-copy"></i> Copy Number</button>
                      <div className="bmc-account-actions">
                        {account.ussd && <a className="bmc-action-btn dial" href={account.ussd}><i className="fas fa-phone"></i> Dial USSD</a>}
                        {account.app  && <a className="bmc-action-btn app"  href={account.app} target="_blank" rel="noopener"><i className="fas fa-external-link-alt"></i> Open App</a>}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <p className="bmc-note"><i className="fas fa-heart" style={{ color:'#f43f5e' }}></i> Thank you for your support!</p>
          </div>
        </div>
      )}

      {toast && <div className="bmc-toast show">{toast}</div>}
    </>
  );
}
