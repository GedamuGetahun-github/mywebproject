import Captcha from './Captcha';
import SITE_CONFIG from '../config';

// inside Contact component, add state:
// const [captchaOk, setCaptchaOk] = useState(false);

const DEVICE_BRANDS = {
  TV: ['Samsung','LG','Sony','TCL','Hisense','Other'],
  Laptop: ['HP','Dell','Lenovo','Asus','Acer','Apple','Other'],
  Mobile: ['Samsung','iPhone','Tecno','Infinix','Huawei','Xiaomi','Other'],
  Appliance: ['Samsung','LG','Bosch','Haier','Other'],
  Printer: ['HP','Canon','Epson','Brother','Other'],
  'Power System': ['APC','Luminous','Sukam','Other'],
};

const DEVICE_PROBLEMS = {
  TV: ['No Power','Blank Screen','No Sound','Color Issue','Wi-Fi Issue','Overheating'],
  Laptop: ["Won't Turn On",'Broken Screen','Slow Performance','Virus/Malware','Battery Issue','OS Reinstallation','Windows Password Reset'],
  Mobile: ['Cracked Screen','Battery Drains Fast',"Won't Charge",'Water Damage','Pattern/PIN Reset','Google FRP Bypass','Software Flash'],
  Appliance: ['Not Turning On','Not Cooling','Not Heating','Making Noise','Water Leaking'],
  Printer: ['Not Printing','Paper Jam','Poor Quality','Driver Issue'],
  'Power System': ['No Output','Battery Dead','Inverter Fault','Charging Issue'],
};

const COST_MAP = {
  TV: 'ETB 500–2,500', Laptop: 'ETB 300–1,500', Mobile: 'ETB 200–800',
  Appliance: 'ETB 300–1,200', Printer: 'ETB 150–700', 'Power System': 'ETB 400–1,500',
};

export default function Contact() {
  const { user, openModal } = useAuth();
  const [step, setStep]           = useState(1);
  const [device, setDevice]       = useState('');
  const [brand, setBrand]         = useState('');
  const [model, setModel]         = useState('');
  const [problems, setProblems]   = useState([]);
  const [desc, setDesc]           = useState('');
  const [urgency, setUrgency]     = useState('Normal');
  const [name, setName]           = useState('');
  const [phone, setPhone]         = useState('');
  const [msg, setMsg]             = useState('');
  const [captchaOk, setCaptchaOk] = useState(false);

  function toggleProblem(p) {
    setProblems(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  }

  function goStep(n) {
    if (n === 2 && !device) { alert('Please select a device type.'); return; }
    if (n === 3 && problems.length === 0 && !desc.trim()) {
      alert('Please select an issue or describe the problem.'); return;
    }
    setStep(n);
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!user) { openModal('signin'); return; }
    if (!captchaOk) { setMsg('⚠️ Please complete the human verification first.'); return; }
    const cost = COST_MAP[device] || 'ETB 150–2,500';
    const req = {
      id: 'R-' + Date.now(),
      device: `${device}${brand ? ' — ' + brand : ''}${model ? ' ' + model : ''}`,
      problems: problems.length ? problems.join(', ') : desc,
      urgency, cost, status: 'Pending',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      phone, name, email: user.email,
    };
    const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
    if (!all[user.email]) all[user.email] = [];
    all[user.email].unshift(req);
    localStorage.setItem('gedamu_repair_requests', JSON.stringify(all));
    setMsg(`✅ Request submitted! Estimated cost: ${cost}. We'll call you at ${phone} shortly.`);
    setStep(1); setDevice(''); setBrand(''); setModel('');
    setProblems([]); setDesc(''); setName(''); setPhone('');
    setTimeout(() => setMsg(''), 6000);
  }

  const dots = [1,2,3];

  return (
    <section className="contact" id="contact">
      <h2 className="section-title">Contact Us</h2>
      <div className="contact-wrapper">

        {/* Left: info + map */}
        <div className="contact-info">
          <div className="contact-info-card">
            {[
              { icon:'fa-map-marker-alt', label:'Location',     val: SITE_CONFIG.address },
              { icon:'fa-phone',          label:'Phone',         val: SITE_CONFIG.phone,  href:`tel:${SITE_CONFIG.phone_raw}` },
              { icon:'fa-envelope',       label:'Email',         val: SITE_CONFIG.email,  href:`mailto:${SITE_CONFIG.email}` },
              { icon:'fa-clock',          label:'Working Hours', val: SITE_CONFIG.hours },
            ].map(r => (
              <div className="info-row" key={r.label}>
                <div className="info-icon"><i className={`fas ${r.icon}`}></i></div>
                <div className="info-text">
                  <span>{r.label}</span>
                  {r.href ? <a href={r.href}>{r.val}</a> : <p>{r.val}</p>}
                </div>
              </div>
            ))}
          </div>
          <div className="map-wrap">
            <iframe src={SITE_CONFIG.map_embed} title="Map" allowFullScreen loading="lazy"/>
          </div>
        </div>

        {/* Right: repair form */}
        <form className="contact-form" onSubmit={handleSubmit}>
          {/* Step dots */}
          <div className="steps-indicator">
            {dots.map((d, i) => (
              <React.Fragment key={d}>
                <div className={`step-dot ${step === d ? 'active' : step > d ? 'done' : ''}`}>{d}</div>
                {i < 2 && <div className={`step-line ${step > d ? 'done' : ''}`}></div>}
              </React.Fragment>
            ))}
          </div>

          {/* Step 1 */}
          {step === 1 && (
            <div className="form-step active">
              <h4 className="step-title"><i className="fas fa-mobile-alt"></i> Select Your Device</h4>
              <div className="cf-group">
                <label>Device Type</label>
                <select value={device} onChange={e => { setDevice(e.target.value); setBrand(''); setModel(''); }}>
                  <option value="">-- Select device type --</option>
                  {Object.keys(DEVICE_BRANDS).map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
              {device && (
                <div className="cf-group">
                  <label>Brand</label>
                  <select value={brand} onChange={e => setBrand(e.target.value)}>
                    <option value="">-- Select brand --</option>
                    {DEVICE_BRANDS[device].map(b => <option key={b}>{b}</option>)}
                  </select>
                </div>
              )}
              <div className="cf-group">
                <label>Model (optional)</label>
                <div className="cf-input-wrap">
                  <i className="fas fa-microchip"></i>
                  <input value={model} onChange={e => setModel(e.target.value)} placeholder="e.g. Galaxy A54"/>
                </div>
              </div>
              <button type="button" className="btn full-btn" onClick={() => goStep(2)}>Next <i className="fas fa-arrow-right"></i></button>
            </div>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <div className="form-step active">
              <h4 className="step-title"><i className="fas fa-tools"></i> Describe the Problem</h4>
              <div className="cf-group">
                <label>Common Issues</label>
                <div className="problem-chips">
                  {(DEVICE_PROBLEMS[device] || []).map(p => (
                    <span key={p} className={`chip ${problems.includes(p) ? 'selected' : ''}`} onClick={() => toggleProblem(p)}>{p}</span>
                  ))}
                </div>
              </div>
              <div className="cf-group">
                <label>Additional Details</label>
                <textarea rows="3" value={desc} onChange={e => setDesc(e.target.value)} placeholder="Describe any extra details..."/>
              </div>
              <div className="cf-group">
                <label>Urgency</label>
                <div className="urgency-options">
                  {['Normal','Urgent','Same Day'].map(u => (
                    <label key={u} className="urgency-opt">
                      <input type="radio" name="urgency" value={u} checked={urgency === u} onChange={() => setUrgency(u)}/> {u}
                    </label>
                  ))}
                </div>
              </div>
              <div className="step-nav">
                <button type="button" className="btn-back" onClick={() => setStep(1)}><i className="fas fa-arrow-left"></i> Back</button>
                <button type="button" className="btn full-btn" onClick={() => goStep(3)}>Next <i className="fas fa-arrow-right"></i></button>
              </div>
            </div>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <div className="form-step active">
              <h4 className="step-title"><i className="fas fa-user"></i> Your Contact Info</h4>
              <div className="cf-group">
                <label>Full Name</label>
                <div className="cf-input-wrap"><i className="fas fa-user"></i><input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" required/></div>
              </div>
              <div className="cf-group">
                <label>Phone Number</label>
                <div className="cf-input-wrap"><i className="fas fa-phone"></i><input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+251..." required/></div>
              </div>
              <div className="request-summary">
                <strong>Device:</strong> {device}{brand ? ` — ${brand}` : ''}{model ? ` ${model}` : ''}<br/>
                <strong>Problems:</strong> {problems.length ? problems.join(', ') : desc || 'Not specified'}<br/>
                <strong>Urgency:</strong> {urgency}
              </div>
              <Captcha onVerified={() => setCaptchaOk(true)} />
              <div className="step-nav">
                <button type="button" className="btn-back" onClick={() => setStep(2)}><i className="fas fa-arrow-left"></i> Back</button>
                <button type="submit" className="btn full-btn"><i className="fas fa-paper-plane"></i> Submit Request</button>
              </div>
            </div>
          )}

          {msg && <p className="form-msg" style={{ color: 'green' }}>{msg}</p>}
        </form>
      </div>
    </section>
  );
}
