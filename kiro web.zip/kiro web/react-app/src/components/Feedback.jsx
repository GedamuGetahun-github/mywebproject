import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const INITIAL = [
  { name:'Abebe G.',   service:'TV Repair',         rating:5, text:'Excellent service! My Samsung TV was fixed same day.', date:'Apr 10, 2026' },
  { name:'Fatuma A.',  service:'Mobile Phones',      rating:5, text:'Screen replaced perfectly. Very professional.',        date:'Apr 11, 2026' },
  { name:'Tadesse B.', service:'Laptop & PC',        rating:4, text:'Good work on my HP laptop. Quality is great.',         date:'Apr 12, 2026' },
  { name:'Meron H.',   service:'Home Appliances',    rating:5, text:'Washing machine repaired quickly.',                    date:'Apr 13, 2026' },
  { name:'Dawit T.',   service:'Printers & Scanners',rating:4, text:'Printer works perfectly now. Fair pricing.',           date:'Apr 14, 2026' },
];

function Stars({ n, interactive = false, onSelect }) {
  const [hover, setHover] = useState(0);
  return (
    <div className={interactive ? 'star-picker' : 'review-stars'}>
      {[1,2,3,4,5].map(i => (
        <i key={i}
          className={`${i <= (hover || n) ? 'fas' : 'far'} fa-star`}
          style={interactive ? { cursor:'pointer', color: i <= (hover || n) ? '#facc15' : '#334155', fontSize:'1.4rem' } : {}}
          onMouseEnter={() => interactive && setHover(i)}
          onMouseLeave={() => interactive && setHover(0)}
          onClick={() => interactive && onSelect(i)}
        />
      ))}
    </div>
  );
}

export default function Feedback() {
  const { user, openModal } = useAuth();
  const [reviews, setReviews] = useState(() =>
    JSON.parse(localStorage.getItem('gedamu_reviews') || 'null') || INITIAL
  );
  const [showAll, setShowAll]   = useState(false);
  const [rating, setRating]     = useState(0);
  const [form, setForm]         = useState({ name:'', service:'', text:'' });
  const [msg, setMsg]           = useState('');

  const sorted  = [...reviews].sort((a,b) => b.rating - a.rating);
  const visible = showAll ? sorted : sorted.slice(0, 3);
  const avg     = reviews.length ? (reviews.reduce((s,r) => s+r.rating,0)/reviews.length).toFixed(1) : '0.0';
  const total   = reviews.length;

  function save(r) { localStorage.setItem('gedamu_reviews', JSON.stringify(r)); }

  function submit(e) {
    e.preventDefault();
    if (!user) { openModal('signin'); return; }
    if (!rating) { setMsg('⚠️ Please select a star rating.'); return; }
    const r = { ...form, rating, date: new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) };
    const updated = [...reviews, r];
    setReviews(updated); save(updated);
    setForm({ name:'', service:'', text:'' }); setRating(0);
    setMsg('✅ Thank you for your feedback!');
    setTimeout(() => setMsg(''), 3000);
  }

  return (
    <section className="feedback-section" id="feedback">
      <h2 className="section-title">Customer Feedback</h2>

      <div className="reviews-wrap">
        {/* Summary */}
        <div className="reviews-summary">
          <div className="avg-score">{avg}</div>
          <Stars n={Math.round(avg)} />
          <p>{total ? `Based on ${total} review${total>1?'s':''}` : 'No reviews yet'}</p>
          <div className="rating-bars">
            {[5,4,3,2,1].map(n => {
              const count = reviews.filter(r => r.rating === n).length;
              const pct   = total ? Math.round(count/total*100) : 0;
              return (
                <div className="rating-bar-row" key={n}>
                  <span className="rb-label">{n}★</span>
                  <div className="rb-track"><div className="rb-fill" style={{ width:`${pct}%` }}></div></div>
                  <span className="rb-count">{count}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cards */}
        <div className="reviews-list">
          {visible.map((r,i) => (
            <div className="review-card" key={i}>
              <div className="review-top">
                <span className="review-author">{r.name}</span>
                <span className="review-date">{r.date}</span>
              </div>
              <Stars n={r.rating} />
              {r.service && <span className="review-service">{r.service}</span>}
              <p className="review-text">{r.text}</p>
            </div>
          ))}
          {sorted.length > 3 && (
            <button className="see-all-btn" onClick={() => setShowAll(!showAll)}>
              <i className={`fas fa-chevron-${showAll?'up':'down'}`}></i>
              {showAll ? 'Show Less' : `See All ${total} Reviews`}
            </button>
          )}
        </div>
      </div>

      {/* Review form */}
      <div className="review-form-wrap">
        <h3><i className="fas fa-pen"></i> Leave a Review</h3>
        <form className="review-form" onSubmit={submit}>
          <div className="cf-group">
            <label>Your Name</label>
            <div className="cf-input-wrap">
              <i className="fas fa-user"></i>
              <input value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} placeholder="Your name" required/>
            </div>
          </div>
          <div className="cf-group">
            <label>Service Used</label>
            <select value={form.service} onChange={e => setForm(f=>({...f,service:e.target.value}))}>
              <option value="">-- Select service --</option>
              {['TV Repair','Laptop & PC','Mobile Phones','Home Appliances','Printers & Scanners','Power Systems'].map(s=><option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="cf-group">
            <label>Rating</label>
            <Stars n={rating} interactive onSelect={setRating} />
          </div>
          <div className="cf-group">
            <label>Your Review</label>
            <textarea rows="3" value={form.text} onChange={e => setForm(f=>({...f,text:e.target.value}))} placeholder="Share your experience..." required/>
          </div>
          <button type="submit" className="btn full-btn"><i className="fas fa-paper-plane"></i> Submit Review</button>
          {msg && <p className="form-msg" style={{ color: msg.startsWith('✅') ? 'green' : '#f97316' }}>{msg}</p>}
        </form>
      </div>
    </section>
  );
}
