import React, { useState, useEffect } from 'react';

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!localStorage.getItem('gedamu_cookie_consent')) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  function setConsent(choice) {
    localStorage.setItem('gedamu_cookie_consent', choice);
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className={`cookie-banner ${visible ? 'show' : ''}`}>
      <div className="cookie-inner">
        <div className="cookie-icon"><i className="fas fa-cookie-bite"></i></div>
        <div className="cookie-text">
          <strong>We use cookies</strong>
          <p>We use browser storage to remember your language and theme preference. No tracking cookies. <a href="/privacy#cookies" target="_blank">Learn more</a></p>
        </div>
        <div className="cookie-actions">
          <button className="cookie-btn accept" onClick={() => setConsent('accepted')}><i className="fas fa-check"></i> Accept All</button>
          <button className="cookie-btn necessary" onClick={() => setConsent('necessary')}>Necessary Only</button>
          <button className="cookie-btn decline" onClick={() => setConsent('declined')}>Decline</button>
        </div>
      </div>
    </div>
  );
}
