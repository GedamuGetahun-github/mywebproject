import React from 'react';

const SERVICES = [
  { icon:'fa-tv',          color:'#3b82f6', name:'TV Repair',           jobs:36, revenue:'18,500' },
  { icon:'fa-laptop',      color:'#10b981', name:'Laptop & PC',          jobs:29, revenue:'12,300' },
  { icon:'fa-mobile-alt',  color:'#f97316', name:'Mobile Phones',        jobs:25, revenue:'8,750'  },
  { icon:'fa-blender',     color:'#8b5cf6', name:'Home Appliances',      jobs:17, revenue:'9,200'  },
  { icon:'fa-print',       color:'#ec4899', name:'Printers & Scanners',  jobs:12, revenue:'3,600'  },
  { icon:'fa-car-battery', color:'#f59e0b', name:'Power Systems',        jobs:5,  revenue:'4,000'  },
];

export default function DashServices() {
  return (
    <div className="dash-card full">
      <div className="card-header"><h4>Managed Services</h4></div>
      <table className="data-table">
        <thead>
          <tr><th>Service</th><th>Jobs This Month</th><th>Revenue (ETB)</th><th>Status</th></tr>
        </thead>
        <tbody>
          {SERVICES.map(s => (
            <tr key={s.name}>
              <td><i className={`fas ${s.icon}`} style={{ color:s.color, marginRight:8 }}></i>{s.name}</td>
              <td>{s.jobs}</td>
              <td>{s.revenue}</td>
              <td><span className="status completed">Active</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
