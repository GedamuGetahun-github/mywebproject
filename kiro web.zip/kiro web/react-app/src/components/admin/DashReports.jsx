import React from 'react';

const STATS = [
  { label:'Jobs This Year',      val:'124',       color:'blue',   icon:'fa-calendar-check' },
  { label:'Total Revenue',       val:'56,350 ETB', color:'green',  icon:'fa-coins' },
  { label:'Satisfaction Rate',   val:'98%',        color:'orange', icon:'fa-star' },
  { label:'Repeat Customers',    val:'34',         color:'purple', icon:'fa-redo' },
];

const MONTHS = [
  { label:'Nov', pct:55 }, { label:'Dec', pct:40 }, { label:'Jan', pct:70 },
  { label:'Feb', pct:60 }, { label:'Mar', pct:80 }, { label:'Apr', pct:90, current:true },
];

export default function DashReports() {
  const max = Math.max(...MONTHS.map(m => m.pct));
  return (
    <>
      <div className="stats-grid">
        {STATS.map(s => (
          <div className={`stat-card ${s.color}`} key={s.label}>
            <div className="stat-icon"><i className={`fas ${s.icon}`}></i></div>
            <div className="stat-info"><h3>{s.val}</h3><p>{s.label}</p></div>
          </div>
        ))}
      </div>

      <div className="dash-card full" style={{ marginTop:'1.5rem' }}>
        <div className="card-header">
          <h4>Monthly Revenue Summary</h4>
          <span style={{ fontSize:'0.82rem', color:'#94a3b8' }}>Last 6 months · 2026</span>
        </div>
        <div className="monthly-bars">
          {MONTHS.map(m => (
            <div className="month-bar" key={m.label}>
              <div
                className={`bar-col ${m.current ? 'active' : ''}`}
                style={{ height: `${Math.round((m.pct / max) * 100)}%` }}
              ></div>
              <span>{m.label}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
