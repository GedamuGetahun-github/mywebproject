import React, { useState } from 'react';

const MSGS = [
  { name:'Abebe Girma',  date:'Apr 14, 9:12 AM',  text:'My Samsung TV has no picture but has sound. Can you fix it today?', device:'Samsung TV',      unread:true },
  { name:'Fatuma Ali',   date:'Apr 13, 3:45 PM',  text:'My iPhone screen is cracked. How much does it cost to replace?',    device:'iPhone 13',       unread:true },
  { name:'Tadesse B.',   date:'Apr 13, 11:20 AM', text:'My HP laptop won\'t turn on after a power surge. Please help.',      device:'HP Laptop',       unread:true },
  { name:'Meron Haile',  date:'Apr 11, 8:00 AM',  text:'Thank you for fixing my washing machine so quickly!',               device:'Washing Machine', unread:false },
];

export default function DashMessages() {
  const [msgs, setMsgs] = useState(MSGS);
  return (
    <div className="dash-card full">
      <div className="card-header"><h4>Contact Form Messages</h4></div>
      <div className="messages-list">
        {msgs.map((m,i) => (
          <div key={i} className={`msg-item ${m.unread?'unread':''}`} onClick={()=>setMsgs(p=>p.map((x,j)=>j===i?{...x,unread:false}:x))}>
            <div className="msg-avatar">{m.name.charAt(0)}</div>
            <div className="msg-body">
              <div className="msg-top"><strong>{m.name}</strong><span>{m.date}</span></div>
              <p>{m.text}</p>
              <span className="msg-device">{m.device}</span>
            </div>
            {m.unread && <span className="unread-dot"></span>}
          </div>
        ))}
      </div>
    </div>
  );
}
