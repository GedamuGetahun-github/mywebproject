import React, { useState, useEffect, useRef } from 'react';

function seedActivity() {
  const data = {};
  const today = new Date();
  for (let i = 364; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const chance = i < 30 ? 0.75 : i < 90 ? 0.55 : 0.35;
    if (Math.random() < chance) data[key] = Math.floor(Math.random() * 80) + 10;
  }
  return data;
}

function loadActivity() {
  const s = localStorage.getItem('gedamu_reading_activity');
  return s ? JSON.parse(s) : seedActivity();
}

export default function ReadingCalendar() {
  const [activity, setActivity] = useState(loadActivity);
  const [tooltip, setTooltip]   = useState(null);
  const tooltipRef              = useRef();

  function save(a) { localStorage.setItem('gedamu_reading_activity', JSON.stringify(a)); }

  function logDay(key, val) {
    const pct = prompt(`Log reading % for ${key} (0–100):`, val || 0);
    if (pct === null) return;
    const num = Math.min(100, Math.max(0, parseInt(pct) || 0));
    const updated = { ...activity };
    if (num === 0) delete updated[key]; else updated[key] = num;
    setActivity(updated); save(updated);
  }

  // Build 52-week grid
  const today = new Date();
  const start = new Date(today);
  start.setDate(start.getDate() - 364);
  while (start.getDay() !== 0) start.setDate(start.getDate() - 1);

  const cells = [];
  const monthLabels = [];
  let col = 0, lastMonth = -1;
  const cur = new Date(start);

  while (cur <= today) {
    const key   = cur.toISOString().slice(0, 10);
    const val   = activity[key] || 0;
    const level = val === 0 ? 0 : val < 25 ? 1 : val < 50 ? 2 : val < 75 ? 3 : 4;
    const isToday = key === today.toISOString().slice(0, 10);

    if (cur.getDay() === 0) {
      if (cur.getMonth() !== lastMonth) {
        monthLabels.push({ col, label: cur.toLocaleString('default', { month: 'short' }) });
        lastMonth = cur.getMonth();
      }
      col++;
    }

    cells.push({ key, val, level, isToday });
    cur.setDate(cur.getDate() + 1);
  }

  const levelColors = ['#f1f5f9','#bbf7d0','#4ade80','#16a34a','#166534'];

  return (
    <div className="dash-card full" style={{ marginBottom:'1.5rem', overflowX:'auto' }}>
      <div className="card-header">
        <h4>Reading Activity Calendar</h4>
        <div style={{ display:'flex', alignItems:'center', gap:'0.4rem', fontSize:'0.75rem', color:'#94a3b8' }}>
          Less {levelColors.map((c,i) => <div key={i} style={{ width:12, height:12, borderRadius:3, background:c, display:'inline-block' }}></div>)} More
        </div>
      </div>

      {/* Month labels */}
      <div style={{ display:'flex', paddingLeft:28, marginBottom:4 }}>
        {monthLabels.map((m,i) => (
          <span key={i} style={{ flex:1, fontSize:'0.7rem', color:'#94a3b8' }}>{m.label}</span>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display:'flex', gap:6, alignItems:'flex-start' }}>
        <div style={{ display:'flex', flexDirection:'column', gap:3, paddingTop:2 }}>
          {['Mon','Wed','Fri'].map(d => <span key={d} style={{ fontSize:'0.65rem', color:'#94a3b8', height:13, lineHeight:'13px' }}>{d}</span>)}
        </div>
        <div style={{ display:'grid', gridTemplateRows:'repeat(7,13px)', gridAutoFlow:'column', gap:3 }}>
          {cells.map(c => (
            <div
              key={c.key}
              title={`${c.key}: ${c.val > 0 ? c.val + '% read' : 'No reading'}`}
              onClick={() => logDay(c.key, c.val)}
              style={{
                width:13, height:13, borderRadius:3,
                background: levelColors[c.level],
                cursor:'pointer',
                outline: c.isToday ? '2px solid #f97316' : 'none',
                transition:'transform 0.15s',
              }}
              onMouseEnter={e => { e.target.style.transform = 'scale(1.4)'; setTooltip({ key:c.key, val:c.val }); }}
              onMouseLeave={e => { e.target.style.transform = 'scale(1)'; setTooltip(null); }}
            />
          ))}
        </div>
      </div>
      {tooltip && (
        <div style={{ marginTop:'0.5rem', fontSize:'0.78rem', color:'#64748b' }}>
          {tooltip.key}: {tooltip.val > 0 ? `${tooltip.val}% read` : 'No reading'}
        </div>
      )}
    </div>
  );
}
