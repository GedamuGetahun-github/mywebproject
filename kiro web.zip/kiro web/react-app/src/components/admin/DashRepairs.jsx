import React, { useState } from 'react';

const INITIAL = [
  { id:'J-024', name:'Abebe Girma',  device:'Samsung TV',      issue:'No power',     tech:'Getahun', status:'Completed',   cost:850,  date:'Apr 12' },
  { id:'J-023', name:'Fatuma Ali',   device:'iPhone 13',       issue:'Cracked screen',tech:'Biruk',  status:'In Progress', cost:600,  date:'Apr 13' },
  { id:'J-022', name:'Tadesse B.',   device:'HP Laptop',       issue:"Won't boot",   tech:'Getahun', status:'Pending',     cost:0,    date:'Apr 13' },
  { id:'J-021', name:'Meron Haile',  device:'Washing Machine', issue:'Not spinning', tech:'Biruk',   status:'Completed',   cost:1200, date:'Apr 11' },
  { id:'J-020', name:'Dawit Tesfaye',device:'Epson Printer',   issue:'Paper jam',    tech:'Getahun', status:'In Progress', cost:300,  date:'Apr 14' },
];

const sc = s => s==='Completed'?'completed':s==='In Progress'?'progress':'pending';

export default function DashRepairs() {
  const [jobs, setJobs]   = useState(INITIAL);
  const [query, setQuery] = useState('');
  const [modal, setModal] = useState(false);
  const [form, setForm]   = useState({});

  const filtered = jobs.filter(j =>
    Object.values(j).join(' ').toLowerCase().includes(query.toLowerCase())
  );

  function addJob(e) {
    e.preventDefault();
    setJobs(prev => [{ ...form, id:`J-0${prev.length+25}`, status:'Pending', date:new Date().toLocaleDateString('en-US',{month:'short',day:'numeric'}) }, ...prev]);
    setModal(false); setForm({});
  }

  return (
    <>
      <div className="section-toolbar">
        <input className="search-input" placeholder="Search jobs..." value={query} onChange={e=>setQuery(e.target.value)}/>
        <button className="add-btn" onClick={()=>setModal(true)}><i className="fas fa-plus"></i> New Job</button>
      </div>
      <div className="dash-card full">
        <table className="data-table">
          <thead><tr><th>#</th><th>Customer</th><th>Device</th><th>Issue</th><th>Tech</th><th>Status</th><th>Cost</th><th>Date</th></tr></thead>
          <tbody>
            {filtered.map(j => (
              <tr key={j.id}>
                <td>{j.id}</td><td>{j.name}</td><td>{j.device}</td><td>{j.issue}</td><td>{j.tech}</td>
                <td><span className={`status ${sc(j.status)}`}>{j.status}</span></td>
                <td>{j.cost || '—'}</td><td>{j.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="modal-overlay active" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
          <div className="modal-box">
            <div className="modal-head"><h4>New Repair Job</h4><button onClick={()=>setModal(false)}><i className="fas fa-times"></i></button></div>
            <form onSubmit={addJob}>
              {['Customer Name','Device','Issue'].map(f => (
                <div className="mform-group" key={f}>
                  <label>{f}</label>
                  <input required placeholder={f} onChange={e=>setForm(p=>({...p,[f.toLowerCase().replace(' ','_')]:e.target.value}))}/>
                </div>
              ))}
              <div className="mform-group"><label>Technician</label>
                <select onChange={e=>setForm(p=>({...p,tech:e.target.value}))}>
                  <option>Getahun</option><option>Biruk</option>
                </select>
              </div>
              <button type="submit" className="add-btn full">Add Job</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
