import React, { useEffect, useRef } from 'react';
import { Chart } from 'chart.js/auto';

const STATS = [
  { label:'Total Repairs',  val:124, color:'blue',   icon:'fa-tools' },
  { label:'Completed',      val:98,  color:'green',  icon:'fa-check-circle' },
  { label:'In Progress',    val:18,  color:'orange', icon:'fa-clock' },
  { label:'Pending',        val:8,   color:'red',    icon:'fa-hourglass-half' },
  { label:'Customers',      val:87,  color:'purple', icon:'fa-users' },
  { label:'Revenue (Month)',val:'42,500 ETB', color:'teal', icon:'fa-coins' },
];

const RECENT = [
  { id:'J-024', customer:'Abebe Girma',  device:'Samsung TV',      status:'Completed',   date:'Apr 12' },
  { id:'J-023', customer:'Fatuma Ali',   device:'iPhone 13',       status:'In Progress', date:'Apr 13' },
  { id:'J-022', customer:'Tadesse B.',   device:'HP Laptop',       status:'Pending',     date:'Apr 13' },
  { id:'J-021', customer:'Meron Haile',  device:'Washing Machine', status:'Completed',   date:'Apr 11' },
  { id:'J-020', customer:'Dawit Tesfaye',device:'Epson Printer',   status:'In Progress', date:'Apr 14' },
];

function DonutChart({ id, labels, data, colors, title, badge }) {
  const ref = useRef();
  useEffect(() => {
    const ctx = ref.current.getContext('2d');
    const chart = new Chart(ctx, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 2, borderColor:'#fff', hoverOffset:8 }] },
      options: { cutout:'68%', plugins:{ legend:{ display:false } }, animation:{ duration:900 } }
    });
    return () => chart.destroy();
  }, []);

  const total = data.reduce((a,b)=>a+b,0);
  return (
    <div className="dash-card chart-card">
      <div className="card-header">
        <h4>{title}</h4>
        <span className="chart-badge">{badge}</span>
      </div>
      <div className="chart-wrap"><canvas ref={ref}></canvas></div>
      <div className="chart-legend">
        {labels.map((l,i) => (
          <div className="legend-item" key={l}>
            <div className="legend-dot" style={{ background:colors[i] }}></div>
            <span>{l}: <strong>{data[i]}</strong> ({Math.round(data[i]/total*100)}%)</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const statusClass = s => s==='Completed'?'completed':s==='In Progress'?'progress':'pending';

export default function DashOverview() {
  return (
    <>
      <div className="stats-grid">
        {STATS.map(s => (
          <div className={`stat-card ${s.color}`} key={s.label}>
            <div className="stat-icon"><i className={`fas ${s.icon}`}></i></div>
            <div className="stat-info"><h3>{s.val}</h3><p>{s.label}</p></div>
          </div>
        ))}
      </div>

      <div className="dash-row" style={{ marginTop:'1.5rem' }}>
        <div className="dash-card wide">
          <div className="card-header"><h4>Recent Repair Jobs</h4></div>
          <table className="data-table">
            <thead><tr><th>#</th><th>Customer</th><th>Device</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              {RECENT.map(r => (
                <tr key={r.id}>
                  <td>{r.id}</td><td>{r.customer}</td><td>{r.device}</td>
                  <td><span className={`status ${statusClass(r.status)}`}>{r.status}</span></td>
                  <td>{r.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="charts-row" style={{ marginTop:'1.5rem' }}>
        <DonutChart id="status" title="Repair Status" badge="124 total"
          labels={['Completed','In Progress','Pending']} data={[98,18,8]}
          colors={['#10b981','#3b82f6','#f59e0b']} />
        <DonutChart id="services" title="Service Distribution" badge="124 jobs"
          labels={['TV','Laptop','Mobile','Appliance','Printer','Power']} data={[36,29,25,17,12,5]}
          colors={['#3b82f6','#10b981','#f97316','#8b5cf6','#ec4899','#f59e0b']} />
        <DonutChart id="revenue" title="Revenue by Service" badge="56.4K ETB"
          labels={['TV','Laptop','Mobile','Appliance','Printer','Power']} data={[18500,12300,8750,9200,3600,4000]}
          colors={['#3b82f6','#10b981','#f97316','#8b5cf6','#ec4899','#f59e0b']} />
      </div>
    </>
  );
}
