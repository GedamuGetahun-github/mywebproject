import React, { useState } from 'react';
import ReadingCalendar from './ReadingCalendar';
import ProgressModal from './ProgressModal';

const DEFAULT_BOOKS = [
  { id:1,  title:'Atomic Habits',              author:'James Clear',     category:'Personal Development', progress:0 },
  { id:2,  title:'The Millionaire Fastlane',   author:'MJ DeMarco',      category:'Personal Finance',     progress:0 },
  { id:3,  title:'The Lean Startup',           author:'Eric Ries',       category:'Business',             progress:0 },
  { id:4,  title:'Limitless',                  author:'Jim Kwik',        category:'Personal Development', progress:0 },
  { id:5,  title:'The Courage to Be Disliked', author:'Ichiro Kishimi',  category:'Personal Development', progress:0 },
  { id:6,  title:'The Mountain Is You',        author:'Brianna Wiest',   category:'Personal Development', progress:0 },
  { id:7,  title:"Can't Hurt Me",              author:'David Goggins',   category:'Personal Development', progress:0 },
  { id:8,  title:'Rich Dad Poor Dad',          author:'Robert Kiyosaki', category:'Personal Finance',     progress:0 },
  { id:9,  title:'The Intelligent Investor',   author:'Benjamin Graham', category:'Investing',            progress:0 },
  { id:10, title:'Think and Grow Rich',        author:'Napoleon Hill',   category:'Personal Finance',     progress:0 },
  { id:11, title:'The Psychology of Money',    author:'Morgan Housel',   category:'Personal Finance',     progress:0 },
  { id:12, title:'Zero to One',                author:'Peter Thiel',     category:'Business',             progress:0 },
];

const COVERS = {
  'Atomic Habits':             'https://covers.openlibrary.org/b/isbn/9780735211292-M.jpg',
  'The Millionaire Fastlane':  'https://covers.openlibrary.org/b/isbn/9780984358106-M.jpg',
  'The Lean Startup':          'https://covers.openlibrary.org/b/isbn/9780307887894-M.jpg',
  'Limitless':                 'https://covers.openlibrary.org/b/isbn/9781401958237-M.jpg',
  'The Courage to Be Disliked':'https://covers.openlibrary.org/b/isbn/9781501197277-M.jpg',
  'The Mountain Is You':       'https://covers.openlibrary.org/b/isbn/9781949759228-M.jpg',
  "Can't Hurt Me":             'https://covers.openlibrary.org/b/isbn/9781544512273-M.jpg',
  'Rich Dad Poor Dad':         'https://covers.openlibrary.org/b/isbn/9781612680194-M.jpg',
  'The Intelligent Investor':  'https://covers.openlibrary.org/b/isbn/9780060555665-M.jpg',
  'Think and Grow Rich':       'https://covers.openlibrary.org/b/isbn/9781585424337-M.jpg',
  'The Psychology of Money':   'https://covers.openlibrary.org/b/isbn/9780857197689-M.jpg',
  'Zero to One':               'https://covers.openlibrary.org/b/isbn/9780804139021-M.jpg',
};

const COLORS = ['#3b82f6','#10b981','#f97316','#8b5cf6','#f43f5e','#0ea5e9','#facc15','#ec4899'];

function load() {
  const s = JSON.parse(localStorage.getItem('gedamu_books') || 'null');
  if (!s || !s.some(b=>b.title==='Atomic Habits')) {
    localStorage.setItem('gedamu_books', JSON.stringify(DEFAULT_BOOKS));
    return DEFAULT_BOOKS;
  }
  return s;
}

export default function DashStudy() {
  const [books, setBooks]     = useState(load);
  const [modal, setModal]     = useState(false);
  const [progBook, setProgBook] = useState(null);
  const [editId, setEditId]   = useState(null);
  const [form, setForm]       = useState({ title:'', author:'', category:'Personal Development', progress:0 });

  function save(b) { localStorage.setItem('gedamu_books', JSON.stringify(b)); }

  function addBook(e) {
    e.preventDefault();
    const updated = [...books, { ...form, id: Date.now(), progress: Number(form.progress) }];
    setBooks(updated); save(updated); setModal(false);
    setForm({ title:'', author:'', category:'Personal Development', progress:0 });
  }

  function updateProgress(id) {
    const book = books.find(b => b.id === id);
    if (book) setProgBook(book);
  }

  function handleProgressSave(updatedBook) {
    const updated = books.map(b => b.id === updatedBook.id ? updatedBook : b);
    setBooks(updated); save(updated);
  }

  function deleteBook(id) {
    if (!window.confirm('Remove this book?')) return;
    const updated = books.filter(b=>b.id!==id);
    setBooks(updated); save(updated);
  }

  const total     = books.length;
  const completed = books.filter(b=>b.progress===100).length;
  const reading   = books.filter(b=>b.progress>0&&b.progress<100).length;
  const notStarted= books.filter(b=>b.progress===0).length;
  const overall   = total ? Math.round(books.reduce((s,b)=>s+b.progress,0)/total) : 0;

  return (
    <>
      <div className="stats-grid" style={{ gridTemplateColumns:'repeat(4,minmax(160px,200px))', justifyContent:'flex-start' }}>
        {[
          { label:'Total Books',  val:total,      color:'blue',   icon:'fa-book' },
          { label:'Completed',    val:completed,  color:'green',  icon:'fa-check-circle' },
          { label:'In Progress',  val:reading,    color:'orange', icon:'fa-spinner' },
          { label:'Not Started',  val:notStarted, color:'purple', icon:'fa-hourglass-start' },
        ].map(s => (
          <div className={`stat-card ${s.color}`} key={s.label}>
            <div className="stat-icon"><i className={`fas ${s.icon}`}></i></div>
            <div className="stat-info"><h3>{s.val}</h3><p>{s.label}</p></div>
          </div>
        ))}
      </div>

      {/* Overall bar */}
      <div className="dash-card full" style={{ margin:'1rem 0 1.5rem' }}>
        <div className="card-header">
          <h4>Overall Reading Progress</h4>
          <span style={{ fontWeight:700, color:'#f97316' }}>{overall}%</span>
        </div>
        <div className="overall-bar-wrap"><div className="overall-bar" style={{ width:`${overall}%` }}></div></div>
      </div>

      <ReadingCalendar />

      {/* Book list */}
      <div className="dash-card full">        <div className="card-header">
          <h4>Book List</h4>
          <button className="add-btn" onClick={()=>setModal(true)}><i className="fas fa-plus"></i> Add Book</button>
        </div>
        <div className="book-list">
          {books.map((b,i) => {
            const color    = COLORS[i % COLORS.length];
            const cover    = COVERS[b.title];
            const status   = b.progress===100?'done':b.progress>0?'reading':'notstarted';
            const label    = b.progress===100?'Completed':b.progress>0?'Reading':'Not Started';
            const barColor = b.progress===100?'#10b981':b.progress>0?'#3b82f6':'#e2e8f0';
            return (
              <div className="book-item" key={b.id}>
                <div className="book-cover" style={{ background:color, overflow:'hidden', padding:0 }}>
                  {cover
                    ? <img src={cover} alt={b.title} style={{ width:'100%', height:'100%', objectFit:'cover', borderRadius:6 }} onError={e=>{ e.target.style.display='none'; }}/>
                    : '📚'}
                </div>
                <div className="book-info">
                  <h4>{b.title}</h4>
                  <div className="book-meta">
                    <span><i className="fas fa-user"></i> {b.author}</span>
                    <span><i className="fas fa-tag"></i> {b.category}</span>
                  </div>
                  <div className="book-progress-wrap">
                    <div className="book-bar-bg"><div className="book-bar" style={{ width:`${b.progress}%`, background:barColor }}></div></div>
                    <span className="book-pct" style={{ color:barColor }}>{b.progress}%</span>
                  </div>
                </div>
                <span className={`book-status ${status}`}>{label}</span>
                <div className="book-actions">
                  <button title="Edit" onClick={()=>updateProgress(b.id)}><i className="fas fa-edit"></i></button>
                  <button title="Delete" style={{ color:'#ef4444' }} onClick={()=>deleteBook(b.id)}><i className="fas fa-trash"></i></button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Book Modal */}
      {modal && (        <div className="modal-overlay active" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
          <div className="modal-box">
            <div className="modal-head"><h4>Add Book</h4><button onClick={()=>setModal(false)}><i className="fas fa-times"></i></button></div>
            <form onSubmit={addBook}>
              <div className="mform-group"><label>Title</label><input required value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="Book title"/></div>
              <div className="mform-group"><label>Author</label><input value={form.author} onChange={e=>setForm(f=>({...f,author:e.target.value}))} placeholder="Author name"/></div>
              <div className="mform-group"><label>Category</label>
                <select value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}>
                  {['Personal Development','Personal Finance','Investing','Business','Accounting','Economics','Banking','Other'].map(c=><option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="mform-group">
                <label>Progress: {form.progress}%</label>
                <input type="range" min="0" max="100" value={form.progress} onChange={e=>setForm(f=>({...f,progress:e.target.value}))} style={{ width:'100%', accentColor:'#f97316' }}/>
              </div>
              <button type="submit" className="add-btn full">Add Book</button>
            </form>
          </div>
        </div>
      )}
      {progBook && <ProgressModal book={progBook} onSave={b => { handleProgressSave(b); setProgBook(null); }} onClose={() => setProgBook(null)} />}
    </>
  );
}
