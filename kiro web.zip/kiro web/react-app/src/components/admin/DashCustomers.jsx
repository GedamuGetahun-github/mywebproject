import React, { useState } from 'react';

const DATA = [
  { id:'C-001', name:'Abebe Girma',   phone:'+251 91 111 2233', jobs:3, last:'Apr 12', paid:'2,350' },
  { id:'C-002', name:'Fatuma Ali',    phone:'+251 92 444 5566', jobs:1, last:'Apr 13', paid:'600' },
  { id:'C-003', name:'Tadesse Bekele',phone:'+251 93 777 8899', jobs:2, last:'Apr 13', paid:'1,100' },
  { id:'C-004', name:'Meron Haile',   phone:'+251 94 222 3344', jobs:4, last:'Apr 11', paid:'3,800' },
  { id:'C-005', name:'Dawit Tesfaye', phone:'+251 95 555 6677', jobs:2, last:'Apr 14', paid:'900' },
];

export default function DashCustomers() {
  const [q, setQ] = useState('');
  const filtered = DATA.filter(c => `${c.name} ${c.phone}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <div className="section-toolbar">
        <input className="search-input" placeholder="Search customers..." value={q} onChange={e=>setQ(e.target.value)}/>
      </div>
      <div className="dash-card full">
        <table className="data-table">
          <thead><tr><th>#</th><th>Name</th><th>Phone</th><th>Jobs</th><th>Last Visit</th><th>Total Paid (ETB)</th></tr></thead>
          <tbody>
            {filtered.map(c => (
              <tr key={c.id}><td>{c.id}</td><td>{c.name}</td><td>{c.phone}</td><td>{c.jobs}</td><td>{c.last}</td><td>{c.paid}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
