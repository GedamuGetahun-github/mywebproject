import React, { useState } from 'react';

export default function DashFeedback() {
  const [reviews, setReviews] = useState(() =>
    JSON.parse(localStorage.getItem('gedamu_reviews') || '[]')
  );
  const [q, setQ] = useState('');

  const total    = reviews.length;
  const avg      = total ? (reviews.reduce((s,r)=>s+r.rating,0)/total).toFixed(1) : '0.0';
  const positive = reviews.filter(r=>r.rating>=4).length;
  const negative = reviews.filter(r=>r.rating<=3).length;

  function del(i) {
    if (!window.confirm('Delete this review?')) return;
    const updated = reviews.filter((_,j)=>j!==i);
    setReviews(updated);
    localStorage.setItem('gedamu_reviews', JSON.stringify(updated));
  }

  const filtered = reviews.filter(r =>
    `${r.name} ${r.text} ${r.service}`.toLowerCase().includes(q.toLowerCase())
  );

  const stars = n => [1,2,3,4,5].map(i=>`<i class="fa${i<=n?'s':'r'} fa-star" style="color:#facc15"></i>`).join('');

  return (
    <>
      <div className="stats-grid" style={{ gridTemplateColumns:'repeat(4,minmax(160px,200px))', justifyContent:'flex-start' }}>
        {[
          { label:'Avg Rating',        val:avg,      color:'yellow', icon:'fa-star' },
          { label:'Total Reviews',     val:total,    color:'green',  icon:'fa-comments' },
          { label:'Positive (4-5★)',   val:positive, color:'blue',   icon:'fa-thumbs-up' },
          { label:'Needs Attention',   val:negative, color:'red',    icon:'fa-thumbs-down' },
        ].map(s => (
          <div className={`stat-card ${s.color}`} key={s.label}>
            <div className="stat-icon"><i className={`fas ${s.icon}`}></i></div>
            <div className="stat-info"><h3>{s.val}</h3><p>{s.label}</p></div>
          </div>
        ))}
      </div>
      <div className="dash-card full" style={{ marginTop:'1.5rem' }}>
        <div className="card-header">
          <h4>All Customer Reviews</h4>
          <input className="search-input" style={{ maxWidth:220 }} placeholder="Search reviews..." value={q} onChange={e=>setQ(e.target.value)}/>
        </div>
        <div className="admin-reviews-list">
          {filtered.length === 0 && <p style={{ padding:'1rem', color:'#94a3b8' }}>No reviews yet.</p>}
          {[...filtered].reverse().map((r,i) => (
            <div className="admin-review-row" key={i}>
              <div className="arv-avatar">{r.name.charAt(0)}</div>
              <div className="arv-body">
                <div className="arv-top"><span className="arv-name">{r.name}</span><span className="arv-date">{r.date}</span></div>
                <div className="arv-stars" dangerouslySetInnerHTML={{ __html: stars(r.rating) }}/>
                {r.service && <span className="arv-service">{r.service}</span>}
                <p className="arv-text">{r.text}</p>
              </div>
              <button className="arv-del" onClick={()=>del(reviews.length-1-i)}><i className="fas fa-trash"></i></button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
