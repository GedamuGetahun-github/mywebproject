import React, { useState } from 'react';

export default function ProgressModal({ book, onSave, onClose }) {
  const [activeTab, setActiveTab] = useState('slider');
  const [sliderVal, setSliderVal] = useState(book.progress);
  const [totalPages, setTotalPages] = useState(book.totalPages || '');
  const [pagesRead, setPagesRead]   = useState(book.pagesRead  || '');
  const [hours, setHours]           = useState('');
  const [calDate, setCalDate]       = useState(new Date().toISOString().slice(0,10));
  const [calPct, setCalPct]         = useState(book.progress);
  const [calNote, setCalNote]       = useState('');
  const [calLog, setCalLog]         = useState(book.calLog || []);
  const [saved, setSaved]           = useState('');

  const pagesCalc = totalPages && pagesRead >= 0
    ? Math.min(100, Math.round(pagesRead / totalPages * 100)) : null;

  function save(mode) {
    let newPct = book.progress;
    let updatedBook = { ...book };

    if (mode === 'slider') {
      newPct = sliderVal;
      if (book.totalPages) updatedBook.pagesRead = Math.round(book.totalPages * newPct / 100);
    } else if (mode === 'hours') {
      if (pagesCalc !== null) newPct = pagesCalc;
      updatedBook.totalPages = parseInt(totalPages) || book.totalPages;
      updatedBook.pagesRead  = parseInt(pagesRead)  || book.pagesRead;
      if (hours) {
        updatedBook.hoursLog = [...(book.hoursLog || []), { date: new Date().toISOString().slice(0,10), hours: parseFloat(hours) }];
      }
    } else if (mode === 'calendar') {
      newPct = calPct;
      const newLog = [...calLog.filter(e => e.date !== calDate), { date:calDate, pct:calPct, note:calNote }]
        .sort((a,b) => b.date.localeCompare(a.date));
      setCalLog(newLog);
      updatedBook.calLog = newLog;
      // sync reading activity
      const act = JSON.parse(localStorage.getItem('gedamu_reading_activity') || '{}');
      act[calDate] = calPct;
      localStorage.setItem('gedamu_reading_activity', JSON.stringify(act));
      setCalNote('');
    }

    updatedBook.progress = newPct;
    onSave(updatedBook);
    setSaved('✅ Saved!');
    setTimeout(() => setSaved(''), 1500);
  }

  const tabs = [
    { id:'slider',   icon:'fa-sliders-h',    label:'Slider' },
    { id:'hours',    icon:'fa-clock',         label:'By Hours' },
    { id:'calendar', icon:'fa-calendar-alt',  label:'Calendar' },
  ];

  return (
    <div className="modal-overlay active" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box" style={{ maxWidth:500 }}>
        <div className="modal-head">
          <h4>📖 {book.title}</h4>
          <button onClick={onClose}><i className="fas fa-times"></i></button>
        </div>

        {/* Tabs */}
        <div className="prog-tabs">
          {tabs.map(t => (
            <button key={t.id} className={`prog-tab ${activeTab===t.id?'active':''}`} onClick={() => setActiveTab(t.id)}>
              <i className={`fas ${t.icon}`}></i> {t.label}
            </button>
          ))}
        </div>

        <div className="prog-book-info">{book.title} — {book.author} | Current: {book.progress}%</div>

        {/* Slider */}
        {activeTab === 'slider' && (
          <div>
            <div className="mform-group">
              <label>Progress: <strong style={{ color:'#f97316' }}>{sliderVal}%</strong></label>
              <input type="range" min="0" max="100" value={sliderVal} onChange={e => setSliderVal(+e.target.value)} style={{ width:'100%', accentColor:'#f97316', marginTop:'0.5rem' }}/>
            </div>
            <div className="prog-quick-btns">
              {[25,50,75,100].map(v => <button key={v} onClick={() => setSliderVal(v)}>{v === 100 ? '100% ✅' : `${v}%`}</button>)}
            </div>
            <button className="add-btn full" onClick={() => save('slider')}>{saved || 'Save Progress'}</button>
          </div>
        )}

        {/* Hours */}
        {activeTab === 'hours' && (
          <div>
            <div className="mform-group"><label>Total pages in book</label><input type="number" value={totalPages} onChange={e => setTotalPages(e.target.value)} placeholder="e.g. 320"/></div>
            <div className="mform-group"><label>Pages read so far</label><input type="number" value={pagesRead} onChange={e => setPagesRead(e.target.value)} placeholder="e.g. 120"/></div>
            {pagesCalc !== null && <div style={{ background:'#f0fdf4', border:'1px solid #bbf7d0', borderRadius:8, padding:'0.6rem', fontSize:'0.82rem', color:'#166534', marginBottom:'0.8rem' }}>📊 {pagesRead} / {totalPages} pages = {pagesCalc}%</div>}
            <div className="mform-group"><label>Hours spent today</label><input type="number" value={hours} onChange={e => setHours(e.target.value)} placeholder="e.g. 2" min="0" max="24" step="0.5"/></div>
            <button className="add-btn full" onClick={() => save('hours')}>{saved || 'Log & Save'}</button>
          </div>
        )}

        {/* Calendar */}
        {activeTab === 'calendar' && (
          <div>
            <div className="mform-group"><label>Select reading date</label><input type="date" value={calDate} onChange={e => setCalDate(e.target.value)} style={{ width:'100%', padding:'0.65rem', border:'1.5px solid #e2e8f0', borderRadius:8, fontSize:'0.9rem', outline:'none' }}/></div>
            <div className="mform-group">
              <label>Progress on that date: <strong style={{ color:'#f97316' }}>{calPct}%</strong></label>
              <input type="range" min="0" max="100" value={calPct} onChange={e => setCalPct(+e.target.value)} style={{ width:'100%', accentColor:'#f97316', marginTop:'0.5rem' }}/>
            </div>
            <div className="mform-group"><label>Note (optional)</label><input value={calNote} onChange={e => setCalNote(e.target.value)} placeholder="e.g. Finished chapter 5"/></div>

            {calLog.length > 0 && (
              <div style={{ maxHeight:140, overflowY:'auto', marginBottom:'0.8rem' }}>
                <p style={{ fontSize:'0.72rem', fontWeight:700, color:'#94a3b8', textTransform:'uppercase', letterSpacing:1, marginBottom:'0.4rem' }}>History</p>
                {calLog.map((e,i) => (
                  <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'0.4rem 0.6rem', borderBottom:'1px solid #f1f5f9', fontSize:'0.8rem' }}>
                    <span style={{ color:'#64748b' }}>{e.date}</span>
                    <span style={{ color:'#94a3b8', flex:1, margin:'0 0.5rem', fontStyle:'italic' }}>{e.note}</span>
                    <span style={{ fontWeight:700, color:'#f97316' }}>{e.pct}%</span>
                  </div>
                ))}
              </div>
            )}
            <button className="add-btn full" onClick={() => save('calendar')}>{saved || 'Log Date Entry'}</button>
          </div>
        )}
      </div>
    </div>
  );
}
