import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

function SocialAuthOverlay({ provider, action, onClose }) {
  const [step, setStep] = useState('loading');
  const label = provider === 'google' ? 'Google' : 'Facebook';

  React.useEffect(() => {
    const t = setTimeout(() => setStep('info'), 1800);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="social-overlay active" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="social-popup">
        {step === 'loading' ? (
          <>
            <div className="social-spinner" style={{ borderTopColor: provider === 'google' ? '#ea4335' : '#1877f2' }}></div>
            <p>{action === 'signin' ? 'Signing in' : 'Creating account'} with {label}...</p>
            <small>Please wait while we connect securely.</small>
          </>
        ) : (
          <>
            <div style={{ fontSize:'2.5rem', marginBottom:'0.8rem' }}>
              <i className="fas fa-exclamation-circle" style={{ color:'#f97316' }}></i>
            </div>
            <p style={{ fontWeight:700, color:'#1a1a2e' }}>Backend Required</p>
            <small style={{ lineHeight:1.6 }}>
              Real {label} login requires server-side OAuth.<br/><br/>
              <strong>To activate:</strong><br/>
              {provider === 'google'
                ? <>1. <a href="https://console.cloud.google.com" target="_blank" rel="noopener" style={{ color:'#f97316' }}>Google Cloud Console</a><br/>2. Enable Google Identity API<br/>3. Add Client ID to config.js</>
                : <>1. <a href="https://developers.facebook.com" target="_blank" rel="noopener" style={{ color:'#f97316' }}>Facebook Developers</a><br/>2. Enable Facebook Login<br/>3. Add App ID to config.js</>
              }
            </small>
            <button onClick={onClose} className="btn" style={{ marginTop:'1rem', padding:'0.5rem 1.5rem', fontSize:'0.85rem' }}>Close</button>
          </>
        )}
      </div>
    </div>
  );
}

export default function AuthModal() {
  const { authModal, closeModal, signin, signup } = useAuth();
  const [tab, setTab]       = useState(authModal.tab);
  const [form, setForm]     = useState({});
  const [msg, setMsg]       = useState({ text: '', color: '' });

  const [socialAuth, setSocialAuth] = useState(null); // { provider, action }

  if (!authModal.open) return null;

  function update(e) { setForm(f => ({ ...f, [e.target.name]: e.target.value })); }

  async function handleSubmit(e) {
    e.preventDefault();
    setMsg({ text: '', color: '' });
    try {
      if (tab === 'signup') {
        if (form.password !== form.confirm) { setMsg({ text: '⚠️ Passwords do not match.', color: '#ef4444' }); return; }
        if ((form.password || '').length < 6) { setMsg({ text: '⚠️ Password must be at least 6 characters.', color: '#ef4444' }); return; }
        signup(form.name, form.email, form.password);
        setMsg({ text: `✅ Welcome ${form.name}!`, color: '#10b981' });
      } else {
        signin(form.email, form.password);
        setMsg({ text: '✅ Welcome back!', color: '#10b981' });
      }
      setTimeout(() => {
        closeModal();
        if (window.__showWelcomeToast) {
          window.__showWelcomeToast(JSON.parse(sessionStorage.getItem('gedamu_user')), tab);
        }
      }, 1800);
    } catch (err) {
      setMsg({ text: `⚠️ ${err.message}`, color: '#ef4444' });
    }
  }

  return (
    <>
    <div className="modal-overlay active" onClick={e => e.target === e.currentTarget && closeModal()}>
      <div className="modal">
        <button className="modal-close" onClick={closeModal}><i className="fas fa-times"></i></button>
        <div className="modal-logo"><i className="fas fa-bolt"></i> Gedamu Electronics</div>

        <div className="auth-tabs">
          {['signin','signup'].map(t => (
            <button key={t} className={`tab-btn ${tab === t ? 'active' : ''}`} onClick={() => { setTab(t); setMsg({}); }}>
              {t === 'signin' ? 'Sign In' : 'Sign Up'}
            </button>
          ))}
        </div>

        {/* Social buttons */}
        <button type="button" className="social-btn google-btn" onClick={() => setSocialAuth({ provider:'google', action:tab })}>
          <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google" width="20"/>
          {tab === 'signin' ? 'Continue' : 'Sign up'} with Google
        </button>
        <button type="button" className="social-btn facebook-btn" style={{ marginTop:'0.6rem' }} onClick={() => setSocialAuth({ provider:'facebook', action:tab })}>
          <i className="fab fa-facebook" style={{ color:'#1877f2', fontSize:'1.2rem' }}></i>
          {tab === 'signin' ? 'Continue' : 'Sign up'} with Facebook
        </button>
        <div className="divider"><span>or {tab === 'signin' ? 'sign in' : 'sign up'} with email</span></div>

        <form className="auth-form" onSubmit={handleSubmit}>
          {tab === 'signup' && (
            <div className="form-group">
              <i className="fas fa-user"></i>
              <input name="name" type="text" placeholder="Full name" required onChange={update}/>
            </div>
          )}
          <div className="form-group">
            <i className="fas fa-envelope"></i>
            <input name="email" type="email" placeholder="Email address" required onChange={update}/>
          </div>
          <div className="form-group">
            <i className="fas fa-lock"></i>
            <input name="password" type="password" placeholder="Password" required onChange={update}/>
          </div>
          {tab === 'signup' && (
            <>
              <div className="form-group">
                <i className="fas fa-lock"></i>
                <input name="confirm" type="password" placeholder="Confirm password" required onChange={update}/>
              </div>
              <div className="terms-check">
                <input type="checkbox" id="terms" required/>
                <label htmlFor="terms">I agree to the <a href="/privacy" target="_blank">Terms & Privacy Policy</a></label>
              </div>
            </>
          )}
          <button type="submit" className="btn full-btn">
            {tab === 'signin' ? 'Sign In' : 'Create Account'}
          </button>
          {msg.text && <p className="auth-msg" style={{ color: msg.color }}>{msg.text}</p>}
        </form>
      </div>
    </div>
    {socialAuth && <SocialAuthOverlay provider={socialAuth.provider} action={socialAuth.action} onClose={() => setSocialAuth(null)} />}
    </>
  );
}
