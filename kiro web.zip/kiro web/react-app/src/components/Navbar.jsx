import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useLang } from '../context/LangContext';
import MyRepairs from './MyRepairs';
import WelcomeToast from './WelcomeToast';

const SERVICES = [
  { title:'TV Repair',           icon:'fa-tv',          href:'/services/tv-repair' },
  { title:'Laptop & PC',         icon:'fa-laptop',      href:'/services/laptop-pc' },
  { title:'Mobile Phones',       icon:'fa-mobile-alt',  href:'/services/mobile-phones' },
  { title:'Home Appliances',     icon:'fa-blender',     href:'/services/home-appliances' },
  { title:'Printers & Scanners', icon:'fa-print',       href:'/services/printers' },
  { title:'Power Systems',       icon:'fa-car-battery', href:'/services/power-systems' },
];

export default function Navbar() {
  const { user, openModal, logout } = useAuth();
  const { toggleTheme, icon }       = useTheme();
  const { lang, t, changeLang }     = useLang();
  const [menuOpen, setMenuOpen]     = useState(false);
  const [query, setQuery]           = useState('');
  const [results, setResults]       = useState([]);
  const [showRepairs, setShowRepairs] = useState(false);
  const [toast, setToast]           = useState(null);

  function handleSearch(q) {
    setQuery(q);
    if (!q.trim()) { setResults([]); return; }
    setResults(SERVICES.filter(s => s.title.toLowerCase().includes(q.toLowerCase())));
  }

  // expose toast trigger for AuthModal
  if (typeof window !== 'undefined') window.__showWelcomeToast = (u, type) => setToast({ user: u, type });

  return (
    <>
      <nav className="navbar">
        <div className="logo"><i className="fas fa-bolt"></i> Gedamu Electronics</div>

        <ul className={`nav-links ${menuOpen ? 'open' : ''}`}>
          <li><a href="#home"    onClick={() => setMenuOpen(false)}>{t('nav_home')}</a></li>
          <li><a href="#services"onClick={() => setMenuOpen(false)}>{t('nav_services')}</a></li>
          <li><a href="#about"   onClick={() => setMenuOpen(false)}>{t('nav_about')}</a></li>
          <li><a href="#contact" onClick={() => setMenuOpen(false)}>{t('nav_contact')}</a></li>
          {user && <li><a href="#" onClick={e=>{e.preventDefault();setShowRepairs(true);setMenuOpen(false);}} style={{color:'var(--primary)'}}><i className="fas fa-clipboard-list"></i> My Repairs</a></li>}
        </ul>

        {/* Search */}
        <div className="nav-search-box">
          <i className="fas fa-search"></i>
          <input value={query} onChange={e => handleSearch(e.target.value)} placeholder="Search services..."/>
          {query && <button className="nav-search-clear" onClick={() => handleSearch('')}><i className="fas fa-times"></i></button>}
          {results.length > 0 && (
            <div className="nav-search-dropdown open">
              {results.map(r => (
                <a key={r.title} className="nsd-item" href={r.href} onClick={() => handleSearch('')}>
                  <i className={`fas ${r.icon}`}></i><span>{r.title}</span>
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Theme toggle */}
        <button className="theme-toggle" onClick={toggleTheme} title="Toggle theme">
          <i className={`fas ${icon}`}></i>
        </button>

        {/* Lang switcher */}
        <div className="lang-switcher">
          {['en','am','or'].map(l => (
            <button key={l} className={`lang-btn ${lang===l?'active':''}`} onClick={() => changeLang(l)}>
              {l==='en'?'EN':l==='am'?'አማ':'OR'}
            </button>
          ))}
        </div>

        {/* Auth */}
        <div className="auth-buttons">
          {user ? (
            <>
              <span className="user-greeting"><i className="fas fa-user-circle"></i> {user.name}</span>
              <button className="btn-outline" onClick={() => setShowRepairs(true)}><i className="fas fa-clipboard-list"></i> My Repairs</button>
              <button className="btn-outline" onClick={logout}>Sign Out</button>
            </>
          ) : (
            <>
              <button className="btn-outline" onClick={() => openModal('signin')}>Sign In</button>
              <button className="btn" onClick={() => openModal('signup')}>Sign Up</button>
            </>
          )}
        </div>

        <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)}>
          <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
      </nav>

      {showRepairs && <MyRepairs onClose={() => setShowRepairs(false)} />}
      {toast && <WelcomeToast user={toast.user} type={toast.type} onDone={() => setToast(null)} />}
    </>
  );
}
