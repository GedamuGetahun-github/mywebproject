import React from 'react';

const stats = [
  { num: '5000+', label: 'Devices Repaired' },
  { num: '10+',   label: 'Years Experience' },
  { num: '98%',   label: 'Customer Satisfaction' },
  { num: '24/7',  label: 'Support Available' },
];

const features = [
  'Certified & Experienced Technicians',
  '90-Day Repair Warranty',
  'Genuine Spare Parts',
  'Same-Day Service Available',
];

export default function About() {
  return (
    <section className="about" id="about">
      <div className="about-content">
        <div className="about-text">
          <h2>About Us</h2>
          <p>Gedamu Electronics Maintenance has been serving customers with top-quality repair and maintenance services for over 10 years. Our certified technicians handle everything from small gadgets to large industrial equipment.</p>
          <ul>
            {features.map(f => (
              <li key={f}><i className="fas fa-check-circle"></i> <span>{f}</span></li>
            ))}
          </ul>
        </div>
        <div className="about-stats">
          {stats.map(s => (
            <div className="stat" key={s.label}>
              <h3>{s.num}</h3>
              <p>{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
