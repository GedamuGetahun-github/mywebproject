import React from 'react';
import { useAuth } from '../context/AuthContext';

const STATUS_COLOR = { Pending:'#f59e0b', 'In Progress':'#3b82f6', Completed:'#10b981' };
const STATUS_BG    = { Pending:'#fef9c3', 'In Progress':'#dbeafe', Completed:'#dcfce7' };

export default function MyRepairs({ onClose }) {
  const { user } = useAuth();
  if (!user) return null;

  const all      = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  const requests = all[user.email] || [];
  const total     = requests.length;
  const pending   = requests.filter(r => r.status === 'Pending').length;
  const progress  = requests.filter(r => r.status === 'In Progress').length;
  const completed = requests.filter(r => r.status === 'Completed').length;

  return (
    <div className="modal-overlay active" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal my-repairs-modal">
        <button className="modal-close" onClick={onClose}><i className="fas fa-times"></i></button>
        <div className="modal-logo"><i className="fas fa-clipboard-list"></i> My Repair Requests</div>

        <div className="my-repairs-stats">
          {[
            { icon:'fa-tools',        color:'#3b82f6', val:total,     label:'Total' },
            { icon:'fa-hourglass-half',color:'#f59e0b', val:pending,   label:'Pending' },
            { icon:'fa-spinner',      color:'#f97316', val:progress,  label:'In Progress' },
            { icon:'fa-check-circle', color:'#10b981', val:completed, label:'Completed' },
          ].map(s => (
            <div className="mr-stat" key={s.label}>
              <i className={`fas ${s.icon}`} style={{ color:s.color, fontSize:'1.2rem' }}></i>
              <span>{s.val}</span>
              <small>{s.label}</small>
            </div>
          ))}
        </div>

        <div className="my-repairs-list">
          {!requests.length ? (
            <div className="mr-empty">
              <i className="fas fa-inbox"></i>
              <p>No repair requests yet.<br/>Submit one below!</p>
            </div>
          ) : requests.map(r => (
            <div className="mr-card" key={r.id}>
              <div className="mr-card-top">
                <div>
                  <div className="mr-device"><i className="fas fa-microchip"></i> {r.device}</div>
                  <div className="mr-date"><i className="fas fa-calendar"></i> {r.date} &nbsp;|&nbsp; <i className="fas fa-bolt"></i> {r.urgency}</div>
                </div>
                <span className="mr-status" style={{ background:STATUS_BG[r.status], color:STATUS_COLOR[r.status] }}>{r.status}</span>
              </div>
              <div className="mr-problems"><i className="fas fa-exclamation-circle" style={{ color:'#f97316' }}></i> <strong>Issue:</strong> {r.problems}</div>
              <div className="mr-cost"><i className="fas fa-coins" style={{ color:'#facc15' }}></i> <strong>Estimated Cost:</strong> <span style={{ color:'#f97316', fontWeight:700 }}>{r.cost}</span></div>
              <div className="mr-id">Request ID: {r.id}</div>
            </div>
          ))}
        </div>

        <p style={{ textAlign:'center', marginTop:'1rem' }}>
          <a href="#contact" onClick={onClose} className="btn" style={{ fontSize:'0.85rem', padding:'0.6rem 1.5rem' }}>
            <i className="fas fa-plus"></i> New Repair Request
          </a>
        </p>
      </div>
    </div>
  );
}
