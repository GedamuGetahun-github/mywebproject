import React, { useState } from 'react';

const CHALLENGES = [
  { label:'Select all 🔧 tools',       pool:['🔧','📱','💻','🔧','📺','🔧','🖨️','⚡','🔧'], correct:'🔧' },
  { label:'Select all 📱 phones',      pool:['📱','🔧','💻','📱','📺','📱','🖨️','⚡','💻'], correct:'📱' },
  { label:'Select all ⚡ power icons', pool:['⚡','📱','💻','⚡','📺','⚡','🔧','🖨️','💻'], correct:'⚡' },
  { label:'Select all 💻 laptops',     pool:['💻','🔧','📱','💻','📺','💻','🖨️','⚡','📱'], correct:'💻' },
  { label:'Select all 📺 TVs',         pool:['📺','🔧','📱','📺','💻','📺','🖨️','⚡','📱'], correct:'📺' },
];

function randomChallenge() {
  const c = CHALLENGES[Math.floor(Math.random() * CHALLENGES.length)];
  return { ...c, pool: [...c.pool].sort(() => Math.random() - 0.5) };
}

export default function Captcha({ onVerified }) {
  const [open, setOpen]         = useState(false);
  const [verified, setVerified] = useState(false);
  const [challenge, setChallenge] = useState(randomChallenge);
  const [selected, setSelected] = useState([]);
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked]     = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [error, setError]       = useState('');
  const [spinning, setSpinning] = useState(false);

  function start() {
    if (verified || locked) return;
    setSpinning(true);
    setTimeout(() => { setSpinning(false); setOpen(true); }, 600);
  }

  function refresh() {
    if (locked) return;
    setChallenge(randomChallenge());
    setSelected([]);
    setError('');
    setAttempts(0);
  }

  function toggle(i) {
    setSelected(s => s.includes(i) ? s.filter(x => x !== i) : [...s, i]);
  }

  function verify() {
    if (!selected.length) { setError('⚠️ Please select the matching images.'); return; }
    const correct = selected.every(i => challenge.pool[i] === challenge.correct) &&
                    selected.length === challenge.pool.filter(e => e === challenge.correct).length;

    if (!correct) {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setSelected([]);
      if (newAttempts >= 2) {
        setLocked(true);
        let secs = 10;
        setCountdown(secs);
        setError(`❌ Too many wrong attempts. Try again in ${secs}s`);
        const timer = setInterval(() => {
          secs--;
          if (secs <= 0) {
            clearInterval(timer);
            setLocked(false); setAttempts(0); setCountdown(0);
            setChallenge(randomChallenge()); setError('');
          } else {
            setCountdown(secs);
            setError(`❌ Too many wrong attempts. Try again in ${secs}s`);
          }
        }, 1000);
      } else {
        setError(`❌ Incorrect. ${2 - newAttempts} attempt${2 - newAttempts > 1 ? 's' : ''} remaining.`);
        setTimeout(() => { setChallenge(randomChallenge()); setError(''); }, 800);
      }
      return;
    }

    setOpen(false);
    setVerified(true);
    onVerified && onVerified();
    setTimeout(() => setVerified(false), 1500);
  }

  return (
    <>
      <div className={`captcha-box ${verified ? 'verified' : ''}`}>
        <div className="captcha-check" onClick={start}>
          <div className={`captcha-spinner ${spinning ? 'checking' : ''} ${verified ? 'done' : ''}`}></div>
          <span>{verified ? 'Verified ✓' : "I'm not a robot"}</span>
        </div>
        <div className="captcha-brand"><i className="fas fa-shield-alt"></i> Human Check</div>
      </div>

      {open && (
        <div className="modal-overlay active" onClick={e => e.target === e.currentTarget && setOpen(false)}>
          <div className="modal captcha-modal">
            <button className="modal-close" onClick={() => setOpen(false)}><i className="fas fa-times"></i></button>
            <div className="captcha-modal-header">
              <i className="fas fa-robot"></i>
              <div><h4>Human Verification</h4><p>Select all images that match the description</p></div>
            </div>
            <div className="captcha-challenge-label">{challenge.label}</div>
            <div className="captcha-grid">
              {challenge.pool.map((emoji, i) => (
                <div key={i} className={`captcha-tile ${selected.includes(i) ? 'selected' : ''}`} onClick={() => !locked && toggle(i)}>
                  {emoji}
                </div>
              ))}
            </div>
            <div className="captcha-actions">
              <button className="captcha-refresh" onClick={refresh} disabled={locked}><i className="fas fa-redo"></i> New Challenge</button>
              <button className="btn captcha-verify-btn" onClick={verify} disabled={locked}>Verify</button>
            </div>
            {error && <p className="captcha-error">{error}</p>}
          </div>
        </div>
      )}
    </>
  );
}
