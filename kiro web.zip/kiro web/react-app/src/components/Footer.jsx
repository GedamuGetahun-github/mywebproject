import React from 'react';
import { Link } from 'react-router-dom';
import SITE_CONFIG from '../config';

const SOCIALS = [
  { icon:'fa-facebook',  key:'facebook',  label:'Facebook' },
  { icon:'fa-instagram', key:'instagram', label:'Instagram' },
  { icon:'fa-linkedin',  key:'linkedin',  label:'LinkedIn' },
  { icon:'fa-x-twitter', key:'twitter',   label:'Twitter' },
  { icon:'fa-threads',   key:'threads',   label:'Threads' },
  { icon:'fa-telegram',  key:'telegram',  label:'Telegram' },
  { icon:'fa-whatsapp',  key:'whatsapp',  label:'WhatsApp' },
  { icon:'fa-tiktok',    key:'tiktok',    label:'TikTok' },
];

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-bottom">
        <p>© 2026 {SITE_CONFIG.business_name}. All rights reserved.</p>
        <Link to="/privacy" style={{ color:'#94a3b8', fontSize:'0.82rem', textDecoration:'none' }}>Privacy Policy</Link>
        <div className="social-links">
          {SOCIALS.map(s => (
            <a key={s.label} href={SITE_CONFIG[s.key]} target="_blank" rel="noopener" title={s.label}>
              <i className={`fab ${s.icon}`}></i>
            </a>
          ))}
          <a href="/admin" title="Admin"><i className="fas fa-shield-alt"></i></a>
        </div>
      </div>
    </footer>
  );
}
