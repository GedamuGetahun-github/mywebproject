import React, { useState } from 'react';

const SERVICES = [
  { icon: 'fa-tv',          title: 'TV Repair',           desc: 'LED, LCD, OLED, and CRT television diagnostics and repair.',          url: '/services/tv-repair' },
  { icon: 'fa-laptop',      title: 'Laptop & PC',          desc: 'Hardware replacement, software troubleshooting, and upgrades.',        url: '/services/laptop-pc' },
  { icon: 'fa-mobile-alt',  title: 'Mobile Phones',        desc: 'Screen replacement, battery swap, charging port fixes and more.',      url: '/services/mobile-phones' },
  { icon: 'fa-blender',     title: 'Home Appliances',      desc: 'Refrigerators, washing machines, microwaves, and other appliances.',   url: '/services/home-appliances' },
  { icon: 'fa-print',       title: 'Printers & Scanners',  desc: 'Ink system cleaning, roller replacement, and connectivity fixes.',     url: '/services/printers' },
  { icon: 'fa-car-battery', title: 'Power Systems',        desc: 'UPS, inverters, solar systems, and power supply repairs.',             url: '/services/power-systems' },
];

const BG_IMAGES = [
  'https://images.unsplash.com/photo-1461151304267-38535e780c79?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=600&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=600&auto=format&fit=crop',
];

export default function Services() {
  const [query, setQuery] = useState('');

  const filtered = SERVICES.filter(s =>
    s.title.toLowerCase().includes(query.toLowerCase()) ||
    s.desc.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <section className="services" id="services">
      <h2 className="section-title">Our Services</h2>

      <div className="services-search-wrap">
        <div className="services-search-box">
          <i className="fas fa-search"></i>
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search services..."/>
          {query && <button className="search-clear" onClick={() => setQuery('')}><i className="fas fa-times"></i></button>}
        </div>
      </div>

      <div className="services-grid">
        {filtered.map((s, i) => (
          <div
            key={s.title}
            className="card"
            style={{ '--card-bg': `url('${BG_IMAGES[i]}')` }}
            onClick={() => window.location.href = s.url}
          >
            <i className={`fas ${s.icon}`}></i>
            <h3>{s.title}</h3>
            <p>{s.desc}</p>
            <span className="card-link">Learn More</span>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="no-services-msg">
          <i className="fas fa-search"></i> No services found for "{query}"
        </p>
      )}
    </section>
  );
}
