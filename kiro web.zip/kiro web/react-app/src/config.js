// ── Gedamu Electronics — Central Config ──────────────────────
// Edit this file to update contact info across the entire React app.

const SITE_CONFIG = {
  business_name: 'Gedamu Electronics Maintenance',
  address:        'Doba Town, Hararghe',
  phone:          '+251 954 030 195',
  phone_raw:      '+251954030195',
  email:          'Gedamugetahun22@gmail.com',
  hours:          'Mon – Sat: 8:00 AM – 6:00 PM',
  facebook:       'https://www.facebook.com/YOUR_PAGE',
  instagram:      'https://www.instagram.com/YOUR_USERNAME',
  linkedin:       'https://www.linkedin.com/in/gadamu-getahun-9a1042362',
  twitter:        'https://twitter.com/YOUR_USERNAME',
  threads:        'https://www.threads.net/@YOUR_USERNAME',
  telegram:       'https://t.me/gft2024',
  whatsapp:       'https://wa.me/251954030195',
  tiktok:         'https://www.tiktok.com/@thanksmaylords',
  map_embed:      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15713.2!2d41.6!3d8.35!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x17b5f0b0b0b0b0b1%3A0x1!2sDoba%2C+West+Hararghe%2C+Ethiopia!5e0!3m2!1sen!2set!4v1713000000000',
  map_link:       'https://maps.google.com/?q=Doba,West+Hararghe,Ethiopia',
};

export default SITE_CONFIG;
