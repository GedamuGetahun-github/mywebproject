# Gedamu Electronics — React App

## Setup

```bash
cd react-app
npm install
npm start
```

## Copy CSS
```bash
cp web/style.css react-app/public/style.css
```
Add to `public/index.html` `<head>`:
```html
<link rel="stylesheet" href="%PUBLIC_URL%/style.css"/>
```

## Features ✅
- Navbar with search, theme toggle (dark/light/bright), language switcher (EN/አማ/OR)
- Scrolling welcome ticker
- Hero section
- Services with search & background images → individual service pages
- About section
- 3-step repair request form with CAPTCHA verification
- Feedback / reviews (sorted by rating, see all toggle)
- Footer with 8 social links
- Sign In / Sign Up modal with validation
- Welcome toast after login
- Cookie consent banner
- Buy Me a Coffee modal (5 Ethiopian payment methods)
- My Repairs modal (user repair history)
- Privacy Policy page
- Admin Login + Dashboard (Overview, Repairs, Customers, Messages, Feedback, Study)
- Donut charts (Chart.js)
- Book list with cover images (Open Library API)

## Routes
| Path | Page |
|---|---|
| `/` | Main website |
| `/services/:slug` | Individual service page |
| `/privacy` | Privacy Policy |
| `/admin` | Admin Login |
| `/admin/dashboard` | Admin Dashboard |

## Admin
Username: `admin` / Password: `gedamu2026`
