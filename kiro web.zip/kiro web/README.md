# ⚡ Gedamu Electronics Maintenance

A full-stack web application for Gedamu Electronics Maintenance — Doba Town, Hararghe, Ethiopia.

## 📁 Project Structure

```
gedamu-electronics/
├── web/                    # Frontend (HTML/CSS/JS) — works offline
│   ├── index.html          # Main website
│   ├── style.css           # All styles
│   ├── script.js           # All frontend logic
│   ├── config.js           # Site configuration (contact info, social links)
│   ├── api.js              # API client (connects to Node.js server)
│   ├── sw.js               # Service Worker (offline support)
│   ├── privacy.html        # Privacy Policy page
│   ├── best-sellers.html   # Best Sellers books page
│   ├── live-news.html      # Live News page
│   ├── news-detail.html    # News detail page
│   ├── sitemap.xml         # SEO sitemap
│   ├── robots.txt          # SEO robots
│   ├── admin/              # Admin dashboard
│   │   ├── login.html
│   │   ├── dashboard.html
│   │   ├── dashboard.css
│   │   └── dashboard.js
│   └── services/           # Service detail pages
│       ├── tv-repair.html
│       ├── laptop-pc.html
│       ├── mobile-phones.html
│       ├── home-appliances.html
│       ├── printers.html
│       ├── power-systems.html
│       ├── service-page.css
│       └── problems/       # Individual problem pages (58 pages)
│
├── server/                 # Backend (Node.js + Express + MongoDB)
│   ├── index.js            # Main server
│   ├── db.js               # MongoDB models
│   ├── package.json
│   ├── Procfile            # Railway/Heroku deployment
│   ├── .env.example        # Environment variables template
│   ├── middleware/
│   │   ├── auth.js         # JWT authentication
│   │   └── security.js     # XSS, injection protection
│   ├── routes/
│   │   ├── auth.js         # Signup, signin, admin login
│   │   ├── repairs.js      # Repair requests CRUD
│   │   ├── reviews.js      # Customer reviews CRUD
│   │   ├── messages.js     # Contact messages CRUD
│   │   ├── books.js        # Study books CRUD
│   │   └── stats.js        # Dashboard statistics
│   └── services/
│       └── email.js        # Email notifications (Nodemailer)
│
├── react-app/              # React version (future upgrade)
│   ├── public/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── components/
│   │   ├── context/
│   │   └── pages/
│   └── package.json
│
├── .github/
│   └── workflows/
│       └── deploy.yml      # CI/CD pipeline (GitHub Actions)
├── .gitignore
└── README.md
```

## 🚀 Quick Start

### Option 1 — Open directly (no server needed)
```bash
# Just open in browser
open web/index.html
```

### Option 2 — Run with Node.js backend
```bash
cd server
npm install
cp .env.example .env
# Edit .env with your MongoDB URI and email credentials
npm run dev
# Open http://localhost:3001
```

### Option 3 — Run React version
```bash
cd react-app
npm install
cp ../web/style.css public/style.css
npm start
# Open http://localhost:3000
```

## 🔑 Admin Access
- URL: `/admin/login.html`
- Username: `admin`
- Password: `gedamu2026`

## 🌐 Deploy

### Frontend only (Netlify — free)
1. Drag `web/` folder to [netlify.com](https://netlify.com)

### Full stack (Railway — free)
1. Push to GitHub
2. Connect repo to [railway.app](https://railway.app)
3. Set root directory to `server/`
4. Add environment variables

## 📞 Contact
- Phone: +251 954 030 195
- Email: Gedamugetahun22@gmail.com
- Location: Doba Town, West Hararghe, Ethiopia
