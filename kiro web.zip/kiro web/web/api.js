// ── Gedamu Electronics — API Client ──────────────────────────
// Auto-detects whether running locally or on deployed server

const API_URL = (() => {
  // If opened from a real server (not file://), use same origin
  if (window.location.protocol !== 'file:' && window.location.hostname !== 'localhost') {
    return window.location.origin + '/api';
  }
  // Local development
  return 'http://localhost:3001/api';
})();

function getToken()  { return localStorage.getItem('gedamu_token'); }
function getAdminToken() { return sessionStorage.getItem('gedamu_admin_token'); }

async function apiCall(endpoint, method = 'GET', body = null, adminAuth = false) {
  const token = adminAuth ? getAdminToken() : getToken();
  try {
    const res = await fetch(`${API_URL}${endpoint}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body ? JSON.stringify(body) : null,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  } catch (err) {
    // If server is offline, throw a clear message
    if (err.message.includes('fetch') || err.message.includes('NetworkError') || err.message.includes('Failed to fetch')) {
      throw new Error('Server offline — using local mode.');
    }
    throw err;
  }
}

// ── Auth ───────────────────────────────────────────────────────
const API = {
  signup: (name, email, password) =>
    apiCall('/auth/signup', 'POST', { name, email, password }),

  signin: (email, password) =>
    apiCall('/auth/signin', 'POST', { email, password }),

  adminLogin: (username, password) =>
    apiCall('/auth/admin', 'POST', { username, password }),

  // ── Repairs ─────────────────────────────────────────────────
  submitRepair: (data) =>
    apiCall('/repairs', 'POST', data),

  getMyRepairs: () =>
    apiCall('/repairs/mine'),

  getAllRepairs: () =>
    apiCall('/repairs', 'GET', null, true),

  updateRepair: (id, data) =>
    apiCall(`/repairs/${id}`, 'PATCH', data, true),

  // ── Reviews ─────────────────────────────────────────────────
  getReviews: () =>
    apiCall('/reviews'),

  submitReview: (data) =>
    apiCall('/reviews', 'POST', data),

  deleteReview: (id) =>
    apiCall(`/reviews/${id}`, 'DELETE', null, true),

  // ── Messages ────────────────────────────────────────────────
  sendMessage: (data) =>
    apiCall('/messages', 'POST', data),

  getMessages: () =>
    apiCall('/messages', 'GET', null, true),

  markMessageRead: (id) =>
    apiCall(`/messages/${id}/read`, 'PATCH', null, true),

  // ── Books (admin) ────────────────────────────────────────────
  getBooks: () =>
    apiCall('/books', 'GET', null, true),

  addBook: (data) =>
    apiCall('/books', 'POST', data, true),

  updateBook: (id, data) =>
    apiCall(`/books/${id}`, 'PATCH', data, true),

  logBookDate: (id, data) =>
    apiCall(`/books/${id}/log`, 'POST', data, true),

  deleteBook: (id) =>
    apiCall(`/books/${id}`, 'DELETE', null, true),

  // ── Stats (admin) ────────────────────────────────────────────
  getStats: () =>
    apiCall('/stats', 'GET', null, true),
};
