// Auth guard
if (!sessionStorage.getItem('gedamu_admin')) {
  window.location.href = 'login.html';
}

// Sidebar navigation
document.querySelectorAll('.nav-item[data-section]').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    switchSection(item.dataset.section);
    // close sidebar on mobile
    document.getElementById('sidebar').classList.remove('open');
  });
});

function switchSection(name) {
  document.querySelectorAll('.content > .section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const sec = document.getElementById(name);
  if (sec) sec.classList.add('active');
  document.querySelector(`[data-section="${name}"]`)?.classList.add('active');
  document.getElementById('pageTitle').textContent =
    name.charAt(0).toUpperCase() + name.slice(1);

  // Section-specific renders
  if (name === 'overview')  { setTimeout(initCharts, 100); renderRepairsTable(); }
  if (name === 'repairs')   { renderRepairsTable(); }
  if (name === 'feedback')  { renderAdminFeedback(); }
  if (name === 'reports')   { renderAllMonthsChart(); }
  if (name === 'news')      { renderNews(); }
  if (name === 'books')     { renderBooksList(); }
}

// Mobile sidebar toggle
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// Logout
function logout() {
  sessionStorage.removeItem('gedamu_admin');
  window.location.href = 'login.html';
}

// Search / filter table rows
function filterTable(input, tableId) {
  const q = input.value.toLowerCase();
  document.querySelectorAll(`#${tableId} tbody tr`).forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function toggleClearBtn(inputId, btnId) {
  const input = document.getElementById(inputId);
  const btn   = document.getElementById(btnId);
  if (!btn) return;
  btn.style.display = input.value ? 'flex' : 'none';
}

function clearSearch(inputId, tableId, btnId) {
  const input = document.getElementById(inputId);
  const btn   = document.getElementById(btnId);
  input.value = '';
  filterTable(input, tableId);
  if (btn) btn.style.display = 'none';
  input.focus();
}

// ── Table Sorting ──────────────────────────────────────────────
const sortState = {}; // tracks sort direction per table+col

function sortTable(tableId, colIndex) {
  const table  = document.getElementById(tableId);
  const tbody  = table.querySelector('tbody');
  const rows   = Array.from(tbody.querySelectorAll('tr'));
  const key    = `${tableId}-${colIndex}`;

  // Toggle direction
  sortState[key] = sortState[key] === 'asc' ? 'desc' : 'asc';
  const asc = sortState[key] === 'asc';

  // Update header icons
  table.querySelectorAll('thead th').forEach((th, i) => {
    th.classList.remove('asc','desc');
    const icon = th.querySelector('i');
    if (icon) icon.className = 'fas fa-sort';
  });
  const th = table.querySelectorAll('thead th')[colIndex];
  th.classList.add(sortState[key]);
  const icon = th.querySelector('i');
  if (icon) icon.className = asc ? 'fas fa-sort-up' : 'fas fa-sort-down';

  // Sort rows
  rows.sort((a, b) => {
    const aText = a.cells[colIndex]?.textContent.trim() || '';
    const bText = b.cells[colIndex]?.textContent.trim() || '';

    // Try numeric sort first
    const aNum = parseFloat(aText.replace(/[^0-9.-]/g, ''));
    const bNum = parseFloat(bText.replace(/[^0-9.-]/g, ''));

    if (!isNaN(aNum) && !isNaN(bNum)) {
      return asc ? aNum - bNum : bNum - aNum;
    }
    // Fallback to string sort
    return asc
      ? aText.localeCompare(bText)
      : bText.localeCompare(aText);
  });

  rows.forEach(row => tbody.appendChild(row));
}

// New Job Modal
function openJobModal() {
  document.getElementById('jobModal').classList.add('active');
}
function closeJobModal() {
  document.getElementById('jobModal').classList.remove('active');
}

let jobCounter = 25;
function addJob(e) {
  e.preventDefault();
  const fields = e.target.querySelectorAll('input, select');
  const name   = fields[0].value;
  const device = fields[2].value;
  const issue  = fields[3].value;
  const tech   = fields[4].value;
  const cost   = fields[5].value || '—';
  const today  = new Date().toLocaleDateString('en-US',{month:'short',day:'numeric'});

  const tbody = document.querySelector('#repairs-table tbody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td>J-0${jobCounter++}</td>
    <td>${name}</td>
    <td>${device}</td>
    <td>${issue}</td>
    <td>${tech}</td>
    <td><span class="status pending">Pending</span></td>
    <td>${cost}</td>
    <td>${today}</td>`;
  tbody.insertBefore(tr, tbody.firstChild);

  closeJobModal();
  e.target.reset();
  switchSection('repairs');
}

// Close job modal on overlay click
document.getElementById('jobModal').addEventListener('click', function(e) {
  if (e.target === this) closeJobModal();
});

// ── READING CALENDAR ───────────────────────────────────────────
// Load or generate activity data (keyed by YYYY-MM-DD → % read that day)
let readingActivity = JSON.parse(localStorage.getItem('gedamu_reading_activity') || 'null');

if (!readingActivity) {
  // Seed realistic demo data for the past 52 weeks
  readingActivity = {};
  const today = new Date();
  for (let i = 364; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    // ~60% chance of reading on any day, weighted higher recently
    const chance = i < 30 ? 0.75 : i < 90 ? 0.55 : 0.35;
    if (Math.random() < chance) {
      readingActivity[key] = Math.floor(Math.random() * 80) + 10; // 10–90%
    }
  }
  localStorage.setItem('gedamu_reading_activity', JSON.stringify(readingActivity));
}

function renderCalendar() {
  const grid      = document.getElementById('calGrid');
  const monthsEl  = document.getElementById('calMonths');
  const tooltip   = getOrCreateTooltip();
  if (!grid) return;

  grid.innerHTML = '';
  monthsEl.innerHTML = '';

  const today   = new Date();
  const start   = new Date(today);
  // go back to last Sunday 52 weeks ago
  start.setDate(start.getDate() - 364);
  while (start.getDay() !== 0) start.setDate(start.getDate() - 1);

  let currentMonth = -1;
  let colCount = 0;
  const monthPositions = [];

  const cur = new Date(start);
  while (cur <= today) {
    const key   = cur.toISOString().slice(0, 10);
    const val   = readingActivity[key] || 0;
    const level = val === 0 ? 0 : val < 25 ? 1 : val < 50 ? 2 : val < 75 ? 3 : 4;

    const cell = document.createElement('div');
    cell.className = 'cal-cell';
    cell.dataset.level = level;
    cell.dataset.date  = key;
    cell.dataset.val   = val;

    cell.addEventListener('mouseenter', e => {
      tooltip.style.display = 'block';
      tooltip.textContent   = val > 0
        ? `${key}: ${val}% read`
        : `${key}: No reading`;
    });
    cell.addEventListener('mousemove', e => {
      tooltip.style.left = (e.clientX + 12) + 'px';
      tooltip.style.top  = (e.clientY - 28) + 'px';
    });
    cell.addEventListener('mouseleave', () => { tooltip.style.display = 'none'; });

    // Log reading on click
    cell.addEventListener('click', () => {
      const pct = prompt(`Log reading % for ${key} (0–100):`, val || 0);
      if (pct === null) return;
      const num = Math.min(100, Math.max(0, parseInt(pct) || 0));
      if (num === 0) delete readingActivity[key];
      else readingActivity[key] = num;
      localStorage.setItem('gedamu_reading_activity', JSON.stringify(readingActivity));
      renderCalendar();
      renderMonthlyChart();
    });

    grid.appendChild(cell);

    // Track month labels
    if (cur.getDay() === 0) {
      if (cur.getMonth() !== currentMonth) {
        currentMonth = cur.getMonth();
        monthPositions.push({ col: colCount, month: cur.toLocaleString('default', { month: 'short' }) });
      }
      colCount++;
    }
    cur.setDate(cur.getDate() + 1);
  }

  // Render month labels
  monthPositions.forEach((m, i) => {
    const span = document.createElement('span');
    span.className = 'cal-month-lbl';
    span.textContent = m.month;
    monthsEl.appendChild(span);
  });
}

function renderMonthlyChart() {
  const el = document.getElementById('monthlyReadingBars');
  const lbl = document.getElementById('calMonthLabel');
  if (!el) return;

  const today = new Date();
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
    months.push({ year: d.getFullYear(), month: d.getMonth(), label: d.toLocaleString('default', { month: 'short' }) });
  }

  // Compute average % per month
  const data = months.map(m => {
    const days = Object.entries(readingActivity).filter(([k]) => {
      const d = new Date(k);
      return d.getFullYear() === m.year && d.getMonth() === m.month;
    });
    const avg = days.length ? Math.round(days.reduce((s, [, v]) => s + v, 0) / days.length) : 0;
    return { ...m, avg, days: days.length };
  });

  const maxAvg = Math.max(...data.map(d => d.avg), 1);
  el.innerHTML = '';

  data.forEach((m, i) => {
    const isCurrent = i === data.length - 1;
    const heightPct = Math.round((m.avg / maxAvg) * 100);
    el.innerHTML += `
      <div class="mbar-col">
        <span class="bar-pct">${m.avg > 0 ? m.avg + '%' : ''}</span>
        <div class="bar-fill ${isCurrent ? 'current' : ''}" style="height:${heightPct}%"></div>
        <span>${m.label}</span>
      </div>`;
  });

  if (lbl) lbl.textContent = `Last 6 months · ${today.getFullYear()}`;
}

function getOrCreateTooltip() {
  let t = document.getElementById('calTooltip');
  if (!t) {
    t = document.createElement('div');
    t.id = 'calTooltip';
    t.className = 'cal-tooltip';
    document.body.appendChild(t);
  }
  return t;
}

// ── PIE / DONUT CHARTS ─────────────────────────────────────────
let chartInstances = {};

function initCharts() {
  renderRepairStatusChart();
  renderServiceDistChart();
  renderRevenueChart();
}

function makeDonut(canvasId, labels, data, colors) {
  if (chartInstances[canvasId]) chartInstances[canvasId].destroy();
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;
  chartInstances[canvasId] = new Chart(ctx, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 2, borderColor: '#fff', hoverOffset: 8 }] },
    options: {
      cutout: '68%',
      plugins: { legend: { display: false }, tooltip: {
        callbacks: { label: ctx => ` ${ctx.label}: ${ctx.parsed} (${Math.round(ctx.parsed / ctx.dataset.data.reduce((a,b)=>a+b,0)*100)}%)` }
      }},
      animation: { animateRotate: true, duration: 900 }
    }
  });
  return chartInstances[canvasId];
}

function buildLegend(containerId, labels, data, colors) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const total = data.reduce((a,b) => a+b, 0);
  el.innerHTML = labels.map((l,i) =>
    `<div class="legend-item">
      <div class="legend-dot" style="background:${colors[i]}"></div>
      <span>${l}: <strong>${data[i]}</strong> (${Math.round(data[i]/total*100)}%)</span>
    </div>`
  ).join('');
}

function setRec(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

// 1. Repair Status Chart
function renderRepairStatusChart() {
  const labels = ['Completed','In Progress','Pending'];
  const data   = [98, 18, 8];
  const colors = ['#10b981','#3b82f6','#f59e0b'];
  const total  = data.reduce((a,b)=>a+b,0);
  const badge  = document.getElementById('totalJobsBadge');
  if (badge) badge.textContent = total + ' total jobs';

  makeDonut('repairStatusChart', labels, data, colors);
  buildLegend('repairStatusLegend', labels, data, colors);

  const completionRate = Math.round(data[0]/total*100);
  const pendingRate    = Math.round(data[2]/total*100);
  let rec = '';
  if (completionRate >= 75) {
    rec = `<i class="fas fa-check-circle"></i> <strong>Excellent!</strong> ${completionRate}% completion rate. Keep up the great work.`;
  } else if (completionRate >= 50) {
    rec = `<i class="fas fa-exclamation-circle"></i> <strong>Good</strong> but ${data[1]} jobs still in progress. Prioritize older jobs.`;
  } else {
    rec = `<i class="fas fa-exclamation-triangle"></i> <strong>Attention needed.</strong> Only ${completionRate}% completed. Review workflow.`;
  }
  if (pendingRate > 10) rec += ` <br><i class="fas fa-clock"></i> ${data[2]} pending jobs need assignment.`;
  setRec('repairStatusRec', rec);
}

// 2. Service Distribution Chart
function renderServiceDistChart() {
  const labels = ['TV','Laptop','Mobile','Appliance','Printer','Power'];
  const data   = [36, 29, 25, 17, 12, 5];
  const colors = ['#3b82f6','#10b981','#f97316','#8b5cf6','#ec4899','#f59e0b'];
  const total  = data.reduce((a,b)=>a+b,0);
  const badge  = document.getElementById('totalServicesBadge');
  if (badge) badge.textContent = total + ' jobs';

  makeDonut('serviceDistChart', labels, data, colors);
  buildLegend('serviceDistLegend', labels, data, colors);

  const topIdx  = data.indexOf(Math.max(...data));
  const lowIdx  = data.indexOf(Math.min(...data));
  setRec('serviceDistRec',
    `<i class="fas fa-star"></i> <strong>${labels[topIdx]}</strong> is your top service (${Math.round(data[topIdx]/total*100)}%).
     <br><i class="fas fa-arrow-up"></i> Consider promoting <strong>${labels[lowIdx]}</strong> — only ${data[lowIdx]} jobs this period.`
  );
}

// 3. Revenue Chart
function renderRevenueChart() {
  const labels = ['TV','Laptop','Mobile','Appliance','Printer','Power'];
  const data   = [18500, 12300, 8750, 9200, 3600, 4000];
  const colors = ['#3b82f6','#10b981','#f97316','#8b5cf6','#ec4899','#f59e0b'];
  const total  = data.reduce((a,b)=>a+b,0);
  const badge  = document.getElementById('totalRevBadge');
  if (badge) badge.textContent = (total/1000).toFixed(1) + 'K ETB';

  makeDonut('revenueChart', labels, data, colors);
  buildLegend('revenueLegend', labels, data, colors);

  const topIdx = data.indexOf(Math.max(...data));
  const lowIdx = data.indexOf(Math.min(...data));
  setRec('revenueRec',
    `<i class="fas fa-coins"></i> <strong>${labels[topIdx]}</strong> generates the most revenue (${Math.round(data[topIdx]/total*100)}%).
     <br><i class="fas fa-lightbulb"></i> <strong>${labels[lowIdx]}</strong> has growth potential — consider targeted marketing.`
  );
}

// Charts init — handled by unified switchSection above

// Init on first load
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(initCharts, 200);
  renderRepairsTable();
  renderNews();
  setTimeout(() => {
    try { renderAdminFeedback(); } catch(e) { console.warn('renderAdminFeedback:', e); }
  }, 300);
});

// ── ADMIN FEEDBACK ─────────────────────────────────────────────
function getReviews() {
  return JSON.parse(localStorage.getItem('gedamu_reviews') || '[]');
}

function renderAdminFeedback() {
  const reviews  = getReviews();
  const total    = reviews.length;
  const avg      = total ? (reviews.reduce((s,r)=>s+r.rating,0)/total).toFixed(1) : '0.0';
  const positive = reviews.filter(r=>r.rating>=4).length;
  const negative = reviews.filter(r=>r.rating<=3).length;

  const set = (id,v) => { const el=document.getElementById(id); if(el) el.textContent=v; };
  set('fbAvg', avg);
  set('fbTotal', total);
  set('fbPositive', positive);
  set('fbNegative', negative);

  renderAdminReviewsList(reviews);
}

function renderAdminReviewsList(reviews) {
  const el = document.getElementById('adminReviewsList');
  if (!el) return;
  if (!reviews.length) { el.innerHTML = '<p style="padding:1rem;color:#94a3b8">No reviews yet.</p>'; return; }

  el.innerHTML = [...reviews].reverse().map((r, i) => {
    const realIdx = reviews.length - 1 - i;
    const stars = [1,2,3,4,5].map(n=>`<i class="fa${n<=r.rating?'s':'r'} fa-star"></i>`).join('');
    return `<div class="admin-review-row">
      <div class="arv-avatar">${r.name.charAt(0).toUpperCase()}</div>
      <div class="arv-body">
        <div class="arv-top">
          <span class="arv-name">${r.name}</span>
          <span class="arv-date">${r.date}</span>
        </div>
        <div class="arv-stars">${stars}</div>
        ${r.service ? `<span class="arv-service">${r.service}</span>` : ''}
        <p class="arv-text">${r.text}</p>
      </div>
      <button class="arv-del" title="Delete" onclick="deleteReview(${realIdx})"><i class="fas fa-trash"></i></button>
    </div>`;
  }).join('');
}

function deleteReview(idx) {
  const reviews = getReviews();
  if (!confirm(`Delete review by "${reviews[idx]?.name}"?`)) return;
  reviews.splice(idx, 1);
  localStorage.setItem('gedamu_reviews', JSON.stringify(reviews));
  renderAdminFeedback();
}

function filterReviews(q) {
  const reviews = getReviews().filter(r =>
    r.name.toLowerCase().includes(q.toLowerCase()) ||
    r.text.toLowerCase().includes(q.toLowerCase()) ||
    (r.service||'').toLowerCase().includes(q.toLowerCase())
  );
  renderAdminReviewsList(reviews);
}

// Feedback hook — handled by unified switchSection above

// ── USER REPAIR REQUESTS (from website) ────────────────────────
function loadUserRepairs() {
  const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  const tbody = document.querySelector('#repairs-table tbody');
  if (!tbody) return;

  Object.entries(all).forEach(([email, requests]) => {
    requests.forEach(r => {
      // avoid duplicates
      if (document.getElementById('row-' + r.id)) return;
      const statusClass = r.status === 'Completed' ? 'completed' : r.status === 'In Progress' ? 'progress' : 'pending';
      const tr = document.createElement('tr');
      tr.id = 'row-' + r.id;
      tr.innerHTML = `
        <td>${r.id}</td>
        <td>${r.name}</td>
        <td>${r.device}</td>
        <td>${r.problems}</td>
        <td>—</td>
        <td>
          <select onchange="updateUserRepairStatus('${email}','${r.id}',this.value,this)" style="border:1px solid #e2e8f0;border-radius:6px;padding:0.2rem 0.4rem;font-size:0.78rem;cursor:pointer">
            <option ${r.status==='Pending'?'selected':''}>Pending</option>
            <option ${r.status==='In Progress'?'selected':''}>In Progress</option>
            <option ${r.status==='Completed'?'selected':''}>Completed</option>
          </select>
        </td>
        <td>${r.cost}</td>
        <td>${r.date}</td>`;
      tbody.insertBefore(tr, tbody.firstChild);
    });
  });
}

function updateUserRepairStatus(email, requestId, newStatus, selectEl) {
  const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  if (!all[email]) return;
  const req = all[email].find(r => r.id === requestId);
  if (!req) return;
  req.status = newStatus;
  localStorage.setItem('gedamu_repair_requests', JSON.stringify(all));
  // Update row color
  const statusClass = newStatus === 'Completed' ? 'completed' : newStatus === 'In Progress' ? 'progress' : 'pending';
  selectEl.style.color = newStatus === 'Completed' ? '#16a34a' : newStatus === 'In Progress' ? '#2563eb' : '#ca8a04';
}

// Repairs hook — handled by unified switchSection above

document.addEventListener('DOMContentLoaded', loadUserRepairs);

// ── REPORTS — ALL 12 MONTHS ────────────────────────────────────
const MONTHLY_DATA = {
  Jan: { revenue: 3200,  jobs: 8  },
  Feb: { revenue: 4100,  jobs: 10 },
  Mar: { revenue: 5800,  jobs: 14 },
  Apr: { revenue: 7200,  jobs: 18 },
  May: { revenue: 6500,  jobs: 15 },
  Jun: { revenue: 4800,  jobs: 12 },
  Jul: { revenue: 5200,  jobs: 13 },
  Aug: { revenue: 6100,  jobs: 15 },
  Sep: { revenue: 4600,  jobs: 11 },
  Oct: { revenue: 5900,  jobs: 14 },
  Nov: { revenue: 4400,  jobs: 11 },
  Dec: { revenue: 3550,  jobs: 9  },
};

function renderAllMonthsChart() {
  const el    = document.getElementById('allMonthsBars');
  const yearEl= document.getElementById('reportsYear');
  const topEl = document.getElementById('topMonthsTable');
  if (!el) return;

  const now        = new Date();
  const curMonth   = now.toLocaleString('default', { month: 'short' });
  const months     = Object.keys(MONTHLY_DATA);
  const revenues   = Object.values(MONTHLY_DATA).map(d => d.revenue);
  const maxRevenue = Math.max(...revenues);

  if (yearEl) yearEl.textContent = now.getFullYear();

  el.innerHTML = months.map(m => {
    const d       = MONTHLY_DATA[m];
    const heightPct = Math.round((d.revenue / maxRevenue) * 100);
    const isCur   = m === curMonth;
    return `
      <div class="month-bar" style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%">
        <span style="font-size:0.68rem;font-weight:700;color:${isCur?'var(--primary)':'#94a3b8'}">${(d.revenue/1000).toFixed(1)}K</span>
        <div style="flex:1;width:100%;display:flex;align-items:flex-end">
          <div class="bar-col ${isCur?'active':''}" style="width:100%;height:${heightPct}%;border-radius:6px 6px 0 0;min-height:4px"></div>
        </div>
        <span style="font-size:0.72rem;color:${isCur?'var(--primary)':'#94a3b8'};font-weight:${isCur?'700':'400'}">${m}</span>
        <span style="font-size:0.65rem;color:#94a3b8">${d.jobs} jobs</span>
      </div>`;
  }).join('');

  // Top months table
  if (topEl) {
    const sorted = months.map(m => ({ m, ...MONTHLY_DATA[m] })).sort((a,b) => b.revenue - a.revenue).slice(0,5);
    topEl.innerHTML = `
      <thead><tr><th>Rank</th><th>Month</th><th>Revenue</th><th>Jobs</th></tr></thead>
      <tbody>${sorted.map((d,i) => `
        <tr>
          <td>${['🥇','🥈','🥉','4th','5th'][i]}</td>
          <td>${d.m}</td>
          <td style="color:var(--primary);font-weight:700">${d.revenue.toLocaleString()} ETB</td>
          <td>${d.jobs}</td>
        </tr>`).join('')}
      </tbody>`;
  }
}

// Reports hook — handled by unified switchSection above

// ── REAL REPAIR JOBS ───────────────────────────────────────────
function getAllRepairRequests() {
  const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  // Flatten all users' requests into one array
  return Object.values(all).flat().sort((a,b) => b.id.localeCompare(a.id));
}

function renderRepairsTable(query) {
  const tbody      = document.getElementById('repairsTbody');
  const statusFilter = document.getElementById('repairsStatusFilter')?.value || '';
  const q          = (query ?? document.getElementById('repairsSearchInput')?.value ?? '').toLowerCase();
  if (!tbody) return;

  let repairs = getAllRepairRequests();

  // Filter by status
  if (statusFilter) repairs = repairs.filter(r => r.status === statusFilter);

  // Filter by search
  if (q) repairs = repairs.filter(r =>
    `${r.name} ${r.device} ${r.problems} ${r.phone} ${r.id}`.toLowerCase().includes(q)
  );

  if (!repairs.length) {
    tbody.innerHTML = `<tr><td colspan="10" style="text-align:center;color:#94a3b8;padding:2rem">
      ${q || statusFilter ? 'No matching repair requests.' : 'No repair requests submitted yet.'}
    </td></tr>`;
    return;
  }

  const sc = s => s==='Completed'?'completed':s==='In Progress'?'progress':'pending';

  tbody.innerHTML = repairs.map(r => `
    <tr>
      <td style="font-size:0.75rem;color:#94a3b8">${r.id}</td>
      <td><strong>${r.name}</strong><br><span style="font-size:0.72rem;color:#94a3b8">${r.phone}</span></td>
      <td>${r.phone}</td>
      <td>${r.device}</td>
      <td style="max-width:160px;white-space:normal;font-size:0.82rem">${r.problems}</td>
      <td><span style="font-size:0.75rem;padding:0.2rem 0.5rem;border-radius:20px;background:${r.urgency==='Urgent'?'#fee2e2':r.urgency==='Same Day'?'#fef9c3':'#f1f5f9'};color:${r.urgency==='Urgent'?'#ef4444':r.urgency==='Same Day'?'#ca8a04':'#64748b'}">${r.urgency}</span></td>
      <td>
        <select onchange="updateRepairStatus('${r.email}','${r.id}',this.value)" style="border:1px solid #e2e8f0;border-radius:6px;padding:0.2rem 0.4rem;font-size:0.78rem;cursor:pointer">
          <option ${r.status==='Pending'?'selected':''}>Pending</option>
          <option ${r.status==='In Progress'?'selected':''}>In Progress</option>
          <option ${r.status==='Completed'?'selected':''}>Completed</option>
        </select>
      </td>
      <td style="color:var(--primary);font-weight:600">${r.cost||'—'}</td>
      <td style="font-size:0.78rem;color:#94a3b8">${r.date}</td>
      <td>
        <button onclick="deleteRepairRequest('${r.email}','${r.id}')" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:0.85rem" title="Delete">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    </tr>`).join('');

  // Also update overview recent jobs
  renderRecentJobs(repairs.slice(0,5));
}

function updateRepairStatus(email, requestId, newStatus) {
  const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  if (!all[email]) return;
  const req = all[email].find(r => r.id === requestId);
  if (!req) return;
  req.status = newStatus;
  localStorage.setItem('gedamu_repair_requests', JSON.stringify(all));
  renderRepairsTable();
}

function deleteRepairRequest(email, requestId) {
  if (!confirm('Delete this repair request?')) return;
  const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  if (!all[email]) return;
  all[email] = all[email].filter(r => r.id !== requestId);
  localStorage.setItem('gedamu_repair_requests', JSON.stringify(all));
  renderRepairsTable();
}

function renderRecentJobs(repairs) {
  const tbody = document.querySelector('#overview .data-table tbody');
  if (!tbody || !repairs.length) return;
  const sc = s => s==='Completed'?'completed':s==='In Progress'?'progress':'pending';
  tbody.innerHTML = repairs.map(r => `
    <tr>
      <td>${r.id}</td>
      <td>${r.name}</td>
      <td>${r.device}</td>
      <td><span class="status ${sc(r.status)}">${r.status}</span></td>
      <td>${r.date}</td>
    </tr>`).join('');
}

// Repairs render hook — handled by unified switchSection above

// Load on page start
document.addEventListener('DOMContentLoaded', () => {
  renderRepairsTable();
});

// ── NEWS ───────────────────────────────────────────────────────
const DEFAULT_NEWS = [
  { id:1, title:'Welcome to Gedamu Electronics Website!', type:'announcement', content:'Our new website is now live! You can now book repair requests, leave reviews, and track your device status online.', status:'published', showWeb:'yes', date:'Apr 17, 2026' },
  { id:2, title:'50% Off Mobile Screen Repair This Week', type:'promotion', content:'Get 50% discount on all mobile phone screen replacements this week only. Valid until April 25, 2026. Book now!', status:'published', showWeb:'yes', date:'Apr 17, 2026' },
  { id:3, title:'New Service: Software Flashing & FRP Bypass', type:'update', content:'We now offer professional software flashing and Google FRP bypass services for all Android phones.', status:'published', showWeb:'yes', date:'Apr 15, 2026' },
  { id:4, title:'Tip: How to Extend Your Phone Battery Life', type:'tip', content:'Avoid charging your phone to 100% every time. Keeping it between 20–80% significantly extends battery lifespan.', status:'published', showWeb:'yes', date:'Apr 14, 2026' },
  { id:5, title:'Holiday Hours Notice', type:'announcement', content:'We will be closed on May 1st (Labor Day). Normal service resumes May 2nd.', status:'draft', showWeb:'no', date:'Apr 13, 2026' },
];

const TYPE_ICONS = { announcement:'📢', promotion:'🎉', update:'🔧', tip:'💡' };

let newsItems = JSON.parse(localStorage.getItem('gedamu_news') || 'null') || DEFAULT_NEWS;
let newsIdCounter = Math.max(...newsItems.map(n=>n.id), 0) + 1;
let newsEditId = null;

function saveNewsData() { localStorage.setItem('gedamu_news', JSON.stringify(newsItems)); }

function renderNews(items = newsItems) {
  renderNewsStats();
  const grid = document.getElementById('newsGrid');
  if (!grid) return;

  if (!items.length) {
    grid.innerHTML = '<div class="news-empty"><i class="fas fa-newspaper"></i><p>No news yet. Add your first announcement!</p></div>';
    return;
  }

  grid.innerHTML = items.map(n => `
    <div class="news-card type-${n.type}">
      <div class="news-card-header">
        <span class="news-type-badge">${TYPE_ICONS[n.type]} ${n.type.charAt(0).toUpperCase()+n.type.slice(1)}</span>
        <span class="news-status-badge ${n.status}">${n.status === 'published' ? '✅ Published' : '📝 Draft'}</span>
      </div>
      <div class="news-card-title">${n.title}</div>
      <div class="news-card-content">${n.content}</div>
      <div class="news-card-footer">
        <span><i class="fas fa-calendar"></i> ${n.date}</span>
        ${n.showWeb === 'yes' ? '<span class="news-web-badge"><i class="fas fa-globe"></i> On Website</span>' : '<span style="color:#94a3b8"><i class="fas fa-eye-slash"></i> Admin Only</span>'}
      </div>
      <div class="news-card-actions">
        <button onclick="editNews(${n.id})"><i class="fas fa-edit"></i> Edit</button>
        <button onclick="toggleNewsStatus(${n.id})">${n.status==='published'?'<i class="fas fa-eye-slash"></i> Unpublish':'<i class="fas fa-eye"></i> Publish'}</button>
        <button class="del-btn" onclick="deleteNews(${n.id})"><i class="fas fa-trash"></i></button>
      </div>
    </div>`).join('');
}

function renderNewsStats() {
  const el = document.getElementById('newsStats');
  if (!el) return;
  const total     = newsItems.length;
  const published = newsItems.filter(n=>n.status==='published').length;
  const drafts    = newsItems.filter(n=>n.status==='draft').length;
  const onWeb     = newsItems.filter(n=>n.showWeb==='yes'&&n.status==='published').length;
  el.innerHTML = `
    <div class="stat-card blue"><div class="stat-icon"><i class="fas fa-newspaper"></i></div><div class="stat-info"><h3>${total}</h3><p>Total News</p></div></div>
    <div class="stat-card green"><div class="stat-icon"><i class="fas fa-check-circle"></i></div><div class="stat-info"><h3>${published}</h3><p>Published</p></div></div>
    <div class="stat-card orange"><div class="stat-icon"><i class="fas fa-edit"></i></div><div class="stat-info"><h3>${drafts}</h3><p>Drafts</p></div></div>
    <div class="stat-card teal"><div class="stat-icon"><i class="fas fa-globe"></i></div><div class="stat-info"><h3>${onWeb}</h3><p>On Website</p></div></div>`;
}

function filterNews(q) {
  const query  = (q ?? document.getElementById('newsSearchInput')?.value ?? '').toLowerCase();
  const type   = document.getElementById('newsFilter')?.value || '';
  let filtered = newsItems;
  if (type)  filtered = filtered.filter(n => n.type === type);
  if (query) filtered = filtered.filter(n => `${n.title} ${n.content}`.toLowerCase().includes(query));
  renderNews(filtered);
}

function openNewsModal(id = null) {
  newsEditId = id;
  const title = document.getElementById('newsModalTitle');
  if (id) {
    const n = newsItems.find(x=>x.id===id);
    if (!n) return;
    title.textContent = 'Edit News';
    document.getElementById('newsTitle').value   = n.title;
    document.getElementById('newsType').value    = n.type;
    document.getElementById('newsContent').value = n.content;
    document.getElementById('newsStatus').value  = n.status;
    document.getElementById('newsShowWeb').value = n.showWeb;
    document.getElementById('newsEditId').value  = id;
  } else {
    title.textContent = 'Add News';
    document.querySelector('#newsModal form').reset();
  }
  document.getElementById('newsModal').classList.add('active');
}

function closeNewsModal() {
  document.getElementById('newsModal').classList.remove('active');
  newsEditId = null;
}

function editNews(id) { openNewsModal(id); }

function saveNews(e) {
  e.preventDefault();
  const now = new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
  const item = {
    id:      newsEditId || newsIdCounter++,
    title:   document.getElementById('newsTitle').value.trim(),
    type:    document.getElementById('newsType').value,
    content: document.getElementById('newsContent').value.trim(),
    status:  document.getElementById('newsStatus').value,
    showWeb: document.getElementById('newsShowWeb').value,
    date:    newsEditId ? newsItems.find(n=>n.id===newsEditId)?.date || now : now,
  };
  if (newsEditId) {
    newsItems = newsItems.map(n => n.id === newsEditId ? item : n);
  } else {
    newsItems.unshift(item);
  }
  saveNewsData();
  renderNews();
  closeNewsModal();
}

function toggleNewsStatus(id) {
  const n = newsItems.find(x=>x.id===id);
  if (!n) return;
  n.status = n.status === 'published' ? 'draft' : 'published';
  saveNewsData(); renderNews();
}

function deleteNews(id) {
  if (!confirm('Delete this news item?')) return;
  newsItems = newsItems.filter(n=>n.id!==id);
  saveNewsData(); renderNews();
}

// News hook — handled by unified switchSection above

document.addEventListener('DOMContentLoaded', () => {
  const m = document.getElementById('newsModal');
  if (m) m.addEventListener('click', e => { if (e.target === m) closeNewsModal(); });
});

// ── LIVE NEWS ──────────────────────────────────────────────────
let currentLiveCat = 'finance investing';

function switchNewsTab(tab) {
  document.getElementById('myNewsTab').classList.toggle('active', tab === 'my');
  document.getElementById('liveNewsTab').classList.toggle('active', tab === 'live');
  document.getElementById('myNewsPanel').style.display   = tab === 'my'   ? 'block' : 'none';
  document.getElementById('liveNewsPanel').style.display = tab === 'live' ? 'block' : 'none';
  if (tab === 'live') {
    checkApiKeySetup();
    if (getNewsApiKey()) fetchLiveNews(currentLiveCat);
  }
}

function getNewsApiKey() { return localStorage.getItem('gedamu_news_api_key') || ''; }

function saveNewsApiKey() {
  const key = document.getElementById('newsApiKeyInput').value.trim();
  if (!key) return;
  localStorage.setItem('gedamu_news_api_key', key);
  checkApiKeySetup();
  fetchLiveNews(currentLiveCat);
}

function checkApiKeySetup() {
  const setup = document.getElementById('apiKeySetup');
  if (!setup) return;
  setup.style.display = getNewsApiKey() ? 'none' : 'flex';
}

async function fetchLiveNews(query, btn) {
  currentLiveCat = query;

  // Update active button
  if (btn) {
    document.querySelectorAll('.live-cat').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }

  const grid   = document.getElementById('liveNewsGrid');
  const status = document.getElementById('liveNewsApiStatus');
  const apiKey = getNewsApiKey();

  if (!apiKey) {
    grid.innerHTML = '<div class="news-empty"><i class="fas fa-key"></i><p>Please enter your NewsAPI key above to load live news.</p></div>';
    return;
  }

  grid.innerHTML = '<div class="live-news-loading"><i class="fas fa-spinner"></i><p>Loading latest news...</p></div>';
  if (status) status.textContent = 'Fetching...';

  try {
    const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&language=en&sortBy=publishedAt&pageSize=12&apiKey=${apiKey}`;
    const res  = await fetch(url);
    const data = await res.json();

    if (data.status !== 'ok') throw new Error(data.message || 'API error');

    const articles = data.articles.filter(a => a.title && a.title !== '[Removed]');
    if (status) status.textContent = `${articles.length} articles found`;

    if (!articles.length) {
      grid.innerHTML = '<div class="news-empty"><i class="fas fa-newspaper"></i><p>No articles found for this topic.</p></div>';
      return;
    }

    const catEmoji = { 'personal development':'🧠', 'finance investing':'💰', 'startup entrepreneurship':'🚀', 'business leadership':'💼', 'technology innovation':'💻' };

    grid.innerHTML = articles.map(a => {
      const date = a.publishedAt ? new Date(a.publishedAt).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : '';
      const emoji = catEmoji[query] || '📰';
      return `
        <div class="live-news-card">
          ${a.urlToImage
            ? `<img class="live-news-img" src="${a.urlToImage}" alt="${a.title}" onerror="this.parentElement.querySelector('.live-news-img-placeholder').style.display='flex';this.style.display='none'"/><div class="live-news-img-placeholder" style="display:none">${emoji}</div>`
            : `<div class="live-news-img-placeholder">${emoji}</div>`}
          <div class="live-news-body">
            <div class="live-news-source">${a.source?.name || 'News'}</div>
            <div class="live-news-title">${a.title}</div>
            <div class="live-news-desc">${a.description || ''}</div>
            <div class="live-news-footer">
              <span class="live-news-date">${date}</span>
              <a class="live-news-link" href="${a.url}" target="_blank" rel="noopener">Read More →</a>
            </div>
          </div>
        </div>`;
    }).join('');

  } catch(err) {
    if (status) status.textContent = 'Error';
    grid.innerHTML = `<div class="news-empty"><i class="fas fa-exclamation-circle"></i>
      <p>Could not load news: ${err.message}<br><small>Check your API key or try again later.</small></p></div>`;
  }
}

// ── STARTUP BOOKS via Google Books API (no key needed) ─────────
const STARTUP_BOOKS_QUERIES = [
  'The Lean Startup Eric Ries',
  'Zero to One Peter Thiel',
  'The Hard Thing About Hard Things Ben Horowitz',
  'Blitzscaling Reid Hoffman',
  'The $100 Startup Chris Guillebeau',
  'Rework Jason Fried',
  'Traction Gabriel Weinberg',
  'Sprint Jake Knapp',
  'The Mom Test Rob Fitzpatrick',
  'Hooked Nir Eyal',
];

const PERSONAL_FINANCE_BOOKS = [
  'The Millionaire Fastlane MJ DeMarco',
  'The Psychology of Money Morgan Housel',
  'Rich Dad Poor Dad Robert Kiyosaki',
  'Think and Grow Rich Napoleon Hill',
  'The Total Money Makeover Dave Ramsey',
  'I Will Teach You To Be Rich Ramit Sethi',
  'The Automatic Millionaire David Bach',
  'Your Money or Your Life Vicki Robin',
  'The Richest Man in Babylon George Clason',
  'Money Master the Game Tony Robbins',
];

const BUSINESS_BOOKS = [
  'Atomic Habits James Clear',
  'The 7 Habits of Highly Effective People Stephen Covey',
  'How to Win Friends and Influence People Dale Carnegie',
  'Deep Work Cal Newport',
  'The 4-Hour Workweek Timothy Ferriss',
  'Thinking Fast and Slow Daniel Kahneman',
  'Outliers Malcolm Gladwell',
  'Start With Why Simon Sinek',
  'Never Split the Difference Chris Voss',
  'Principles Ray Dalio',
];

async function fetchStartupBooks(btn) {
  await fetchGoogleBooks(STARTUP_BOOKS_QUERIES, btn, '🚀', 'startup');
}

async function fetchGoogleBooks(queries, btn, emoji, category) {
  document.querySelectorAll('#booksNewsPanel .live-cat').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  const grid   = document.getElementById('nytBooksGrid');
  const status = document.getElementById('nytApiStatus');

  grid.innerHTML = '<div class="live-news-loading"><i class="fas fa-spinner"></i><p>Loading books...</p></div>';
  if (status) status.textContent = 'Fetching...';

  try {
    const results = await Promise.all(
      queries.map(async (q, i) => {
        const res  = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(q)}&maxResults=1&printType=books`);
        const data = await res.json();
        const item = data.items?.[0];
        if (!item) return null;
        const info = item.volumeInfo;
        return {
          rank:        i + 1,
          title:       info.title,
          author:      info.authors?.join(', ') || 'Unknown',
          description: info.description ? info.description.slice(0, 160) + '...' : 'A must-read book in this category.',
          image:       info.imageLinks?.thumbnail?.replace('http:', 'https:') || '',
          link:        info.infoLink || '#',
          rating:      info.averageRating || null,
          pages:       info.pageCount || null,
          category,
        };
      })
    );

    const books = results.filter(Boolean).slice(0, 10);
    if (status) status.textContent = `${books.length} books`;

    const existingStudy = JSON.parse(localStorage.getItem('gedamu_books') || '[]');

    grid.innerHTML = books.map(b => {
      const inStudy = existingStudy.some(s => s.title.toLowerCase() === b.title.toLowerCase());
      return `
        <div class="nyt-book-card">
          <div class="nyt-rank-badge ${b.rank<=3?'rank-'+b.rank:''}">${b.rank}</div>
          ${b.image
            ? `<img class="nyt-book-cover" src="${b.image}" alt="${b.title}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"/>
               <div class="nyt-book-cover-placeholder" style="display:none">${emoji}</div>`
            : `<div class="nyt-book-cover-placeholder">${emoji}</div>`}
          <div class="nyt-book-body">
            <div class="nyt-book-title">${b.title}</div>
            <div class="nyt-book-author">by ${b.author}</div>
            <div class="nyt-book-desc">
              ${b.rating ? `<span style="display:inline-block;background:#fff7ed;color:#f97316;font-size:0.72rem;font-weight:700;padding:0.2rem 0.6rem;border-radius:20px;margin-bottom:0.5rem">⭐ ${b.rating}/5 · ${b.pages||'?'} pages</span><br/>` : ''}
              ${b.description}
            </div>
            <div class="nyt-book-footer">
              <a class="nyt-buy-btn" href="${b.link}" target="_blank" rel="noopener">View →</a>
              <button class="nyt-add-study-btn ${inStudy?'added':''}"
                onclick="addNYTBookToStudy('${b.title.replace(/'/g,"\\'")}','${b.author.replace(/'/g,"\\'")}','${b.category}',this)"
                ${inStudy?'disabled':''}>
                ${inStudy ? '✅ In Study' : '+ Add to Study'}
              </button>
            </div>
          </div>
        </div>`;
    }).join('');

  } catch(err) {
    if (status) status.textContent = 'Error';
    grid.innerHTML = `<div class="news-empty"><i class="fas fa-exclamation-circle"></i><p>Could not load books: ${err.message}</p></div>`;
  }
}
let currentNYTList = 'hardcover-business-books';

const NYT_LIST_LABELS = {
  'hardcover-business-books':          '💼 Business',
  'personal-finance':                  '💰 Personal Finance',
  'advice-how-to-and-miscellaneous':   '🧠 Self Help',
  'young-adult-hardcover':             '🚀 Young Adult',
};

function getNYTApiKey() { return localStorage.getItem('gedamu_nyt_api_key') || ''; }

function saveNYTApiKey() {
  const key = document.getElementById('nytApiKeyInput').value.trim();
  if (!key) return;
  localStorage.setItem('gedamu_nyt_api_key', key);
  checkNYTApiKeySetup();
  fetchNYTBooks(currentNYTList);
}

function checkNYTApiKeySetup() {
  const setup = document.getElementById('nytApiKeySetup');
  if (!setup) return;
  const key = getNYTApiKey();
  if (key) {
    setup.style.display = 'none';
    // Show change key button if not already there
    let changeBtn = document.getElementById('nytChangeKeyBtn');
    if (!changeBtn) {
      changeBtn = document.createElement('button');
      changeBtn.id = 'nytChangeKeyBtn';
      changeBtn.className = 'add-btn';
      changeBtn.style.background = '#64748b';
      changeBtn.style.fontSize = '0.78rem';
      changeBtn.innerHTML = '<i class="fas fa-key"></i> Change API Key';
      changeBtn.onclick = () => {
        localStorage.removeItem('gedamu_nyt_api_key');
        setup.style.display = 'flex';
        changeBtn.remove();
        document.getElementById('nytBooksGrid').innerHTML = '<div class="news-empty"><i class="fas fa-book"></i><p>Select a category to load NYT Best Sellers.</p></div>';
        document.getElementById('nytApiStatus').textContent = '';
      };
      setup.parentElement.insertBefore(changeBtn, setup.nextSibling);
    }
  } else {
    setup.style.display = 'flex';
    const changeBtn = document.getElementById('nytChangeKeyBtn');
    if (changeBtn) changeBtn.remove();
  }
}

async function fetchNYTBooks(listName, btn) {
  // For Business and Personal Finance, use curated Google Books list
  if (listName === 'hardcover-business-books') {
    await fetchGoogleBooks(BUSINESS_BOOKS, btn, '💼', 'Business'); return;
  }
  if (listName === 'personal-finance') {
    await fetchGoogleBooks(PERSONAL_FINANCE_BOOKS, btn, '💰', 'Personal Finance'); return;
  }
  currentNYTList = listName;

  if (btn) {
    document.querySelectorAll('#booksNewsPanel .live-cat').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }

  const grid   = document.getElementById('nytBooksGrid');
  const status = document.getElementById('nytApiStatus');
  const apiKey = getNYTApiKey();

  if (!apiKey) {
    grid.innerHTML = '<div class="news-empty"><i class="fas fa-key"></i><p>Please enter your NYT API key above.</p></div>';
    return;
  }

  grid.innerHTML = '<div class="live-news-loading"><i class="fas fa-spinner"></i><p>Loading NYT Best Sellers...</p></div>';
  if (status) status.textContent = 'Fetching...';

  try {
    const url = `https://api.nytimes.com/svc/books/v3/lists/current/${listName}.json?api-key=${apiKey}`;
    const res  = await fetch(url);
    const data = await res.json();

    if (data.status !== 'OK') throw new Error(data.fault?.faultstring || 'API error');

    const books = data.results?.books || [];
    if (status) status.textContent = `${books.length} books · Updated ${data.results?.published_date || ''}`;

    if (!books.length) {
      grid.innerHTML = '<div class="news-empty"><i class="fas fa-book"></i><p>No books found for this list.</p></div>';
      return;
    }

    grid.innerHTML = books.map((b, i) => {
      const rank = i + 1;
      const rankClass = rank === 1 ? 'rank-1' : rank === 2 ? 'rank-2' : rank === 3 ? 'rank-3' : '';
      const inStudy = (JSON.parse(localStorage.getItem('gedamu_books') || '[]')).some(s => s.title.toLowerCase() === b.title.toLowerCase());
      const amazonUrl = b.buy_links?.find(l => l.name === 'Amazon')?.url || b.amazon_product_url || '#';

      return `
        <div class="nyt-book-card">
          <div class="nyt-rank-badge ${rankClass}">${rank}</div>
          ${b.book_image
            ? `<img class="nyt-book-cover" src="${b.book_image}" alt="${b.title}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"/>
               <div class="nyt-book-cover-placeholder" style="display:none">📚</div>`
            : `<div class="nyt-book-cover-placeholder">📚</div>`}
          <div class="nyt-book-body">
            <div class="nyt-book-title">${b.title}</div>
            <div class="nyt-book-author">by ${b.author}</div>
            <div class="nyt-book-desc">
              <span style="display:inline-block;background:#fff7ed;color:#f97316;font-size:0.72rem;font-weight:700;padding:0.2rem 0.6rem;border-radius:20px;margin-bottom:0.5rem">
                📅 ${b.weeks_on_list} week${b.weeks_on_list !== 1 ? 's' : ''} on NYT Best Seller list
              </span><br/>
              ${b.description || 'No description available.'}
            </div>
            <div class="nyt-book-footer">
              <a class="nyt-buy-btn" href="${amazonUrl}" target="_blank" rel="noopener">Buy →</a>
              <button class="nyt-add-study-btn ${inStudy ? 'added' : ''}"
                onclick="addNYTBookToStudy('${b.title.replace(/'/g,"\\'")}','${b.author.replace(/'/g,"\\'")}','${listName}',this)"
                ${inStudy ? 'disabled' : ''}>
                ${inStudy ? '✅ In Study' : '+ Add to Study'}
              </button>
            </div>
          </div>
        </div>`;
    }).join('');

  } catch(err) {
    if (status) status.textContent = 'Error';
    grid.innerHTML = `<div class="news-empty"><i class="fas fa-exclamation-circle"></i>
      <p>Could not load books: ${err.message}<br>
      <small>Check your NYT API key at <a href="https://developer.nytimes.com" target="_blank" style="color:var(--primary)">developer.nytimes.com</a></small></p></div>`;
  }
}

function addNYTBookToStudy(title, author, listName, btn) {
  const catMap = {
    'hardcover-business-books':        'Business',
    'personal-finance':                'Personal Finance',
    'hardcover-nonfiction':            'Business',
    'startup':                         'Business',
  };
  const category = catMap[listName] || 'Other';
  const existing = JSON.parse(localStorage.getItem('gedamu_books') || '[]');
  if (existing.some(b => b.title.toLowerCase() === title.toLowerCase())) {
    btn.textContent = '✅ In Study'; btn.disabled = true; btn.classList.add('added'); return;
  }
  const newBook = {
    id: Date.now(), title, author, category, progress: 0
  };
  existing.push(newBook);
  localStorage.setItem('gedamu_books', JSON.stringify(existing));
  // Reload books array
  books = existing;
  btn.textContent = '✅ In Study'; btn.disabled = true; btn.classList.add('added');
}

// switchNewsTab — handles My News / Live News / NYT Best Sellers tabs
function switchNewsTab(tab) {
  document.getElementById('myNewsTab').classList.toggle('active', tab === 'my');
  document.getElementById('liveNewsTab').classList.toggle('active', tab === 'live');
  document.getElementById('booksNewsTab').classList.toggle('active', tab === 'books');
  document.getElementById('myNewsPanel').style.display    = tab === 'my'    ? 'block' : 'none';
  document.getElementById('liveNewsPanel').style.display  = tab === 'live'  ? 'block' : 'none';
  document.getElementById('booksNewsPanel').style.display = tab === 'books' ? 'block' : 'none';
  if (tab === 'live')  { checkApiKeySetup(); if (getNewsApiKey()) fetchLiveNews(currentLiveCat); }
  if (tab === 'books') { checkNYTApiKeySetup(); if (getNYTApiKey()) fetchNYTBooks(currentNYTList); }
}

// ── MY BOOKS ───────────────────────────────────────────────────
const BOOK_COVERS = {
  'Atomic Habits':               'https://covers.openlibrary.org/b/isbn/9780735211292-M.jpg',
  'The Millionaire Fastlane':    'https://covers.openlibrary.org/b/isbn/9780984358106-M.jpg',
  'The Lean Startup':            'https://covers.openlibrary.org/b/isbn/9780307887894-M.jpg',
  'Limitless':                   'https://covers.openlibrary.org/b/isbn/9781401958237-M.jpg',
  'The Courage to Be Disliked':  'https://covers.openlibrary.org/b/isbn/9781501197277-M.jpg',
  'The Mountain Is You':         'https://covers.openlibrary.org/b/isbn/9781949759228-M.jpg',
  "Can't Hurt Me":               'https://covers.openlibrary.org/b/isbn/9781544512273-M.jpg',
  'Rich Dad Poor Dad':           'https://covers.openlibrary.org/b/isbn/9781612680194-M.jpg',
  'The Intelligent Investor':    'https://covers.openlibrary.org/b/isbn/9780060555665-M.jpg',
  'Think and Grow Rich':         'https://covers.openlibrary.org/b/isbn/9781585424337-M.jpg',
  'The Psychology of Money':     'https://covers.openlibrary.org/b/isbn/9780857197689-M.jpg',
  'Zero to One':                 'https://covers.openlibrary.org/b/isbn/9780804139021-M.jpg',
};

const BOOK_COLORS = ['#3b82f6','#10b981','#f97316','#8b5cf6','#f43f5e','#0ea5e9','#facc15','#ec4899'];

const DEFAULT_BOOK_LIST = [
  { id:1,  title:'Atomic Habits',               author:'James Clear',     category:'Personal Development', progress:0 },
  { id:2,  title:'The Millionaire Fastlane',     author:'MJ DeMarco',      category:'Personal Finance',     progress:0 },
  { id:3,  title:'The Lean Startup',             author:'Eric Ries',       category:'Business',             progress:0 },
  { id:4,  title:'Limitless',                    author:'Jim Kwik',        category:'Personal Development', progress:0 },
  { id:5,  title:'The Courage to Be Disliked',   author:'Ichiro Kishimi',  category:'Personal Development', progress:0 },
  { id:6,  title:'The Mountain Is You',          author:'Brianna Wiest',   category:'Personal Development', progress:0 },
  { id:7,  title:"Can't Hurt Me",                author:'David Goggins',   category:'Personal Development', progress:0 },
  { id:8,  title:'Rich Dad Poor Dad',            author:'Robert Kiyosaki', category:'Personal Finance',     progress:0 },
  { id:9,  title:'The Intelligent Investor',     author:'Benjamin Graham', category:'Investing',            progress:0 },
  { id:10, title:'Think and Grow Rich',          author:'Napoleon Hill',   category:'Personal Finance',     progress:0 },
  { id:11, title:'The Psychology of Money',      author:'Morgan Housel',   category:'Personal Finance',     progress:0 },
  { id:12, title:'Zero to One',                  author:'Peter Thiel',     category:'Business',             progress:0 },
];

if (!localStorage.getItem('gedamu_books_v2')) {
  localStorage.setItem('gedamu_books_v2', JSON.stringify(DEFAULT_BOOK_LIST));
}

let bookList = JSON.parse(localStorage.getItem('gedamu_books_v2'));
let bookEditId = null;
let bookIdCtr  = Math.max(...bookList.map(b => b.id), 0) + 1;

function saveBooksV2() { localStorage.setItem('gedamu_books_v2', JSON.stringify(bookList)); }

function renderBooksList(filter) {
  const list    = document.getElementById('bk-list');
  if (!list) return;

  const q    = (filter ?? document.getElementById('booksSearch')?.value ?? '').toLowerCase();
  const cat  = document.getElementById('booksCatFilter')?.value || '';
  let items  = bookList;
  if (cat) items = items.filter(b => b.category === cat);
  if (q)   items = items.filter(b => `${b.title} ${b.author}`.toLowerCase().includes(q));

  // Stats
  const total      = bookList.length;
  const done       = bookList.filter(b => b.progress === 100).length;
  const reading    = bookList.filter(b => b.progress > 0 && b.progress < 100).length;
  const notStarted = bookList.filter(b => b.progress === 0).length;
  const overall    = total ? Math.round(bookList.reduce((s,b) => s+b.progress, 0) / total) : 0;

  const set = (id, v) => { const el=document.getElementById(id); if(el) el.textContent=v; };
  set('bk-total', total); set('bk-done', done);
  set('bk-reading', reading); set('bk-notstarted', notStarted);
  set('bk-overall-pct', overall + '%');
  const bar = document.getElementById('bk-overall-bar');
  if (bar) bar.style.width = overall + '%';

  if (!items.length) {
    list.innerHTML = '<p style="padding:1.5rem;text-align:center;color:#94a3b8">No books found.</p>';
    return;
  }

  list.innerHTML = items.map((b, i) => {
    const color    = BOOK_COLORS[i % BOOK_COLORS.length];
    const cover    = BOOK_COVERS[b.title];
    const status   = b.progress === 100 ? 'done' : b.progress > 0 ? 'reading' : 'notstarted';
    const label    = b.progress === 100 ? 'Completed' : b.progress > 0 ? 'Reading' : 'Not Started';
    const barColor = b.progress === 100 ? '#10b981' : b.progress > 0 ? '#3b82f6' : '#e2e8f0';
    return `
      <div class="book-item">
        <div class="book-cover" style="background:${color};overflow:hidden;padding:0">
          ${cover
            ? `<img src="${cover}" alt="${b.title}" style="width:100%;height:100%;object-fit:cover;border-radius:6px" onerror="this.style.display='none'"/>`
            : '📚'}
        </div>
        <div class="book-info">
          <h4>${b.title}</h4>
          <div class="book-meta">
            <span><i class="fas fa-user"></i> ${b.author || '—'}</span>
            <span><i class="fas fa-tag"></i> ${b.category}</span>
          </div>
          <div class="book-progress-wrap">
            <div class="book-bar-bg"><div class="book-bar" style="width:${b.progress}%;background:${barColor}"></div></div>
            <span class="book-pct" style="color:${barColor}">${b.progress}%</span>
          </div>
        </div>
        <span class="book-status ${status}">${label}</span>
        <div class="book-actions">
          <button title="Edit" onclick="openAddBookModal(${b.id})"><i class="fas fa-edit"></i></button>
          <button title="Progress" onclick="quickProgress(${b.id})"><i class="fas fa-sliders-h"></i></button>
          <button title="Delete" onclick="deleteBookItem(${b.id})" style="color:#ef4444"><i class="fas fa-trash"></i></button>
        </div>
      </div>`;
  }).join('');
}

function filterBooksList(q) { renderBooksList(q); }

function openAddBookModal(id) {
  bookEditId = id || null;
  const title = document.getElementById('addBookModalTitle');
  if (id) {
    const b = bookList.find(x => x.id === id);
    if (!b) return;
    title.textContent = 'Edit Book';
    document.getElementById('bkTitle').value    = b.title;
    document.getElementById('bkAuthor').value   = b.author;
    document.getElementById('bkCategory').value = b.category;
    document.getElementById('bkProgress').value = b.progress;
    document.getElementById('bkProgressLabel').textContent = b.progress + '%';
    document.getElementById('bkEditId').value   = id;
  } else {
    title.textContent = 'Add Book';
    document.querySelector('#addBookModal form').reset();
    document.getElementById('bkProgressLabel').textContent = '0%';
  }
  document.getElementById('addBookModal').classList.add('active');
}

function closeAddBookModal() {
  document.getElementById('addBookModal').classList.remove('active');
  bookEditId = null;
}

function saveBook(e) {
  e.preventDefault();
  const book = {
    id:       bookEditId || bookIdCtr++,
    title:    document.getElementById('bkTitle').value.trim(),
    author:   document.getElementById('bkAuthor').value.trim(),
    category: document.getElementById('bkCategory').value,
    progress: parseInt(document.getElementById('bkProgress').value) || 0,
  };
  if (bookEditId) {
    bookList = bookList.map(b => b.id === bookEditId ? book : b);
  } else {
    bookList.push(book);
  }
  saveBooksV2(); renderBooksList(); closeAddBookModal();
}

function deleteBookItem(id) {
  if (!confirm('Remove this book?')) return;
  bookList = bookList.filter(b => b.id !== id);
  saveBooksV2(); renderBooksList();
}

function quickProgress(id) {
  const b = bookList.find(x => x.id === id);
  if (!b) return;
  const val = prompt(`Progress for "${b.title}" (0–100):`, b.progress);
  if (val === null) return;
  b.progress = Math.min(100, Math.max(0, parseInt(val) || 0));
  saveBooksV2(); renderBooksList();
}

document.addEventListener('DOMContentLoaded', () => {
  const m = document.getElementById('addBookModal');
  if (m) m.addEventListener('click', e => { if (e.target === m) closeAddBookModal(); });
});

// ── BOOK PROGRESS MODAL ────────────────────────────────────────
let bkProgressId = null;

function openBookProgressModal(id) {
  bkProgressId = id;
  const b = bookList.find(x => x.id === id);
  if (!b) return;

  document.getElementById('bkProgModalTitle').textContent = `📖 ${b.title}`;
  document.getElementById('bkProgInfo').textContent = `${b.title} — ${b.author} | Current: ${b.progress}%`;

  // Pages tab
  document.getElementById('bkTotalPages').value = b.totalPages || '';
  document.getElementById('bkPagesRead').value  = b.pagesRead  || '';
  document.getElementById('bkSlider').value     = b.progress;
  document.getElementById('bkSliderLabel').textContent = b.progress + '%';
  document.getElementById('bkPagesResult').style.display = 'none';

  // Time tab
  document.getElementById('bkTimeTotalPages').value = b.totalPages || '';
  document.getElementById('bkTotalHours').value     = b.totalHours || '';
  document.getElementById('bkHours').value          = '';
  document.getElementById('bkTimeResult').style.display = 'none';

  // Calendar tab
  document.getElementById('bkCalDate').value  = new Date().toISOString().slice(0,10);
  document.getElementById('bkCalSlider').value = b.progress;
  document.getElementById('bkCalPctLabel').textContent = b.progress + '%';
  document.getElementById('bkCalNote').value  = '';
  renderBkCalHistory(id);

  // Reset to first tab
  switchBkTab('pages', document.querySelector('#bookProgressModal .prog-tab'));
  document.getElementById('bookProgressModal').classList.add('active');
}

function closeBookProgressModal() {
  document.getElementById('bookProgressModal').classList.remove('active');
  bkProgressId = null;
}

function switchBkTab(name, btn) {
  document.querySelectorAll('#bookProgressModal .prog-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('#bookProgressModal .prog-panel').forEach(p => p.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.getElementById('bkpanel-' + name).classList.add('active');
}

function setBkSlider(val) {
  document.getElementById('bkSlider').value = val;
  document.getElementById('bkSliderLabel').textContent = val + '%';
}

function calcBkPages() {
  const total = parseInt(document.getElementById('bkTotalPages').value) || 0;
  const read  = parseInt(document.getElementById('bkPagesRead').value)  || 0;
  const res   = document.getElementById('bkPagesResult');
  if (total > 0 && read >= 0) {
    const pct = Math.min(100, Math.round(read / total * 100));
    res.style.display = 'block';
    res.textContent   = `📊 ${read} / ${total} pages = ${pct}%`;
    document.getElementById('bkSlider').value = pct;
    document.getElementById('bkSliderLabel').textContent = pct + '%';
  } else {
    res.style.display = 'none';
  }
}

function calcBkTime() {
  const total  = parseInt(document.getElementById('bkTimeTotalPages').value) || 0;
  const speed  = parseInt(document.getElementById('bkSpeed').value) || 30;
  const hours  = parseFloat(document.getElementById('bkHours').value) || 0;
  const res    = document.getElementById('bkTimeResult');
  if (total > 0 && hours > 0) {
    const pagesRead = Math.round(hours * speed);
    const pct       = Math.min(100, Math.round(pagesRead / total * 100));
    res.style.display = 'block';
    res.textContent   = `⏱️ ${hours}h × ${speed} pages/h = ${pagesRead} pages = ${pct}%`;
  } else {
    res.style.display = 'none';
  }
}

function saveBkProgress(mode) {
  const b = bookList.find(x => x.id === bkProgressId);
  if (!b) return;

  if (mode === 'pages') {
    const total = parseInt(document.getElementById('bkTotalPages').value) || 0;
    const read  = parseInt(document.getElementById('bkPagesRead').value)  || 0;
    b.progress  = parseInt(document.getElementById('bkSlider').value);
    if (total > 0) { b.totalPages = total; b.pagesRead = read || Math.round(total * b.progress / 100); }

  } else if (mode === 'time') {
    const total  = parseInt(document.getElementById('bkTimeTotalPages').value) || 0;
    const speed  = parseInt(document.getElementById('bkSpeed').value) || 30;
    const hours  = parseFloat(document.getElementById('bkHours').value) || 0;
    const totHrs = parseFloat(document.getElementById('bkTotalHours').value) || 0;
    if (total > 0 && hours > 0) {
      const pagesRead = Math.round(hours * speed);
      b.progress = Math.min(100, Math.round(pagesRead / total * 100));
      b.totalPages = total;
    }
    if (totHrs > 0) b.totalHours = totHrs;
    if (!b.hoursLog) b.hoursLog = [];
    if (hours > 0) b.hoursLog.push({ date: new Date().toISOString().slice(0,10), hours });

  } else if (mode === 'calendar') {
    const date = document.getElementById('bkCalDate').value;
    const pct  = parseInt(document.getElementById('bkCalSlider').value);
    const note = document.getElementById('bkCalNote').value.trim();
    b.progress = pct;
    if (!b.calLog) b.calLog = [];
    b.calLog = b.calLog.filter(e => e.date !== date);
    b.calLog.push({ date, pct, note });
    b.calLog.sort((a,c) => c.date.localeCompare(a.date));
    document.getElementById('bkCalNote').value = '';
    renderBkCalHistory(bkProgressId);
  }

  saveBooksV2(); renderBooksList();

  // 🎉 Congratulations if just completed
  if (b.progress === 100) {
    closeBookProgressModal();
    showBookCongrats(b.title, b.author);
    return;
  }

  // Flash button
  const btn = document.querySelector(`#bkpanel-${mode} .add-btn`);
  if (btn) { const orig = btn.textContent; btn.textContent = '✅ Saved!'; setTimeout(() => btn.textContent = orig, 1500); }
}

function renderBkCalHistory(id) {
  const b  = bookList.find(x => x.id === id);
  const el = document.getElementById('bkCalHistory');
  if (!el || !b) return;
  const log = b.calLog || [];
  if (!log.length) { el.innerHTML = '<p style="font-size:0.75rem;color:#94a3b8;padding:0.3rem">No entries yet.</p>'; return; }
  el.innerHTML = '<p style="font-size:0.7rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:0.3rem">History</p>' +
    log.map((e,i) => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:0.35rem 0.5rem;border-bottom:1px solid #f1f5f9;font-size:0.78rem">
        <span style="color:#64748b">${e.date}</span>
        <span style="color:#94a3b8;font-style:italic;flex:1;margin:0 0.5rem">${e.note||''}</span>
        <span style="font-weight:700;color:var(--primary)">${e.pct}%</span>
        <button onclick="deleteBkCalEntry(${id},${i})" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:0.72rem;margin-left:0.3rem"><i class="fas fa-times"></i></button>
      </div>`).join('');
}

function deleteBkCalEntry(id, idx) {
  const b = bookList.find(x => x.id === id);
  if (!b || !b.calLog) return;
  b.calLog.splice(idx, 1);
  saveBooksV2(); renderBkCalHistory(id);
}

// Override quickProgress to open the full modal
quickProgress = function(id) { openBookProgressModal(id); };

document.addEventListener('DOMContentLoaded', () => {
  const m = document.getElementById('bookProgressModal');
  if (m) m.addEventListener('click', e => { if (e.target === m) closeBookProgressModal(); });
});

// ── BOOK CONGRATULATIONS ───────────────────────────────────────
function showBookCongrats(title, author) {
  document.getElementById('congratsBookTitle').textContent = '📖 ' + title;
  document.getElementById('congratsBookAuthor').textContent = 'by ' + (author || 'Unknown');
  document.getElementById('bookCongratsModal').classList.add('active');
  launchCongratsConfetti();
}

function closeBookCongrats() {
  document.getElementById('bookCongratsModal').classList.remove('active');
  document.getElementById('congratsConfetti').innerHTML = '';
}

function launchCongratsConfetti() {
  const container = document.getElementById('congratsConfetti');
  container.innerHTML = '';
  const colors = ['#facc15','#f97316','#10b981','#3b82f6','#f43f5e','#a855f7','#fff','#fbbf24'];
  for (let i = 0; i < 80; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.cssText = `
      left: ${Math.random() * 100}%;
      background: ${colors[Math.floor(Math.random() * colors.length)]};
      width: ${5 + Math.random() * 10}px;
      height: ${5 + Math.random() * 10}px;
      border-radius: ${Math.random() > 0.5 ? '50%' : '2px'};
      animation-duration: ${1.5 + Math.random() * 2.5}s;
      animation-delay: ${Math.random() * 0.6}s;
    `;
    container.appendChild(piece);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const m = document.getElementById('bookCongratsModal');
  if (m) m.addEventListener('click', e => { if (e.target === m) closeBookCongrats(); });
});
