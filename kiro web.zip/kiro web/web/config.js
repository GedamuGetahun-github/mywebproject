// ── Gedamu Electronics — Site Configuration ──────────────────
// Edit this file to update contact info across the entire site.

const SITE_CONFIG = {
  business_name: 'Gedamu Electronics Maintenance',
  address:        'Doba Town, Hararghe',
  phone:          '+251 954 030 195',
  email:          'Gedamugetahun22@gmail.com',
  hours:          'Mon – Sat: 8:00 AM – 6:00 PM',

  // ── Social Media Links ──────────────────────────────────────
  // Replace each value with your real profile URL
  facebook:  'https://www.facebook.com/YOUR_PAGE',
  linkedin:  'https://www.linkedin.com/in/gadamu-getahun-9a1042362',
  telegram:  'https://t.me/gft2024',
  tiktok:    'https://www.tiktok.com/@thanksmaylords',
  instagram: 'https://www.instagram.com/YOUR_USERNAME',
  threads:   'https://www.threads.net/@YOUR_USERNAME',
  whatsapp:  'https://wa.me/251954030195',
  twitter:   'https://twitter.com/YOUR_USERNAME',
  youtube:   'https://www.youtube.com/@gadamutech384Edu',

  map_link: 'https://maps.google.com/?q=Doba,West+Hararghe,Ethiopia',

  // ── Cloudflare Turnstile ────────────────────────────────────
  // Get free key at: dash.cloudflare.com → Turnstile → Add Site
  turnstile_site_key: 'YOUR_TURNSTILE_SITE_KEY',
};
