// Gedamu Electronics — Service Worker
const CACHE_NAME = 'gedamu-v1';
const BOOK_COVERS_CACHE = 'gedamu-covers-v1';

// Core files to cache for offline use
const CORE_FILES = [
  '/',
  '/index.html',
  '/style.css',
  '/script.js',
  '/config.js',
  '/api.js',
  '/admin/dashboard.html',
  '/admin/dashboard.css',
  '/admin/dashboard.js',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css',
];

// Book cover URLs to cache permanently
const BOOK_COVERS = [
  'https://covers.openlibrary.org/b/isbn/9780735211292-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780984358106-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780307887894-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781401958237-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781501197277-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781949759228-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781544512273-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781612680194-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780060555665-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781585424337-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780857197689-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780804139021-M.jpg',
  // Best sellers covers
  'https://covers.openlibrary.org/b/isbn/9780743269513-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780671027032-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781455586691-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780307465351-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780374533557-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780316017930-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781591846444-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780062407801-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781501124020-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780307951526-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780307463746-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781591848363-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781501121746-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9781591847786-M.jpg',
  'https://covers.openlibrary.org/b/isbn/9780066620992-M.jpg',
];

// Install — cache everything
self.addEventListener('install', event => {
  event.waitUntil(
    Promise.all([
      caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_FILES).catch(() => {})),
      caches.open(BOOK_COVERS_CACHE).then(cache =>
        Promise.all(BOOK_COVERS.map(url =>
          cache.add(url).catch(() => {}) // ignore individual failures
        ))
      ),
    ]).then(() => self.skipWaiting())
  );
});

// Activate — clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME && k !== BOOK_COVERS_CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — serve from cache, fall back to network
self.addEventListener('fetch', event => {
  const url = event.request.url;

  // Book covers — cache first, always
  if (url.includes('covers.openlibrary.org')) {
    event.respondWith(
      caches.open(BOOK_COVERS_CACHE).then(cache =>
        cache.match(event.request).then(cached => {
          if (cached) return cached;
          return fetch(event.request).then(response => {
            cache.put(event.request, response.clone());
            return response;
          }).catch(() => cached);
        })
      )
    );
    return;
  }

  // Core files — cache first
  if (url.includes(self.location.origin) || url.includes('cdnjs.cloudflare.com')) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          if (response.ok) {
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, response.clone()));
          }
          return response;
        }).catch(() => cached);
      })
    );
    return;
  }

  // Everything else — network first
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
});
