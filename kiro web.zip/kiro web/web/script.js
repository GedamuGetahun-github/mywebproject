// ── HUMAN / CAPTCHA CHECK ──────────────────────────────────────
const captchaChallenges = [
  { label: 'Select all 🔧 tools',       correct: ['🔧','🔧','🔧'], pool: ['🔧','📱','💻','🔧','📺','🔧','🖨️','⚡','🔧'] },
  { label: 'Select all 📱 phones',      correct: ['📱','📱','📱'], pool: ['📱','🔧','💻','📱','📺','📱','🖨️','⚡','💻'] },
  { label: 'Select all ⚡ power icons', correct: ['⚡','⚡','⚡'], pool: ['⚡','📱','💻','⚡','📺','⚡','🔧','🖨️','💻'] },
  { label: 'Select all 💻 laptops',     correct: ['💻','💻','💻'], pool: ['💻','🔧','📱','💻','📺','💻','🖨️','⚡','📱'] },
  { label: 'Select all 📺 TVs',         correct: ['📺','📺','📺'], pool: ['📺','🔧','📱','📺','💻','📺','🖨️','⚡','📱'] },
];

let currentCaptchaTarget = null;
let currentChallenge     = null;
let captchaVerified      = { repair: false, review: false };
let captchaAttempts      = 0;
let captchaLocked        = false;

function startCaptcha(target) {
  if (captchaVerified[target]) return;
  if (captchaLocked) return;
  currentCaptchaTarget = target;
  captchaAttempts = 0;

  const spinner = document.getElementById(target + 'Spinner');
  spinner.classList.add('checking');
  setTimeout(() => {
    spinner.classList.remove('checking');
    generateCaptcha();
    document.getElementById('captchaModal').classList.add('active');
  }, 600);
}

function generateCaptcha() {
  if (captchaLocked) return;
  captchaAttempts = 0;
  currentChallenge = captchaChallenges[Math.floor(Math.random() * captchaChallenges.length)];
  document.getElementById('captchaLabel').textContent = currentChallenge.label;
  document.getElementById('captchaError').textContent = '';

  // Shuffle pool
  const shuffled = [...currentChallenge.pool].sort(() => Math.random() - 0.5);
  const grid = document.getElementById('captchaGrid');
  grid.innerHTML = shuffled.map((emoji, i) =>
    `<div class="captcha-tile" data-emoji="${emoji}" onclick="toggleTile(this)">${emoji}</div>`
  ).join('');
}

function toggleTile(el) {
  el.classList.toggle('selected');
}

function verifyCaptcha() {
  const selected = [...document.querySelectorAll('.captcha-tile.selected')].map(t => t.dataset.emoji);
  const correct  = currentChallenge.correct;
  const errEl    = document.getElementById('captchaError');

  // Check: must select exactly the correct emojis (same count)
  const sortedSel = [...selected].sort().join('');
  const sortedCor = [...correct].sort().join('');

  if (selected.length === 0) {
    errEl.textContent = '⚠️ Please select the matching images.';
    return;
  }

  if (sortedSel !== sortedCor) {
    captchaAttempts++;
    document.querySelectorAll('.captcha-tile').forEach(t => t.classList.remove('selected'));

    if (captchaAttempts >= 2) {
      // Lock and show Try Again with countdown
      captchaLocked = true;
      let secs = 10;
      errEl.style.color = '#ef4444';
      errEl.textContent = `❌ Too many wrong attempts. Try again in ${secs}s`;
      document.querySelector('.captcha-verify-btn').disabled = true;
      document.querySelector('.captcha-refresh').disabled = true;

      const timer = setInterval(() => {
        secs--;
        if (secs <= 0) {
          clearInterval(timer);
          captchaLocked = false;
          captchaAttempts = 0;
          errEl.textContent = '';
          document.querySelector('.captcha-verify-btn').disabled = false;
          document.querySelector('.captcha-refresh').disabled = false;
          generateCaptcha();
          errEl.style.color = '#10b981';
          errEl.textContent = '✅ You can try again now.';
          setTimeout(() => { errEl.textContent = ''; }, 2000);
        } else {
          errEl.textContent = `❌ Too many wrong attempts. Try again in ${secs}s`;
        }
      }, 1000);
    } else {
      errEl.style.color = '#ef4444';
      errEl.textContent = `❌ Incorrect. ${2 - captchaAttempts} attempt${2 - captchaAttempts > 1 ? 's' : ''} remaining.`;
      setTimeout(generateCaptcha, 800);
    }
    return;
  }

  // Passed
  closeCaptcha();
  captchaVerified[currentCaptchaTarget] = true;

  const spinner = document.getElementById(currentCaptchaTarget + 'Spinner');
  const label   = document.getElementById(currentCaptchaTarget + 'CaptchaLabel');
  const box     = document.getElementById(currentCaptchaTarget + 'Captcha');
  spinner.classList.add('done');
  label.textContent = 'Verified ✓';
  box.classList.add('verified');

  // Auto-hide after 1.5s
  setTimeout(() => { box.style.display = 'none'; }, 1500);
}

function closeCaptcha() {
  document.getElementById('captchaModal').classList.remove('active');
  if (!captchaLocked) captchaAttempts = 0;
}

// Block form submit if captcha not verified
const _origHandleSubmit = handleSubmit;
handleSubmit = function(e) {
  if (!captchaVerified.repair) {
    e.preventDefault();
    const msg = document.getElementById('formMsg');
    msg.style.color = '#f97316';
    msg.textContent = '⚠️ Please complete the human verification first.';
    document.getElementById('repairCaptcha').style.border = '2px solid #f97316';
    setTimeout(() => { msg.textContent = ''; document.getElementById('repairCaptcha').style.border = ''; }, 3000);
    return;
  }
  _origHandleSubmit(e);
  captchaVerified.repair = false;
  resetCaptchaBox('repair');
};

const _origSubmitReview = submitReview;
submitReview = function(e) {
  if (!captchaVerified.review) {
    e.preventDefault();
    const msg = document.getElementById('reviewMsg');
    msg.style.color = '#f97316';
    msg.textContent = '⚠️ Please complete the human verification first.';
    document.getElementById('reviewCaptcha').style.border = '2px solid #f97316';
    setTimeout(() => { msg.textContent = ''; document.getElementById('reviewCaptcha').style.border = ''; }, 3000);
    return;
  }
  _origSubmitReview(e);
  captchaVerified.review = false;
  resetCaptchaBox('review');
};

function resetCaptchaBox(target) {
  const spinner = document.getElementById(target + 'Spinner');
  const label   = document.getElementById(target + 'CaptchaLabel');
  const box     = document.getElementById(target + 'Captcha');
  spinner.className = 'captcha-spinner';
  label.textContent = "I'm not a robot";
  box.classList.remove('verified');
  box.style.border = '';
  box.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('captchaModal');
  if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeCaptcha(); });
});

// ── NAVBAR SEARCH ──────────────────────────────────────────────
const navServices = [
  { title: 'TV Repair',          icon: 'fa-tv',          url: 'services/tv-repair.html',       desc: 'LED, LCD, OLED, CRT repair' },
  { title: 'Laptop & PC',        icon: 'fa-laptop',      url: 'services/laptop-pc.html',       desc: 'Hardware, software, upgrades' },
  { title: 'Mobile Phones',      icon: 'fa-mobile-alt',  url: 'services/mobile-phones.html',   desc: 'Screen, battery, charging port' },
  { title: 'Home Appliances',    icon: 'fa-blender',     url: 'services/home-appliances.html', desc: 'Fridge, washing machine, microwave' },
  { title: 'Printers & Scanners',icon: 'fa-print',       url: 'services/printers.html',        desc: 'Ink, roller, connectivity' },
  { title: 'Power Systems',      icon: 'fa-car-battery', url: 'services/power-systems.html',   desc: 'UPS, inverter, solar' },
  { title: 'Contact Us',         icon: 'fa-phone',       url: '#contact',                      desc: 'Get in touch with us' },
  { title: 'About Us',           icon: 'fa-info-circle', url: '#about',                        desc: 'Learn about Gedamu Electronics' },
  { title: 'Feedback',           icon: 'fa-star',        url: '#feedback',                     desc: 'Leave a review' },
];

function handleNavSearch(q) {
  const dropdown = document.getElementById('navSearchDropdown');
  const clearBtn = document.getElementById('navSearchClear');
  clearBtn.style.display = q ? 'flex' : 'none';
  if (!q.trim()) { dropdown.classList.remove('open'); return; }

  const results = navServices.filter(s =>
    s.title.toLowerCase().includes(q.toLowerCase()) ||
    s.desc.toLowerCase().includes(q.toLowerCase())
  );

  if (!results.length) {
    dropdown.innerHTML = `<div class="nsd-empty">No results for "${q}"</div>`;
  } else {
    dropdown.innerHTML = results.map(s => `
      <a class="nsd-item" href="${s.url}" onclick="closeNavSearch()">
        <i class="fas ${s.icon}"></i>
        <div>
          <div style="font-weight:600">${s.title}</div>
          <div style="font-size:0.75rem;color:#94a3b8">${s.desc}</div>
        </div>
      </a>`).join('');
  }
  dropdown.classList.add('open');
}

function clearNavSearch() {
  document.getElementById('navSearchInput').value = '';
  handleNavSearch('');
  document.getElementById('navSearchInput').focus();
}

function closeNavSearch() {
  document.getElementById('navSearchDropdown').classList.remove('open');
  document.getElementById('navSearchInput').value = '';
  document.getElementById('navSearchClear').style.display = 'none';
}

// Close dropdown on outside click
document.addEventListener('click', e => {
  const box = document.querySelector('.nav-search-box');
  if (box && !box.contains(e.target)) closeNavSearch();
});

// ── SERVICES SEARCH ────────────────────────────────────────────
function filterServices(q) {
  const query   = q.toLowerCase().trim();
  const cards   = document.querySelectorAll('.services-grid .card');
  const clearBtn = document.getElementById('searchClear');
  const noMsg   = document.getElementById('noServicesMsg');
  const noQuery = document.getElementById('noServicesQuery');
  let visible   = 0;

  clearBtn.style.display = query ? 'flex' : 'none';

  cards.forEach(card => {
    const text = card.textContent.toLowerCase();
    const match = !query || text.includes(query);
    card.classList.toggle('hidden-card', !match);
    if (match) visible++;
  });

  if (noMsg) {
    noMsg.style.display = visible === 0 ? 'block' : 'none';
    if (noQuery) noQuery.textContent = q;
  }
}

function clearServiceSearch() {
  const input = document.getElementById('servicesSearch');
  input.value = '';
  filterServices('');
  input.focus();
}

// ── COOKIE CONSENT ─────────────────────────────────────────────
function initCookieConsent() {
  const consent = localStorage.getItem('gedamu_cookie_consent');
  if (!consent) {
    // Show banner after short delay
    setTimeout(() => {
      document.getElementById('cookieBanner').classList.add('show');
    }, 1200);
  }
}

function setCookieConsent(choice) {
  localStorage.setItem('gedamu_cookie_consent', choice);
  localStorage.setItem('gedamu_cookie_date', new Date().toISOString().slice(0,10));
  const banner = document.getElementById('cookieBanner');
  banner.classList.remove('show');
  banner.classList.add('hide');

  // If declined, clear non-essential storage
  if (choice === 'declined') {
    localStorage.removeItem('gedamu-lang');
    localStorage.removeItem('gedamu-theme');
  }
}

initCookieConsent();

// ── CONTACT CONFIG LOADER ──────────────────────────────────────
function applyContactConfig() {
  const c = SITE_CONFIG;

  // Fill text spans/anchors
  document.querySelectorAll('[data-contact]').forEach(el => {
    const key = el.getAttribute('data-contact');
    if (c[key]) el.textContent = c[key];
  });

  // Fill href attributes (tel:phone, mailto:email, or direct url)
  document.querySelectorAll('[data-contact-href]').forEach(el => {
    const raw = el.getAttribute('data-contact-href');
    if (raw.includes(':')) {
      const [scheme, key] = raw.split(':');
      if (c[key]) el.href = scheme + ':' + c[key].replace(/\s/g, '');
    } else {
      if (c[raw]) el.href = c[raw];
    }
  });

  document.title = c.business_name;
}

applyContactConfig();

// ── TRANSLATIONS ──────────────────────────────────────────────
const translations = {
  en: {
    nav_home: 'Home', nav_services: 'Services', nav_about: 'About', nav_contact: 'Contact',
    hero_title: 'Gedex Electronics Maintenance',
    hero_sub: 'Fast, reliable, and affordable repair services for all your electronic devices.',
    hero_btn: 'Book a Repair',
    services_title: 'Our Services',
    svc1_title: 'TV Repair',        svc1_desc: 'LED, LCD, OLED, and CRT television diagnostics and repair.',
    svc2_title: 'Laptop & PC',      svc2_desc: 'Hardware replacement, software troubleshooting, and upgrades.',
    svc3_title: 'Mobile Phones',    svc3_desc: 'Screen replacement, battery swap, charging port fixes and more.',
    svc4_title: 'Home Appliances',  svc4_desc: 'Refrigerators, washing machines, microwaves, and other appliances.',
    svc5_title: 'Printers & Scanners', svc5_desc: 'Ink system cleaning, roller replacement, and connectivity fixes.',
    svc6_title: 'Power Systems',    svc6_desc: 'UPS, inverters, solar systems, and power supply repairs.',
    learn_more: 'Learn More',
    about_title: 'About Us',
    about_desc: 'Gedamu Electronics Maintenance has been serving customers with top-quality repair and maintenance services for over 10 years. Our certified technicians handle everything from small gadgets to large industrial equipment.',
    about_f1: 'Certified & Experienced Technicians', about_f2: '90-Day Repair Warranty',
    about_f3: 'Genuine Spare Parts',                 about_f4: 'Same-Day Service Available',
    stat1: 'Devices Repaired', stat2: 'Years Experience', stat3: 'Customer Satisfaction', stat4: 'Support Available',
    contact_title: 'Contact Us',
    working_hours: 'Mon – Sat: 8:00 AM – 6:00 PM',
    send_btn: 'Send Message',
    footer_copy: '© 2026 Gedamu Electronics Maintenance. All rights reserved.',
    ph_name: 'Your Name', ph_email: 'Your Email', ph_device: 'Device / Issue', ph_desc: 'Describe the problem...'
  },
  am: {
    nav_home: 'መነሻ', nav_services: 'አገልግሎቶች', nav_about: 'ስለ እኛ', nav_contact: 'ያግኙን',
    hero_title: 'የGedex ኤሌክትሮኒክስ ጥገና ባለሙያዎች',
    hero_sub: 'ለሁሉም የኤሌክትሮኒክስ መሳሪያዎችዎ ፈጣን፣ አስተማማኝ እና ተመጣጣኝ የጥገና አገልግሎት።',
    hero_btn: 'ጥገና ያስይዙ',
    services_title: 'አገልግሎቶቻችን',
    svc1_title: 'ቴሌቪዥን ጥገና',     svc1_desc: 'LED፣ LCD፣ OLED እና CRT ቴሌቪዥኖች ምርመራ እና ጥገና።',
    svc2_title: 'ላፕቶፕ እና ፒሲ',    svc2_desc: 'ሃርድዌር ለውጥ፣ ሶፍትዌር ችግር ፍቺ እና ማሻሻያ።',
    svc3_title: 'ሞባይል ስልኮች',      svc3_desc: 'ስክሪን ለውጥ፣ ባትሪ ለውጥ፣ የቻርጂንግ ፖርት ጥገና እና ሌሎችም።',
    svc4_title: 'የቤት ዕቃዎች',       svc4_desc: 'ማቀዝቀዣ፣ የልብስ ማጠቢያ፣ ማይክሮዌቭ እና ሌሎች የቤት ዕቃዎች።',
    svc5_title: 'ፕሪንተር እና ስካነር', svc5_desc: 'የቀለም ስርዓት ማጽዳት፣ ሮለር ለውጥ እና የግንኙነት ጥገና።',
    svc6_title: 'የኃይል ስርዓቶች',    svc6_desc: 'UPS፣ ኢንቨርተር፣ የፀሐይ ስርዓቶች እና የኃይል አቅርቦት ጥገና።',
    learn_more: 'ተጨማሪ ይወቁ',
    about_title: 'ስለ እኛ',
    about_desc: 'ገዳሙ ኤሌክትሮኒክስ ጥገና ለ10 ዓመታት በላይ ለደንበኞቻቸው ከፍተኛ ጥራት ያለው የጥገና አገልግሎት ሲሰጥ ቆይቷል። የተረጋገጡ ቴክኒሻኖቻችን ከትናንሽ መሳሪያዎች እስከ ትልልቅ ኢንዱስትሪ ዕቃዎች ድረስ ሁሉንም ያስተናግዳሉ።',
    about_f1: 'የተረጋገጡ እና ልምድ ያላቸው ቴክኒሻኖች', about_f2: 'የ90 ቀን የጥገና ዋስትና',
    about_f3: 'ዋና ዋና መለዋወጫ ዕቃዎች',             about_f4: 'በዕለቱ አገልግሎት ይገኛል',
    stat1: 'የተጠገኑ መሳሪያዎች', stat2: 'ዓመታት ልምድ', stat3: 'የደንበኛ እርካታ', stat4: 'ድጋፍ ይገኛል',
    contact_title: 'ያግኙን',
    working_hours: 'ሰኞ – ቅዳሜ: ከጠዋቱ 2:00 – ከምሽቱ 12:00',
    send_btn: 'መልዕክት ላክ',
    footer_copy: '© 2026 ገዳሙ ኤሌክትሮኒክስ ጥገና። መብቱ በሕግ የተጠበቀ ነው።',
    ph_name: 'ስምዎ', ph_email: 'ኢሜይልዎ', ph_device: 'መሳሪያ / ችግር', ph_desc: 'ችግሩን ይግለጹ...'
  },
  or: {
    nav_home: 'Mana', nav_services: 'Tajaajila', nav_about: 'Waa\'ee Keenya', nav_contact: 'Nu Quunnamaa',
    hero_title: 'Gedex Suphaa Elektirooniksii',
    hero_sub: 'Tajaajila suphaa ariifataa, amanamaa fi gatii madaalawaa meeshaalee elektirooniksii keessaniif.',
    hero_btn: 'Suphaa Qabadhu',
    services_title: 'Tajaajila Keenya',
    svc1_title: 'Suphaa TV',           svc1_desc: 'Qorannoo fi suphaa televizhinii LED, LCD, OLED fi CRT.',
    svc2_title: 'Laptop fi PC',        svc2_desc: 'Jijjiirraa hardware, furmaata software fi fooyya\'iinsa.',
    svc3_title: 'Bilbila Harkaa',      svc3_desc: 'Jijjiirraa screen, baatarii, suphaa port chaarjii fi kkf.',
    svc4_title: 'Meeshaalee Mana',     svc4_desc: 'Firiji, maashinii uffata dhiquu, microwave fi meeshaalee biroo.',
    svc5_title: 'Pirinteraa fi Iskaaneraa', svc5_desc: 'Qulqulleessuu ink, jijjiirraa roller fi suphaa walqunnamtii.',
    svc6_title: 'Sirna Humna',         svc6_desc: 'UPS, inverter, sirna aduu fi suphaa dhiyeessii humna.',
    learn_more: 'Dabalata Baradhu',
    about_title: 'Waa\'ee Keenya',
    about_desc: 'Suphaa Elektirooniksii Gedamu waggaa 10 ol tajaajila suphaa fi kunuunsa qulqullina olaanaa qabu kennaa tureera. Teekniishinoota keenya ragaalee qaban meeshaalee xixiqqaa hanga meeshaalee industirii guguddaa hunda ni kunuunsu.',
    about_f1: 'Teekniishinoota Ragaalee fi Muuxannoo Qaban', about_f2: 'Waadaa Suphaa Guyyaa 90',
    about_f3: 'Qooda Jijjiirraa Dhugaa',                    about_f4: 'Tajaajila Guyyaa Sanaa Ni Argama',
    stat1: 'Meeshaalee Suphamee', stat2: 'Waggaa Muuxannoo', stat3: 'Gammachuu Maamilaa', stat4: 'Deeggarsa Ni Argama',
    contact_title: 'Nu Quunnamaa',
    working_hours: 'Wiixata – Sanbata: Sa\'a 2:00 – 12:00',
    send_btn: 'Ergaa Ergi',
    footer_copy: '© 2026 Suphaa Elektirooniksii Gedamu. Mirgi seeraan eegameera.',
    ph_name: 'Maqaa Keessan', ph_email: 'Imeelii Keessan', ph_device: 'Meeshaa / Rakkoo', ph_desc: 'Rakkoo ibsi...'
  }
};

let currentLang = localStorage.getItem('gedamu-lang') || 'en';

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem('gedamu-lang', lang);
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
  document.querySelector(`.lang-btn[onclick="setLang('${lang}')"]`).classList.add('active');
  applyTranslations();
}

function applyTranslations() {
  const t = translations[currentLang];
  // text nodes
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (t[key]) el.textContent = t[key];
  });
  // placeholders
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const key = el.getAttribute('data-i18n-ph');
    if (t[key]) el.setAttribute('placeholder', t[key]);
  });
  // html lang attribute
  document.documentElement.lang = currentLang;
}

// Apply on load
applyTranslations();
document.querySelector(`.lang-btn[onclick="setLang('${currentLang}')"]`)?.classList.add('active');
document.querySelectorAll('.lang-btn').forEach(b => {
  if (b.getAttribute('onclick') !== `setLang('${currentLang}')`) b.classList.remove('active');
});

// ── THEME TOGGLE ───────────────────────────────────────────────
const themeToggle = document.getElementById('themeToggle');
const themes = ['dark', 'light', 'bright', 'navy'];
const icons  = ['fa-moon', 'fa-sun', 'fa-circle-half-stroke', 'fa-water'];
const labels = ['Dark Mode', 'Light Mode', 'Bright Mode', 'Navy Mode'];
let themeIndex = 0;

// Load saved theme
const saved = localStorage.getItem('gedamu-theme');
if (saved !== null) {
  themeIndex = parseInt(saved);
  applyTheme();
}

themeToggle.addEventListener('click', () => {
  themeIndex = (themeIndex + 1) % themes.length;
  applyTheme();
  localStorage.setItem('gedamu-theme', themeIndex);
});

function applyTheme() {
  document.body.classList.remove('light', 'bright', 'navy');
  if (themes[themeIndex] !== 'dark') {
    document.body.classList.add(themes[themeIndex]);
  }
  themeToggle.innerHTML = `<i class="fas ${icons[themeIndex]}"></i>`;
  themeToggle.title = labels[(themeIndex + 1) % themes.length];
}

// ── MULTI-STEP REPAIR FORM ─────────────────────────────────────
const deviceBrands = {
  TV:           ['Samsung','LG','Sony','TCL','Hisense','Skyworth','Other'],
  Laptop:       ['HP','Dell','Lenovo','Asus','Acer','Apple','Toshiba','Other'],
  Mobile:       ['Samsung','iPhone','Tecno','Infinix','Huawei','Nokia','Xiaomi','Other'],
  Appliance:    ['Samsung','LG','Ariston','Bosch','Haier','Nasco','Other'],
  Printer:      ['HP','Canon','Epson','Brother','Lexmark','Other'],
  'Power System':['APC','Luminous','Sukam','Felicity','Generic','Other'],
};

const brandModels = {
  // Mobile
  Samsung: ['Galaxy A05','Galaxy A15','Galaxy A25','Galaxy A35','Galaxy A55','Galaxy M11','Galaxy M12','Galaxy M13','Galaxy M14','Galaxy M31','Galaxy M32','Galaxy S21','Galaxy S22','Galaxy S23','Galaxy S24','Galaxy Note 20','Other'],
  iPhone:  ['iPhone 11','iPhone 12','iPhone 12 Pro','iPhone 13','iPhone 13 Pro','iPhone 14','iPhone 14 Pro','iPhone 15','iPhone 15 Pro','iPhone SE','Other'],
  Tecno:   ['Spark 10','Spark 20','Camon 20','Camon 30','Pop 7','Pop 8','Pova 5','Pova 6','Other'],
  Infinix: ['Hot 30','Hot 40','Note 30','Note 40','Smart 8','Zero 30','Zero 40','Other'],
  Huawei:  ['Y9s','Y7a','Nova 9','Nova 11','P30','P40','P50','Mate 50','Other'],
  Nokia:   ['G21','G42','C32','C22','X30','Other'],
  Xiaomi:  ['Redmi 12','Redmi 13','Redmi Note 12','Redmi Note 13','Mi 11','POCO X5','POCO M5','Other'],
  // Laptop
  HP:      ['Pavilion 15','Pavilion 14','Envy 13','Envy 15','EliteBook 840','ProBook 450','Victus 15','Omen 16','Other'],
  Dell:    ['Inspiron 15','Inspiron 14','Vostro 15','Vostro 14','XPS 13','XPS 15','Latitude 5420','Other'],
  Lenovo:  ['IdeaPad 3','IdeaPad 5','ThinkPad E14','ThinkPad T14','Legion 5','Yoga 7','Other'],
  Asus:    ['VivoBook 15','VivoBook 14','ZenBook 14','ROG Strix G15','TUF Gaming A15','Other'],
  Acer:    ['Aspire 5','Aspire 7','Swift 3','Nitro 5','Predator Helios','Other'],
  Apple:   ['MacBook Air M1','MacBook Air M2','MacBook Air M3','MacBook Pro 13','MacBook Pro 14','MacBook Pro 16','Other'],
  Toshiba: ['Satellite C55','Satellite L50','Dynabook E10','Other'],
  // TV
  LG:      ['C3 OLED','C4 OLED','B3 OLED','UQ7500','UQ8000','NANO75','NANO85','Other'],
  Sony:    ['X80K','X90K','X95K','A80K OLED','A90K OLED','Bravia 7','Other'],
  TCL:     ['P635','P745','C645','C745','S5400','Other'],
  Hisense: ['A6K','U6K','U8K','E7K','Other'],
  Skyworth:['SUC8300','STC65','Other'],
  // Appliance
  Ariston: ['NMTM 1922','NMTM 1723','Other'],
  Bosch:   ['Serie 4','Serie 6','Serie 8','Other'],
  Haier:   ['HW70','HW80','HW100','Other'],
  Nasco:   ['WM-1000','WM-800','Other'],
  // Printer
  Canon:   ['PIXMA G2010','PIXMA G3010','PIXMA G6020','imageCLASS MF3010','Other'],
  Epson:   ['L3110','L3150','L5190','L6190','EcoTank ET-2800','Other'],
  Brother: ['DCP-T420W','DCP-T520W','MFC-T920DW','Other'],
  Lexmark: ['MB2236','MX331','Other'],
  // Power
  APC:     ['Back-UPS 600VA','Back-UPS 1000VA','Smart-UPS 1500VA','Other'],
  Luminous: ['Eco Volt 850','Eco Volt 1050','Zelio 1100','Other'],
  Sukam:   ['Falcon 1400','Shiny 700','Other'],
  Felicity:['FP1012','FP2024','Other'],
  Generic: ['Other'],
};

// fallback for brands with no specific models
const defaultModels = ['Other'];

const deviceProblems = {
  TV:           ['No Power','Blank Screen','No Sound','Color Issue','Remote Not Working','Cracked Screen','Wi-Fi Issue','Overheating','Software Update Issue','Password / Lock Reset'],
  Laptop:       ['Won\'t Turn On','Broken Screen','Slow Performance','Virus/Malware','Battery Issue','Keyboard Broken','Overheating','No Wi-Fi','OS Reinstallation','BIOS Password Reset','Windows Password Reset','Software Installation','Driver Issues'],
  Mobile:       ['Cracked Screen','Battery Drains Fast','Won\'t Charge','Water Damage','No Sound','Camera Broken','Network Issue','Won\'t Turn On','Pattern/PIN Reset','Google Account (FRP) Bypass','Software Flash / ROM','App Issues','Hang / Freezing'],
  Appliance:    ['Not Turning On','Not Cooling','Not Heating','Making Noise','Water Leaking','Not Spinning','Door Issue','Software/Control Board Error','Other'],
  Printer:      ['Not Printing','Paper Jam','Poor Quality','No Ink','Wi-Fi Issue','Scanner Broken','Won\'t Power On','Driver / Software Issue','Other'],
  'Power System':['No Output','Battery Dead','Overload Shutdown','Inverter Fault','Charging Issue','Noise','Firmware Issue','Other'],
};

let selectedDevice = '';
let selectedProblems = [];

function selectDeviceFromDropdown(type) {
  selectedDevice = type;
  const brandSel = document.getElementById('deviceBrand');
  const modelSel = document.getElementById('deviceModel');
  brandSel.innerHTML = '<option value="">Select brand</option>';
  modelSel.innerHTML = '<option value="">Select brand first</option>';
  (deviceBrands[type] || []).forEach(b => {
    const opt = document.createElement('option');
    opt.value = b; opt.textContent = b;
    brandSel.appendChild(opt);
  });
}

// called when brand changes
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('deviceBrand').addEventListener('change', function () {
    const modelSel = document.getElementById('deviceModel');
    const models = brandModels[this.value] || defaultModels;
    modelSel.innerHTML = '<option value="">Select model</option>';
    models.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m; opt.textContent = m;
      modelSel.appendChild(opt);
    });
  });
});

function goStep(n) {
  // Validate step 1
  if (n === 2 && !selectedDevice) {
    alert('Please select a device type first.'); return;
  }
  // Validate step 2 — must select a chip OR write in textarea
  if (n === 3) {
    const desc = document.getElementById('problemDesc').value.trim();
    if (selectedProblems.length === 0 && desc === '') {
      const chips = document.getElementById('problemChips');
      chips.style.outline = '2px solid #ef4444';
      chips.style.borderRadius = '8px';
      const ta = document.getElementById('problemDesc');
      ta.style.borderColor = '#ef4444';
      ta.placeholder = '⚠️ Please select an issue above or describe the problem here...';
      ta.focus();
      return;
    }
    // clear error styles
    document.getElementById('problemChips').style.outline = '';
    document.getElementById('problemDesc').style.borderColor = '';
  }
  // Populate problem chips on entering step 2
  if (n === 2) {
    const chips = document.getElementById('problemChips');
    chips.innerHTML = '';
    selectedProblems = [];
    (deviceProblems[selectedDevice] || []).forEach(p => {
      const c = document.createElement('span');
      c.className = 'chip';
      c.textContent = p;
      c.onclick = () => {
        c.classList.toggle('selected');
        selectedProblems = [...document.querySelectorAll('.chip.selected')].map(x => x.textContent);
      };
      chips.appendChild(c);
    });
  }
  // Build summary on entering step 3
  if (n === 3) {
    const brand = document.getElementById('deviceBrand').value;
    const model = document.getElementById('deviceModel').value;    const desc  = document.getElementById('problemDesc').value;
    const urgency = document.querySelector('input[name="urgency"]:checked')?.value || 'Normal';
    document.getElementById('requestSummary').innerHTML =
      `<strong>Device:</strong> ${selectedDevice}${brand ? ' — ' + brand : ''}${model ? ' ' + model : ''}<br>
       <strong>Problems:</strong> ${selectedProblems.length ? selectedProblems.join(', ') : 'Not specified'}<br>
       ${desc ? `<strong>Details:</strong> ${desc}<br>` : ''}
       <strong>Urgency:</strong> ${urgency}`;
  }

  // Switch steps
  document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
  document.getElementById('step' + n).classList.add('active');

  // Update dots & lines
  [1,2,3].forEach(i => {
    const dot  = document.getElementById('dot' + i);
    const line = document.querySelectorAll('.step-line')[i - 1];
    dot.classList.toggle('active', i === n);
    dot.classList.toggle('done',   i < n);
    if (line) line.classList.toggle('done', i < n);
  });
}

// Contact form submit
function handleSubmit(e) {
  e.preventDefault();

  // Check login at submit time
  if (!getUser()) {
    showAuthRequired('formMsg', 'repair');
    return;
  }

  const user  = getUser();
  const name  = user ? user.name : document.getElementById('clientName').value;
  const phone = document.getElementById('clientPhone').value;
  if (!name || !phone) { alert('Please fill in your name and phone.'); return; }

  const brand   = document.getElementById('deviceBrand').value;
  const model   = document.getElementById('deviceModel').value;
  const desc    = document.getElementById('problemDesc').value.trim();
  const urgency = document.querySelector('input[name="urgency"]:checked')?.value || 'Normal';
  const problems = selectedProblems.length ? selectedProblems.join(', ') : desc || 'Not specified';

  // Estimate cost based on device type
  const costMap = {
    TV: 'ETB 500 – 2,500', Laptop: 'ETB 300 – 1,500', Mobile: 'ETB 200 – 800',
    Appliance: 'ETB 300 – 1,200', Printer: 'ETB 150 – 700', 'Power System': 'ETB 400 – 1,500'
  };
  const estimatedCost = costMap[selectedDevice] || 'ETB 150 – 2,500';

  const request = {
    id:       'R-' + Date.now(),
    device:   `${selectedDevice}${brand ? ' — ' + brand : ''}${model ? ' ' + model : ''}`,
    problems,
    urgency,
    cost:     estimatedCost,
    status:   'Pending',
    date:     new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}),
    phone,
    name,
    email:    user ? user.email : ''
  };

  // Save to user's repair history
  if (user) {
    const allRequests = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
    if (!allRequests[user.email]) allRequests[user.email] = [];
    allRequests[user.email].unshift(request);
    localStorage.setItem('gedamu_repair_requests', JSON.stringify(allRequests));
  }

  const msg = document.getElementById('formMsg');
  msg.style.color = 'green';
  msg.textContent = `✅ Request submitted! Estimated cost: ${estimatedCost}. We'll call you at ${phone} shortly.`;
  e.target.reset();
  selectedDevice = ''; selectedProblems = [];
  goStep(1);
  setTimeout(() => { msg.textContent = ''; }, 6000);
}

// ── SOCIAL AUTH ────────────────────────────────────────────────
function socialAuth(provider, action) {
  const overlay  = document.getElementById('socialOverlay');
  const msgEl    = document.getElementById('socialPopupMsg');
  const noteEl   = document.getElementById('socialPopupNote');
  const spinner  = document.querySelector('.social-spinner');
  const label    = provider === 'google' ? 'Google' : 'Facebook';
  const actionLabel = action === 'signin' ? 'Signing in' : 'Creating account';

  // Show loading state
  overlay.classList.add('active');
  spinner.style.display = 'block';
  spinner.style.borderTopColor = provider === 'google' ? '#ea4335' : '#1877f2';
  msgEl.innerHTML = `${actionLabel} with ${label}...`;
  noteEl.textContent = 'Please wait while we connect securely.';

  // Simulate OAuth redirect delay
  setTimeout(() => {
    spinner.style.display = 'none';

    // NOTE: Real OAuth needs a backend. This simulates the flow.
    // To enable real Google login: add Google Identity Services SDK
    // To enable real Facebook login: add Facebook SDK + App ID
    msgEl.innerHTML = `<span class="error-icon"><i class="fas fa-exclamation-circle" style="color:#f97316"></i></span><br>Backend Required`;
    noteEl.innerHTML = `Real ${label} login requires a server-side OAuth setup.<br><br>
      <strong style="color:#334155">To activate:</strong><br>
      ${provider === 'google'
        ? '1. Create a project at <a href="https://console.cloud.google.com" target="_blank" style="color:#f97316">Google Cloud Console</a><br>2. Enable Google Identity API<br>3. Add your Client ID to config.js'
        : '1. Create an app at <a href="https://developers.facebook.com" target="_blank" style="color:#f97316">Facebook Developers</a><br>2. Enable Facebook Login<br>3. Add your App ID to config.js'}`;

    setTimeout(() => {
      overlay.classList.remove('active');
      // restore spinner for next use
      spinner.style.display = 'block';
      msgEl.textContent = 'Connecting...';
      noteEl.textContent = '';
    }, 4000);
  }, 1800);
}

// ── AUTH MODAL ─────────────────────────────────────────────────
const hamburger = document.getElementById('hamburger');
const navLinks = document.querySelector('.nav-links');

hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
  });
});

// Auth Modal
function openModal(tab) {
  document.getElementById('authModal').classList.add('active');
  switchTab(tab);
}

function closeModal() {
  document.getElementById('authModal').classList.remove('active');
  document.getElementById('authMsg').textContent = '';
}

function switchTab(tab) {
  const signinForm = document.getElementById('signinForm');
  const signupForm = document.getElementById('signupForm');
  const signinTab  = document.getElementById('signinTab');
  const signupTab  = document.getElementById('signupTab');

  if (tab === 'signin') {
    signinForm.classList.remove('hidden');
    signupForm.classList.add('hidden');
    signinTab.classList.add('active');
    signupTab.classList.remove('active');
  } else {
    signupForm.classList.remove('hidden');
    signinForm.classList.add('hidden');
    signupTab.classList.add('active');
    signinTab.classList.remove('active');
  }
  document.getElementById('authMsg').textContent = '';
}

function handleAuth(e, type) {
  e.preventDefault();
  const msg = document.getElementById('authMsg');
  msg.style.color = '';
  msg.textContent = '';

  if (type === 'signup') {
    const name  = document.querySelector('#signupForm input[type="text"]').value.trim();
    const email = document.querySelector('#signupForm input[type="email"]').value.trim();
    const pass1 = document.getElementById('signupPass').value;
    const pass2 = document.getElementById('signupPass2').value;
    const terms = document.getElementById('terms').checked;

    if (pass1.length < 6) {
      msg.style.color = '#ef4444';
      msg.textContent = '⚠️ Password must be at least 6 characters.';
      return;
    }
    if (pass1 !== pass2) {
      msg.style.color = '#ef4444';
      msg.textContent = '⚠️ Passwords do not match.';
      document.getElementById('signupPass2').style.borderColor = '#ef4444';
      return;
    }
    if (!terms) {
      msg.style.color = '#ef4444';
      msg.textContent = '⚠️ Please agree to the Terms & Privacy Policy.';
      return;
    }
    // Save user to localStorage
    const users = JSON.parse(localStorage.getItem('gedamu_users') || '[]');
    if (users.find(u => u.email === email)) {
      msg.style.color = '#ef4444';
      msg.textContent = '⚠️ An account with this email already exists.';
      return;
    }
    users.push({ name, email, password: pass1 });
    localStorage.setItem('gedamu_users', JSON.stringify(users));
    sessionStorage.setItem('gedamu_user', JSON.stringify({ name, email }));

    document.getElementById('signupPass2').style.borderColor = '';
    msg.style.color = '#10b981';
    msg.textContent = `✅ Welcome ${name}! Account created successfully.`;
  } else {
    const email = document.querySelector('#signinForm input[type="email"]').value.trim();
    const pass  = document.getElementById('signinPass').value;
    const users = JSON.parse(localStorage.getItem('gedamu_users') || '[]');
    const user  = users.find(u => u.email === email && u.password === pass);
    if (!user) {
      msg.style.color = '#ef4444';
      msg.textContent = '⚠️ Invalid email or password.';
      return;
    }
    sessionStorage.setItem('gedamu_user', JSON.stringify({ name: user.name, email: user.email }));
    msg.style.color = '#10b981';
    msg.textContent = `✅ Welcome back, ${user.name}!`;
  }

  e.target.reset();
  setTimeout(() => {
    closeModal();
    msg.textContent = '';
    updateAuthUI();
    unlockForms();
    const userName = type === 'signup'
      ? document.querySelector('#signupForm input[type="text"]')?.value.trim() || 'there'
      : JSON.parse(sessionStorage.getItem('gedamu_user') || '{}').name || 'there';
    showWelcomeToast(userName, type);
  }, 1800);
}

function togglePass(id, icon) {
  const input = document.getElementById(id);
  if (input.type === 'password') {
    input.type = 'text';
    icon.classList.replace('fa-eye', 'fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.replace('fa-eye-slash', 'fa-eye');
  }
}

function togglePass(id, icon) {
  const input = document.getElementById(id);
  if (input.type === 'password') {
    input.type = 'text';
    icon.classList.replace('fa-eye', 'fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.replace('fa-eye-slash', 'fa-eye');
  }
}

// ── USER SESSION ───────────────────────────────────────────────
function getUser() {
  return JSON.parse(sessionStorage.getItem('gedamu_user') || 'null');
}

function updateAuthUI() {
  const user = getUser();
  const authBtns = document.querySelector('.auth-buttons');
  const navLink  = document.getElementById('myRepairsNavLink');
  if (!authBtns) return;
  if (user) {
    authBtns.innerHTML = `
      <span class="user-greeting"><i class="fas fa-user-circle"></i> ${user.name}</span>
      <button class="btn-outline" onclick="openMyRepairs()"><i class="fas fa-clipboard-list"></i> My Repairs</button>
      <button class="btn-outline" onclick="logoutUser()">Sign Out</button>`;
    if (navLink) navLink.style.display = 'block';
  } else {
    authBtns.innerHTML = `
      <button class="btn-outline" onclick="openModal('signin')">Sign In</button>
      <button class="btn" onclick="openModal('signup')">Sign Up</button>`;
    if (navLink) navLink.style.display = 'none';
  }
}

function logoutUser() {
  sessionStorage.removeItem('gedamu_user');
  updateAuthUI();
  lockForms();
}

function showWelcomeToast(name, type) {
  // Remove existing toast if any
  const old = document.getElementById('welcomeToast');
  if (old) old.remove();

  const toast = document.createElement('div');
  toast.id = 'welcomeToast';
  toast.className = 'welcome-toast';
  toast.innerHTML = `
    <div class="wt-avatar">${name.charAt(0).toUpperCase()}</div>
    <div class="wt-body">
      <strong>${type === 'signup' ? '🎉 Welcome to Gedamu Electronics!' : '👋 Welcome back!'}</strong>
      <span>Hello, <em>${name}</em>! You are now signed in.</span>
    </div>
    <button class="wt-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>`;

  document.body.appendChild(toast);
  // Trigger animation
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 500);
  }, 5000);
}

// ── MY REPAIRS ─────────────────────────────────────────────────
function openMyRepairs() {
  const user = getUser();
  if (!user) { openModal('signin'); return; }
  renderMyRepairs(user);
  document.getElementById('myRepairsModal').classList.add('active');
}

function closeMyRepairs() {
  document.getElementById('myRepairsModal').classList.remove('active');
}

function renderMyRepairs(user) {
  const allRequests = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  const requests    = allRequests[user.email] || [];
  const statsEl     = document.getElementById('myRepairsStats');
  const listEl      = document.getElementById('myRepairsList');

  // Stats
  const total     = requests.length;
  const pending   = requests.filter(r => r.status === 'Pending').length;
  const progress  = requests.filter(r => r.status === 'In Progress').length;
  const completed = requests.filter(r => r.status === 'Completed').length;

  statsEl.innerHTML = `
    <div class="mr-stat"><i class="fas fa-tools" style="color:#3b82f6"></i><span>${total}</span><small>Total</small></div>
    <div class="mr-stat"><i class="fas fa-hourglass-half" style="color:#f59e0b"></i><span>${pending}</span><small>Pending</small></div>
    <div class="mr-stat"><i class="fas fa-spinner" style="color:#f97316"></i><span>${progress}</span><small>In Progress</small></div>
    <div class="mr-stat"><i class="fas fa-check-circle" style="color:#10b981"></i><span>${completed}</span><small>Completed</small></div>`;

  if (!requests.length) {
    listEl.innerHTML = `<div class="mr-empty"><i class="fas fa-inbox"></i><p>No repair requests yet.<br>Submit one below!</p></div>`;
    return;
  }

  const statusColor = { Pending:'#f59e0b', 'In Progress':'#3b82f6', Completed:'#10b981' };
  const statusBg    = { Pending:'#fef9c3', 'In Progress':'#dbeafe', Completed:'#dcfce7' };

  listEl.innerHTML = requests.map(r => `
    <div class="mr-card">
      <div class="mr-card-top">
        <div>
          <div class="mr-device"><i class="fas fa-microchip"></i> ${r.device}</div>
          <div class="mr-date"><i class="fas fa-calendar"></i> ${r.date} &nbsp;|&nbsp; <i class="fas fa-bolt"></i> ${r.urgency}</div>
        </div>
        <span class="mr-status" style="background:${statusBg[r.status]};color:${statusColor[r.status]}">${r.status}</span>
      </div>
      <div class="mr-problems"><i class="fas fa-exclamation-circle" style="color:#f97316"></i> <strong>Issue:</strong> ${r.problems}</div>
      <div class="mr-cost"><i class="fas fa-coins" style="color:#facc15"></i> <strong>Estimated Cost:</strong> <span style="color:#f97316;font-weight:700">${r.cost}</span></div>
      <div class="mr-id">Request ID: ${r.id}</div>
    </div>`).join('');
}

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('myRepairsModal');
  if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeMyRepairs(); });
});

function unlockForms() {}
function lockForms() {}

function showAuthRequired(msgId, type) {
  const msg = document.getElementById(msgId);
  if (!msg) return;
  msg.style.color = '#f97316';
  msg.innerHTML = `<i class="fas fa-lock"></i> You need to <strong style="cursor:pointer;text-decoration:underline" onclick="openModal('signin')">Sign In</strong> or <strong style="cursor:pointer;text-decoration:underline" onclick="openModal('signup')">Register</strong> to submit ${type === 'review' ? 'a review' : 'a repair request'}.`;
  msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
  setTimeout(() => { msg.innerHTML = ''; }, 6000);
}

// Init on page load
document.addEventListener('DOMContentLoaded', () => {
  updateAuthUI();
  if (getUser()) unlockForms(); else lockForms();
});

// Close modal on overlay click
document.getElementById('authModal').addEventListener('click', function(e) {
  if (e.target === this) closeModal();
});

// ── FEEDBACK / REVIEWS ─────────────────────────────────────────
let reviews = JSON.parse(localStorage.getItem('gedamu_reviews') || 'null') || [
  { name:'Abebe G.',    service:'TV Repair',        rating:5, text:'Excellent service! My Samsung TV was fixed same day. Highly recommend.', date:'Apr 10, 2026' },
  { name:'Fatuma A.',   service:'Mobile Phones',     rating:5, text:'Screen replaced perfectly. Very professional and affordable.', date:'Apr 11, 2026' },
  { name:'Tadesse B.',  service:'Laptop & PC',       rating:4, text:'Good work on my HP laptop. Took a bit longer than expected but quality is great.', date:'Apr 12, 2026' },
  { name:'Meron H.',    service:'Home Appliances',   rating:5, text:'Washing machine repaired quickly. Technician was very knowledgeable.', date:'Apr 13, 2026' },
  { name:'Dawit T.',    service:'Printers & Scanners',rating:4, text:'Printer works perfectly now. Fair pricing and friendly staff.', date:'Apr 14, 2026' },
];

let selectedRating = 0;

function saveReviews() { localStorage.setItem('gedamu_reviews', JSON.stringify(reviews)); }

function renderReviews() {
  const list = document.getElementById('reviewsList');
  const avgEl = document.getElementById('avgScore');
  const starsEl = document.getElementById('avgStars');
  const labelEl = document.getElementById('avgLabel');
  const barsEl  = document.getElementById('ratingBars');
  if (!list) return;

  // Stats
  const total = reviews.length;
  const avg   = total ? (reviews.reduce((s,r) => s+r.rating, 0) / total).toFixed(1) : '0.0';
  if (avgEl) avgEl.textContent = avg;
  if (starsEl) starsEl.innerHTML = starsHTML(Math.round(avg));
  if (labelEl) labelEl.textContent = total ? `Based on ${total} review${total>1?'s':''}` : 'No reviews yet';

  // Rating bars
  if (barsEl) {
    barsEl.innerHTML = [5,4,3,2,1].map(n => {
      const count = reviews.filter(r => r.rating === n).length;
      const pct   = total ? Math.round(count/total*100) : 0;
      return `<div class="rating-bar-row">
        <span class="rb-label">${n}★</span>
        <div class="rb-track"><div class="rb-fill" style="width:${pct}%"></div></div>
        <span class="rb-count">${count}</span>
      </div>`;
    }).join('');
  }

  // Cards
  if (reviews.length === 0) {
    list.innerHTML = '<div class="no-reviews">No reviews yet. Be the first!</div>';
    return;
  }

  const INITIAL_SHOW = 3;
  const reversed = [...reviews].sort((a, b) => b.rating - a.rating);

  const renderCards = (items) => items.map(r => `
    <div class="review-card">
      <div class="review-top">
        <span class="review-author">${r.name}</span>
        <span class="review-date">${r.date}</span>
      </div>
      <div class="review-stars">${starsHTML(r.rating)}</div>
      ${r.service ? `<span class="review-service">${r.service}</span>` : ''}
      <p class="review-text">${r.text}</p>
    </div>`).join('');

  const visible = reversed.slice(0, INITIAL_SHOW);
  const hidden  = reversed.slice(INITIAL_SHOW);

  list.innerHTML = renderCards(visible);

  // Add hidden reviews wrapped in collapsible div
  if (hidden.length > 0) {
    list.innerHTML += `
      <div class="reviews-extra" id="reviewsExtra" style="display:none">
        ${renderCards(hidden)}
      </div>
      <button class="see-all-btn" id="seeAllBtn" onclick="toggleAllReviews()">
        <i class="fas fa-chevron-down"></i> See All ${reviews.length} Reviews
      </button>`;
  }
}

function toggleAllReviews() {
  const extra = document.getElementById('reviewsExtra');
  const btn   = document.getElementById('seeAllBtn');
  const total = reviews.length;
  if (!extra) return;
  const isOpen = extra.style.display !== 'none';
  extra.style.display = isOpen ? 'none' : 'block';
  btn.innerHTML = isOpen
    ? `<i class="fas fa-chevron-down"></i> See All ${total} Reviews`
    : `<i class="fas fa-chevron-up"></i> Show Less`;
}

function starsHTML(n) {
  return [1,2,3,4,5].map(i =>
    `<i class="fa${i<=n?'s':'r'} fa-star"></i>`
  ).join('');
}

function submitReview(e) {
  e.preventDefault();

  // Check login at submit time
  if (!getUser()) {
    showAuthRequired('reviewMsg', 'review');
    return;
  }

  if (selectedRating === 0) {
    document.getElementById('reviewMsg').style.color = '#ef4444';
    document.getElementById('reviewMsg').textContent = '⚠️ Please select a star rating.';
    return;
  }
  const name    = document.getElementById('reviewName').value.trim();
  const service = document.getElementById('reviewService').value;
  const text    = document.getElementById('reviewText').value.trim();
  const now     = new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});

  reviews.push({ name, service, rating: selectedRating, text, date: now });
  saveReviews();
  renderReviews();

  e.target.reset();
  selectedRating = 0;
  document.querySelectorAll('.star-picker i').forEach(s => s.classList.remove('active'));
  const msg = document.getElementById('reviewMsg');
  msg.style.color = '#10b981';
  msg.textContent = '✅ Thank you for your feedback!';
  setTimeout(() => { msg.textContent = ''; }, 3000);
}

// Star picker interaction
document.addEventListener('DOMContentLoaded', () => {
  const stars = document.querySelectorAll('.star-picker i');
  stars.forEach(star => {
    star.addEventListener('mouseenter', () => {
      const val = +star.dataset.val;
      stars.forEach(s => s.classList.toggle('hover', +s.dataset.val <= val));
    });
    star.addEventListener('mouseleave', () => {
      stars.forEach(s => s.classList.remove('hover'));
    });
    star.addEventListener('click', () => {
      selectedRating = +star.dataset.val;
      stars.forEach(s => s.classList.toggle('active', +s.dataset.val <= selectedRating));
      document.getElementById('reviewMsg').textContent = '';
    });
  });
  renderReviews();
});

// ── BUY ME A COFFEE ────────────────────────────────────────────
let bmcSelected = 200;

const bmcAccounts = {
  'M-Pesa':             { label: 'M-Pesa Number',       num: '+251715570737', display: '+251 715 570 737', name: 'Gedamu Getahun', ussd: 'tel:*733*1*251715570737#', app: null },
  'Telebirr':           { label: 'Telebirr Number',      num: '+251954030195', display: '+251 954 030 195', name: 'Gedamu Getahun', ussd: 'tel:*127*1*251954030195#', app: 'https://telebirr.et' },
  'CBE Account':        { label: 'CBE Account Number',   num: '100058448907', display: '100058448907',  name: 'Gedamu Getahun', ussd: 'tel:*847#', app: 'https://www.combanketh.et/en/cbe-birr' },
  'Abyssinia CBE Birr': { label: 'Abyssinia Account',    num: '0XXXXXXXXXXX',  display: '0XXXXXXXXXXX',    name: 'Gedamu Getahun', ussd: 'tel:*704#', app: 'https://www.bankofabyssinia.com' },
  'Awash Bank':         { label: 'Awash Bank Account',   num: '0XXXXXXXXXXX',  display: '0XXXXXXXXXXX',    name: 'Gedamu Getahun', ussd: 'tel:*844#', app: 'https://awashbank.com' },
};

function openBMC() {
  document.getElementById('bmcModal').classList.add('active');
}

function closeBMC() {
  document.getElementById('bmcModal').classList.remove('active');
  document.getElementById('bmcAccountInfo').style.display = 'none';
  document.querySelectorAll('.bmc-method').forEach(b => b.style.borderColor = '');
}

function selectAmt(btn, val) {
  document.querySelectorAll('.bmc-amt').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  bmcSelected = parseInt(val);
  document.getElementById('bmcCustom').value = '';
}

function bmcPay(method) {
  const custom = document.getElementById('bmcCustom').value;
  const amount = custom ? parseInt(custom) : bmcSelected;

  if (!amount || amount < 10) {
    showBMCToast('⚠️ Please enter a valid amount (min 10 ETB)');
    return;
  }

  // Highlight selected method button
  document.querySelectorAll('.bmc-method').forEach(b => b.style.borderColor = '');
  event.currentTarget.style.borderColor = 'var(--primary)';

  const acc = bmcAccounts[method];
  if (acc) {
    document.getElementById('bmcAccountLabel').textContent = acc.label;
    document.getElementById('bmcAccountNum').textContent   = acc.display;
    document.getElementById('bmcAccountName').textContent  = `Account Name: ${acc.name}`;

    // Build action buttons
    const actionsEl = document.getElementById('bmcAccountActions');
    actionsEl.innerHTML = '';

    // USSD dial button (works on mobile)
    if (acc.ussd) {
      const dialBtn = document.createElement('a');
      dialBtn.href = acc.ussd;
      dialBtn.className = 'bmc-action-btn dial';
      dialBtn.innerHTML = '<i class="fas fa-phone"></i> Dial USSD';
      actionsEl.appendChild(dialBtn);
    }

    // Open app / website
    if (acc.app) {
      const appBtn = document.createElement('a');
      appBtn.href = acc.app;
      appBtn.target = '_blank';
      appBtn.rel = 'noopener';
      appBtn.className = 'bmc-action-btn app';
      appBtn.innerHTML = '<i class="fas fa-external-link-alt"></i> Open App';
      actionsEl.appendChild(appBtn);
    }

    document.getElementById('bmcAccountInfo').style.display = 'block';
  }

  showBMCToast(`Send ${amount} ETB via ${method} using the details below.`);
}

function copyAccount() {
  const num = document.getElementById('bmcAccountNum').textContent;
  navigator.clipboard.writeText(num).then(() => {
    showBMCToast('✅ Account number copied!');
  }).catch(() => {
    showBMCToast('� ' + num);
  });
}

function showBMCToast(msg) {
  const toast = document.getElementById('bmcToast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 4000);
}

// Close BMC modal on overlay click
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('bmcModal').addEventListener('click', function(e) {
    if (e.target === this) closeBMC();
  });
});





// ── API INTEGRATION OVERRIDES ──────────────────────────────────
// All functions work offline (localStorage) AND online (MongoDB API).

function isOfflineError(err) {
  return err.message.includes('offline') || err.message.includes('fetch') ||
         err.message.includes('NetworkError') || err.message.includes('Failed to fetch') ||
         err.message.includes('Load failed');
}

// ── Auth (signup/signin) ───────────────────────────────────────
handleAuth = async function(e, type) {
  e.preventDefault();
  const msg = document.getElementById('authMsg');
  msg.style.color = ''; msg.textContent = '';

  const name  = type === 'signup' ? document.querySelector('#signupForm input[type="text"]').value.trim() : '';
  const email = type === 'signup'
    ? document.querySelector('#signupForm input[type="email"]').value.trim()
    : document.querySelector('#signinForm input[type="email"]').value.trim();
  const pass1 = type === 'signup' ? document.getElementById('signupPass').value : document.getElementById('signinPass').value;
  const pass2 = type === 'signup' ? document.getElementById('signupPass2').value : '';
  const terms = type === 'signup' ? document.getElementById('terms').checked : true;

  if (type === 'signup') {
    if (pass1.length < 6) { msg.style.color='#ef4444'; msg.textContent='⚠️ Password must be at least 6 characters.'; return; }
    if (pass1 !== pass2)  { msg.style.color='#ef4444'; msg.textContent='⚠️ Passwords do not match.'; return; }
    if (!terms)           { msg.style.color='#ef4444'; msg.textContent='⚠️ Please agree to the Terms & Privacy Policy.'; return; }
  }

  let userName = name;
  let success  = false;

  // Try API first
  if (typeof API !== 'undefined') {
    try {
      const res = type === 'signup' ? await API.signup(name, email, pass1) : await API.signin(email, pass1);
      localStorage.setItem('gedamu_token', res.token);
      sessionStorage.setItem('gedamu_user', JSON.stringify(res.user));
      userName = res.user.name;
      success  = true;
    } catch(err) {
      if (!isOfflineError(err)) {
        msg.style.color = '#ef4444'; msg.textContent = '⚠️ ' + err.message; return;
      }
      // offline — fall through to localStorage
    }
  }

  // localStorage fallback
  if (!success) {
    const users = JSON.parse(localStorage.getItem('gedamu_users') || '[]');
    if (type === 'signup') {
      if (users.find(u => u.email === email)) { msg.style.color='#ef4444'; msg.textContent='⚠️ Email already registered.'; return; }
      users.push({ name, email, password: pass1 });
      localStorage.setItem('gedamu_users', JSON.stringify(users));
      sessionStorage.setItem('gedamu_user', JSON.stringify({ name, email }));
      userName = name;
    } else {
      const user = users.find(u => u.email === email && u.password === pass1);
      if (!user) { msg.style.color='#ef4444'; msg.textContent='⚠️ Invalid email or password.'; return; }
      sessionStorage.setItem('gedamu_user', JSON.stringify({ name: user.name, email: user.email }));
      userName = user.name;
    }
  }

  msg.style.color = '#10b981';
  msg.textContent = type === 'signup' ? `✅ Welcome ${userName}!` : `✅ Welcome back, ${userName}!`;
  e.target.reset();
  setTimeout(() => {
    closeModal(); msg.textContent = '';
    updateAuthUI(); unlockForms();
    showWelcomeToast(userName, type);
  }, 1800);
};

// ── Repair Request ─────────────────────────────────────────────
handleSubmit = async function(e) {
  e.preventDefault();
  if (!getUser()) { showAuthRequired('formMsg','repair'); return; }
  if (!captchaVerified.repair) {
    const m = document.getElementById('formMsg');
    m.style.color='#f97316'; m.textContent='⚠️ Please complete the human verification first.';
    setTimeout(()=>m.textContent='',3000); return;
  }

  const user    = getUser();
  const phone   = document.getElementById('clientPhone').value;
  const brand   = document.getElementById('deviceBrand').value;
  const model   = document.getElementById('deviceModel').value;
  const desc    = document.getElementById('problemDesc').value.trim();
  const urgency = document.querySelector('input[name="urgency"]:checked')?.value || 'Normal';
  const problems= selectedProblems.length ? selectedProblems.join(', ') : desc || 'Not specified';
  const device  = `${selectedDevice}${brand?' — '+brand:''}${model?' '+model:''}`;

  const costMap = { TV:'ETB 500–2,500', Laptop:'ETB 300–1,500', Mobile:'ETB 200–800',
    Appliance:'ETB 300–1,200', Printer:'ETB 150–700', 'Power System':'ETB 400–1,500' };
  const cost = costMap[selectedDevice] || 'ETB 150–2,500';

  // Try API, fallback to localStorage
  let finalCost = cost;
  if (typeof API !== 'undefined') {
    try {
      const res = await API.submitRepair({ name:user.name, phone, email:user.email, device, problems, urgency });
      finalCost = res.cost;
    } catch(err) {
      if (!isOfflineError(err)) {
        const m = document.getElementById('formMsg');
        m.style.color='#ef4444'; m.textContent='⚠️ '+err.message; return;
      }
      // offline — save to localStorage below
    }
  }

  // Always save to localStorage (works offline + syncs admin dashboard)
  const request = {
    id: 'R-' + Date.now(), device, problems, urgency,
    cost: finalCost, status: 'Pending',
    date: new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}),
    phone, name: user.name, email: user.email || ''
  };
  const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
  if (!all[user.email || 'guest']) all[user.email || 'guest'] = [];
  all[user.email || 'guest'].unshift(request);
  localStorage.setItem('gedamu_repair_requests', JSON.stringify(all));

  const msg = document.getElementById('formMsg');
  msg.style.color = 'green';
  msg.textContent = `✅ Request submitted! Estimated cost: ${finalCost}. We'll call you at ${phone} shortly.`;
  e.target.reset(); selectedDevice=''; selectedProblems=[];
  captchaVerified.repair=false; resetCaptchaBox('repair'); goStep(1);
  setTimeout(()=>msg.textContent='',6000);
};

// ── Review Submission ──────────────────────────────────────────
submitReview = async function(e) {
  e.preventDefault();
  if (!getUser()) { showAuthRequired('reviewMsg','review'); return; }
  if (!captchaVerified.review) {
    const m = document.getElementById('reviewMsg');
    m.style.color='#f97316'; m.textContent='⚠️ Please complete the human verification first.';
    setTimeout(()=>m.textContent='',3000); return;
  }
  if (selectedRating === 0) {
    document.getElementById('reviewMsg').style.color='#ef4444';
    document.getElementById('reviewMsg').textContent='⚠️ Please select a star rating.'; return;
  }

  const user    = getUser();
  const service = document.getElementById('reviewService').value;
  const text    = document.getElementById('reviewText').value.trim();
  const now     = new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});

  // Try API
  if (typeof API !== 'undefined') {
    try {
      await API.submitReview({ service, rating:selectedRating, text });
      const data = await API.getReviews();
      reviews = data; saveReviews();
    } catch(err) {
      // offline — save locally
      reviews.push({ name:user.name, service, rating:selectedRating, text, date:now });
      saveReviews();
    }
  } else {
    reviews.push({ name:user.name, service, rating:selectedRating, text, date:now });
    saveReviews();
  }

  renderReviews();
  e.target.reset(); selectedRating=0;
  document.querySelectorAll('.star-picker i').forEach(s=>s.classList.remove('active'));
  captchaVerified.review=false; resetCaptchaBox('review');
  const msg = document.getElementById('reviewMsg');
  msg.style.color='#10b981'; msg.textContent='✅ Thank you for your feedback!';
  setTimeout(()=>msg.textContent='',3000);
};

// ── My Repairs ─────────────────────────────────────────────────
openMyRepairs = async function() {
  const user = getUser();
  if (!user) { openModal('signin'); return; }

  let repairs = [];

  // Try API
  if (typeof API !== 'undefined') {
    try {
      repairs = await API.getMyRepairs();
    } catch(err) {
      // offline — load from localStorage
      const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
      repairs = all[user.email || 'guest'] || [];
    }
  } else {
    const all = JSON.parse(localStorage.getItem('gedamu_repair_requests') || '{}');
    repairs = all[user.email || 'guest'] || [];
  }

  renderMyRepairs(user, repairs);
};

function renderMyRepairs(user, repairs) {
  const modal   = document.getElementById('myRepairsModal');
  const statsEl = document.getElementById('myRepairsStats');
  const listEl  = document.getElementById('myRepairsList');
  const total     = repairs.length;
  const pending   = repairs.filter(r=>r.status==='Pending').length;
  const progress  = repairs.filter(r=>r.status==='In Progress').length;
  const completed = repairs.filter(r=>r.status==='Completed').length;

  statsEl.innerHTML = `
    <div class="mr-stat"><i class="fas fa-tools" style="color:#3b82f6"></i><span>${total}</span><small>Total</small></div>
    <div class="mr-stat"><i class="fas fa-hourglass-half" style="color:#f59e0b"></i><span>${pending}</span><small>Pending</small></div>
    <div class="mr-stat"><i class="fas fa-spinner" style="color:#f97316"></i><span>${progress}</span><small>In Progress</small></div>
    <div class="mr-stat"><i class="fas fa-check-circle" style="color:#10b981"></i><span>${completed}</span><small>Completed</small></div>`;

  const sc = {Pending:'#f59e0b','In Progress':'#3b82f6',Completed:'#10b981'};
  const sb = {Pending:'#fef9c3','In Progress':'#dbeafe',Completed:'#dcfce7'};

  listEl.innerHTML = repairs.length ? repairs.map(r=>`
    <div class="mr-card">
      <div class="mr-card-top">
        <div>
          <div class="mr-device"><i class="fas fa-microchip"></i> ${r.device}</div>
          <div class="mr-date"><i class="fas fa-calendar"></i> ${r.date||r.created_at||''} &nbsp;|&nbsp; <i class="fas fa-bolt"></i> ${r.urgency}</div>
        </div>
        <span class="mr-status" style="background:${sb[r.status]||'#f1f5f9'};color:${sc[r.status]||'#64748b'}">${r.status}</span>
      </div>
      <div class="mr-problems"><i class="fas fa-exclamation-circle" style="color:#f97316"></i> <strong>Issue:</strong> ${r.problems}</div>
      <div class="mr-cost"><i class="fas fa-coins" style="color:#facc15"></i> <strong>Estimated Cost:</strong> <span style="color:#f97316;font-weight:700">${r.cost||'TBD'}</span></div>
      <div class="mr-id">Request ID: ${r.id||r.request_id||''}</div>
    </div>`).join('')
  : '<div class="mr-empty"><i class="fas fa-inbox"></i><p>No repair requests yet.<br>Submit one below!</p></div>';

  modal.classList.add('active');
}

// ── Load reviews on page start ─────────────────────────────────
(async () => {
  if (typeof API !== 'undefined') {
    try {
      const data = await API.getReviews();
      if (data.length) { reviews = data; saveReviews(); renderReviews(); }
    } catch(e) { /* use localStorage */ }
  }
})();


// ── FRONTEND SECURITY ──────────────────────────────────────────

// Sanitize any string before injecting into innerHTML
function sanitize(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

// Apply sanitize to all user-generated content in reviews
const _origRenderCards = typeof renderCards !== 'undefined' ? renderCards : null;
function renderCards(items) {
  return items.map(r => `
    <div class="review-card">
      <div class="review-top">
        <span class="review-author">${sanitize(r.name)}</span>
        <span class="review-date">${sanitize(r.date)}</span>
      </div>
      <div class="review-stars">${starsHTML(r.rating)}</div>
      ${r.service ? `<span class="review-service">${sanitize(r.service)}</span>` : ''}
      <p class="review-text">${sanitize(r.text)}</p>
    </div>`).join('');
}

// Input length limits — prevent huge payloads
document.addEventListener('DOMContentLoaded', () => {
  const limits = {
    '#reviewName':    50,
    '#reviewText':    500,
    '#clientName':    80,
    '#clientPhone':   20,
    '#clientEmail':   100,
    '#deviceModel':   60,
    '#problemDesc':   300,
    '#adminUser':     30,
    '#adminPass':     50,
  };
  Object.entries(limits).forEach(([sel, max]) => {
    const el = document.querySelector(sel);
    if (el) el.maxLength = max;
  });

  // Prevent paste of scripts into text fields
  document.querySelectorAll('input[type="text"], input[type="email"], textarea').forEach(el => {
    el.addEventListener('paste', e => {
      const pasted = (e.clipboardData || window.clipboardData).getData('text');
      if (/<script|javascript:|onerror=/i.test(pasted)) {
        e.preventDefault();
        console.warn('Blocked suspicious paste content.');
      }
    });
  });
});

// Sanitize welcome toast (uses user.name from server/localStorage)
const _origShowWelcomeToast = showWelcomeToast;
showWelcomeToast = function(name, type) {
  _origShowWelcomeToast(sanitize(name), type);
};

console.log('🔒 Frontend security active.');


// ── PERFORMANCE OPTIMIZATIONS ──────────────────────────────────

// 1. Lazy load Google Maps — only load when contact section is visible
(function lazyLoadMap() {
  const iframe = document.getElementById('mapIframe');
  if (!iframe) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        iframe.src = iframe.dataset.src;
        observer.disconnect();
      }
    });
  }, { rootMargin: '200px' });
  observer.observe(iframe);
})();

// 2. Lazy load service card background images
(function lazyLoadCardBgs() {
  const cards = document.querySelectorAll('.card[style*="--card-bg"]');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const card = entry.target;
        const bg = card.style.getPropertyValue('--card-bg');
        if (bg) card.style.backgroundImage = bg.replace('url(', '').replace(')', '');
        observer.unobserve(card);
      }
    });
  }, { rootMargin: '100px' });
  cards.forEach(c => observer.observe(c));
})();

// 3. Debounce search inputs for performance
function debounce(fn, delay = 300) {
  let timer;
  return function(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

// Apply debounce to navbar search
document.addEventListener('DOMContentLoaded', () => {
  const navInput = document.getElementById('navSearchInput');
  if (navInput) {
    const original = navInput.oninput;
    navInput.oninput = debounce(function() { handleNavSearch(this.value); }, 250);
  }
});

// 4. Cache DOM references used frequently
const DOM = {
  get authModal()    { return document.getElementById('authModal'); },
  get myRepairsModal(){ return document.getElementById('myRepairsModal'); },
  get formMsg()      { return document.getElementById('formMsg'); },
  get reviewMsg()    { return document.getElementById('reviewMsg'); },
};

// 5. Preload next likely page when hovering service cards
document.addEventListener('DOMContentLoaded', () => {
  const serviceLinks = {
    'TV Repair':           'services/tv-repair.html',
    'Laptop & PC':         'services/laptop-pc.html',
    'Mobile Phones':       'services/mobile-phones.html',
    'Home Appliances':     'services/home-appliances.html',
    'Printers & Scanners': 'services/printers.html',
    'Power Systems':       'services/power-systems.html',
  };

  document.querySelectorAll('.services-grid .card').forEach(card => {
    card.addEventListener('mouseenter', () => {
      const title = card.querySelector('h3')?.textContent;
      const url   = serviceLinks[title];
      if (url && !document.querySelector(`link[href="${url}"]`)) {
        const link = document.createElement('link');
        link.rel  = 'prefetch';
        link.href = url;
        document.head.appendChild(link);
      }
    }, { once: true });
  });
});

console.log('⚡ Performance optimizations active.');

// ── ADS PRIVACY CHOICES ────────────────────────────────────────
function openAdsPrivacy() {
  // Load saved preference
  const saved = localStorage.getItem('gedamu_functional_storage');
  const toggle = document.getElementById('functionalToggle');
  if (toggle && saved !== null) toggle.checked = saved === 'true';
  document.getElementById('adsPrivacyModal').classList.add('active');
}

function closeAdsPrivacy() {
  document.getElementById('adsPrivacyModal').classList.remove('active');
}

function savePrivacyChoice(type, value) {
  localStorage.setItem(`gedamu_${type}_storage`, value);
  if (!value && type === 'functional') {
    // Clear functional data if user opts out
    localStorage.removeItem('gedamu_repair_requests');
    localStorage.removeItem('gedamu_reviews');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const m = document.getElementById('adsPrivacyModal');
  if (m) m.addEventListener('click', e => { if (e.target === m) closeAdsPrivacy(); });
});


// ── FRONT PAGE NEWS ────────────────────────────────────────────
function renderFrontNews() {
  const grid = document.getElementById('newsFrontGrid');
  if (!grid) return;
  const TYPE_ICONS = { announcement:'📢', promotion:'🎉', update:'🔧', tip:'💡' };
  const news = JSON.parse(localStorage.getItem('gedamu_news') || '[]')
    .filter(n => n.status === 'published' && n.showWeb === 'yes');
  if (!news.length) { grid.innerHTML = ''; return; }
  grid.innerHTML = news.map(n => `
    <div class="nac-card type-${n.type}">
      <span class="nac-badge">${TYPE_ICONS[n.type]||'📰'} ${n.type.charAt(0).toUpperCase()+n.type.slice(1)}</span>
      <div class="nac-title">${sanitize(n.title)}</div>
      <div class="nac-content">${sanitize(n.content)}</div>
      <div class="nac-date"><i class="fas fa-calendar-alt"></i> ${n.date}</div>
    </div>`).join('');
}
document.addEventListener('DOMContentLoaded', renderFrontNews);

// ── FRONT PAGE NEWS ────────────────────────────────────────────
const TYPE_ICONS_FRONT = { announcement:'📢', promotion:'🎉', update:'🔧', tip:'💡' };

function renderFrontNews() {
  const grid = document.getElementById('newsFrontGrid');
  if (!grid) return;
  const news = JSON.parse(localStorage.getItem('gedamu_news') || '[]')
    .filter(n => n.status === 'published' && n.showWeb === 'yes');
  if (!news.length) { grid.innerHTML = ''; return; }
  grid.innerHTML = news.map((n, i) => `
    <a href="news-detail.html?id=${i}" class="news-front-card type-${n.type}" style="text-decoration:none">
      <span class="nfc-badge">${TYPE_ICONS_FRONT[n.type]||'📰'} ${n.type.charAt(0).toUpperCase()+n.type.slice(1)}</span>
      <div class="nfc-title">${sanitize(n.title)}</div>
      <div class="nfc-content">${sanitize(n.content)}</div>
      <div class="nfc-date"><i class="fas fa-calendar-alt"></i> ${n.date}</div>
    </a>`).join('');
}

document.addEventListener('DOMContentLoaded', renderFrontNews);
